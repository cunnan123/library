// components/loading/loading.js
const app = getApp();
const $ = app.global;
Component({
    options: {
        multipleSlots: true
    },
    /**
     * 组件的属性列表
     */
    properties: {

    },

    /**
     * 组件的初始数据
     */
    data: {
        imgurl: $.imgurl,
        isShow:false
    },

    /**
     * 组件的方法列表
     */
    methods: {
        //隐藏
        hide() {
            if (!this.data.isShow){return}
            this.setData({
                isShow: !this.data.isShow
            })
        },
        //展示
        show() {
            if (this.data.isShow){return}
            this.setData({
                isShow: !this.data.isShow
            })
        },
    }
})
