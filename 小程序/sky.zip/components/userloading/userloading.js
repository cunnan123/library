// components/userloading/userloading.js
const app = getApp();
const $ = app.global;
Component({
    options: {
        multipleSlots: true
    },
    /**
     * 组件的属性列表
     */
    properties: {

    },
    lifetimes: {
        attached: function () {
            // 在组件实例进入页面节点树时执行
            this.loading = this.selectComponent("#loading")
        },
    },
    attached: function () {
        // 在组件实例进入页面节点树时执行
        this.loading = this.selectComponent("#loading")
    },
    /**
     * 组件的初始数据
     */
    data: {
        latlng: null,
        imgurl: $.imgurl,
        isShow: false
    },
    /**
     * 组件的方法列表
     */
    methods: {
        //隐藏
        hide() {
            if (!this.data.isShow) { return }
            this.setData({
                isShow: !this.data.isShow
            })
            $.f.setglobalData('userloading', false)
        },
        //展示
        show() {
            if (this.data.isShow) { return }
            this.setData({
                isShow: !this.data.isShow
            })
            $.f.setglobalData('userloading', true)
        },
        getUserInfo(e) {
            var _this = this;
            _this.hide();
            _this.loading.show();
            if (e.detail.errMsg == "getUserInfo:ok") {
                var data = $.f.decipher(e.detail.encryptedData, e.detail.iv);
                if(data!=''){//解密成功
                    $.f.setglobalData('userInfo', data);
                    _this.signUnionid(data.unionId);//进行uid加密
                    _this.updateUnionid(data.unionId);//把unionId回传给后台
                } else {//解密失败..为了区分赋值为字符串false
                    $.f.setglobalData('userUnionId','false')
                    $.f.setStorageSync('userUnionId', 'false')
                    _this.loading.hide();
                    _this.getLocation();
                }
            } else {
                console.log('用户拒绝了授权');
                $.f.setglobalData('userUnionId', 'false')
                $.f.setStorageSync('userUnionId', 'false')
                _this.loading.hide();
                _this.getLocation();
            }
        },
        clickchoose:function (e) {//点击关闭
            console.log('用户点击关闭');
            $.f.setglobalData('userUnionId', 'false')
            $.f.setStorageSync('userUnionId', 'false')
            this.hide();
            this.getLocation();
        },
        updateUnionid: function (e) {//把unionId回传给后台
            let params = {
                appopenid: app.globalData.userOpenId,
                unionid: e
            };
            $.Http.request($.HttpURL.updateUnionid, params, false, function (res) {})
        },
        signUnionid: function (e) {//进行uid加密
            let _this = this;
            let params = {
                sign: '',
                userid: e
            };
            $.Http.request($.HttpURL.desStringUserId, params, false, function (res) {
                //放入缓存及全局变量
                $.f.setglobalData('userUnionId', res.userid)
                $.f.setStorageSync('userUnionId', res.userid)
                _this.loading.hide();
                _this.getLocation();
            })
        },
        getLocation: function () { //获取地理位置
            var _this = this
            wx.getLocation({
                type: 'gcj02',
                success: function (res) {
                    _this.setData({
                        latlng:res
                    })
                    _this._Location();
                },
                cancel: function (res) {
                    _this._Location() //按定位成功逻辑
                },
                fail: function (res) {
                    _this._Location() //按定位成功逻辑
                }
            })
        },
        _Location(e) {
            //触发取消回调
            let myEventDetail = this.data.latlng;
            this.triggerEvent("Location", myEventDetail)
        },
    }
})
