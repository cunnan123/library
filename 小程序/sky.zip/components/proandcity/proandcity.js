// components/proandcity/proandcity.js
const app = getApp();
const $ = app.global;
var obj = [];//需要返回的数据
Component({
    options: {
        multipleSlots: true
    },
    /**
     * 组件的属性列表
     */
    properties: {// 传入层级1（省级）.2（市级）.3（县级）
        rank: {
            type: String,
            value: '3'
        },
    },
    /**
     * 组件数据
     */
    data: {
        list:null,
        originaldata:null,
        scrolltop:null,//滚动条位置
    },
    /**
     * 组件布局完成
     */
    ready() {
        let _this = this;
        if (!app.globalData.ProviceCityData){
            wx.request({
                url: $.HttpDomain+'wechatpageview/common/js/ProvinceCityData.json',
                success(res) {
                    _this.setData({
                        list: res.data,
                        originaldata: res.data,
                        scrolltop:0
                    });
                    $.f.setglobalData('ProviceCityData', res.data)
                }
            })
        }else{
            this.setData({
                list: app.globalData.ProviceCityData,
                originaldata: app.globalData.ProviceCityData,
                scrolltop: 0
            })
        }
        // console.log(this.data)
    },

    /**
     * 组件的方法列表
     */
    methods: {
        //隐藏
        hide() {
            if (!this.data.isShow) { return }
            this.setData({
                isShow: !this.data.isShow
            })
        },
        //展示
        show() {
            if (this.data.isShow) { return }
            obj = [];
            this.setData({
                isShow: !this.data.isShow,
                list: this.data.originaldata,
                scrolltop: 0
            });
        },
        _cancelproandcity(e) {
            //触发取消回调
            this.hide();
            // this.triggerEvent("cancelproandcity")
        },
        _confirmproandcity(e) {
            //触发点击回调
            let cl = e.currentTarget.dataset.val;
            console.log(cl);
            obj.push({ 'name': cl.name, 'code': cl.code });
            if (this.data.rank == '1') {
                this.back();
            }
            if (this.data.rank == '2') {
                if (cl['city']) {
                    if (cl['city'].length == 1) {
                        obj.push({ 'name': cl['city'][0].name, 'code': cl['city'][0].code });
                        this.back();
                    } else {
                        this.setData({
                            list: cl['city'],
                            scrolltop:0
                        });
                    }
                    return
                }
                this.back();
            }
            if (this.data.rank == '3') {
                if (cl['city']) {
                    if (cl['city'].length == 1) {
                        obj.push({ 'name': cl['city'][0].name, 'code': cl['city'][0].code }),
                            this.setData({
                                list: cl['city'][0]['area'],
                                scrolltop:0
                            })
                    } else {
                        this.setData({
                            list: cl['city'],
                            scrolltop:0
                        });
                    }
                    return
                }
                if (cl['area']) {
                    this.setData({
                        list: cl['area'],
                        scrolltop: 0
                    });
                    return
                }
                this.back();
            }
        },
        back() {
            if(obj.length==1){obj[1] = obj[0]}
            if(obj.length==2){obj[2] = obj[1]}
            this.triggerEvent("confirmproandcity", obj);
            this.hide();
        }
    }
})
