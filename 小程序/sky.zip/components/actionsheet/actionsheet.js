// components/actionsheet/actionsheet.js
Component({
    options: {
        multipleSlots: true 
    },
    ready() {
        // console.log(this.data);
    },
    /**
     * 组件的属性列表
     */
    properties: {
        obj: {
            type: Object,
        },
    },

    /**
     * 组件的初始数据
     */
    data: {
        isShow: false
    },

    /**
     * 组件的方法列表
     */
    methods: {
        //隐藏
        hide() {
            this.setData({
                isShow: !this.data.isShow
            })
        },
        //展示
        show() {
            this.setData({
                isShow: !this.data.isShow
            })
        },
        _cancelEvent(e) {
            //触发取消回调
            this.triggerEvent("cancelEvent")
        },
        _confirmEvent(e) {
            //触发点击回调
            this.triggerEvent("confirmEvent", e.currentTarget.dataset.val);
        }
    }
})
