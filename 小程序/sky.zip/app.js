//app.js
var $ = require("utils/const.js");
var xbossdebug = require('utils/xbossdebug.js') // 引用xbossdebug
xbossdebug.config.key = 'kzfwxcx' // key为自定义唯一值，用于后端记录时区分应用
xbossdebug.config.url = 'https://wechattest.chinalife-p.com.cn/wechatpageservice/testaaa/backUp.do'; // 上报服务端地址
// 可选参数
xbossdebug.config.setSystemInfo = true; // 获取系统信息
xbossdebug.config.setLocation = true; // 获取用户位置信息
App({
    global: $,
    onLaunch: function () {
        console.log($);
        var _this = this;
        _this.checkSession();// 检查登录态
        _this.getUserInfo();// 基本信息
        _this.overShare();//重写分享方法
    },
    onShow:function(){
        this.updataApp();//检查更新
    },
    onError(msg) {
        // $.xbossdebug.error(msg)
    },
    checkSession: function () {// 检查登录态
        wx.showLoading({
            title: '加载中',
            mask:true
        })
        var _this = this;
        wx.checkSession({
            success() {
                console.log('session_key未失效');
                //session_key 未过期，并且在本生命周期一直有效
                //尝试取缓存
                var data = $.f.getStorageSync('userSessionKey');
                var data0 = $.f.getStorageSync('userUnionId');
                var data1 = $.f.getStorageSync('userOpenId');
                var data7 = $.f.getStorageSync('userOpenIds');
                var data5 = $.f.getStorageSync('userId');
                var data2 = $.f.getStorageSync('userWxOpenId');
                var data3 = $.f.getStorageSync('userUserId');
                var data4 = $.f.getStorageSync('userPhone');
                var data6 = $.f.getStorageSync('userName');
                if (data && data0 && data1 && data7 && data5) {
                    console.log('重要数据都取到');
                    $.f.setglobalData('userSessionKey', data)
                    $.f.setglobalData('userUnionId', data0)
                    $.f.setglobalData('userOpenId', data1)
                    $.f.setglobalData('userOpenIds', data7)
                    $.f.setglobalData('userId', data5)
                    if (data2) {$.f.setglobalData('userWxOpenId', data2)}
                    if (data3) {$.f.setglobalData('userUserId', data3)}
                    if (data4) {$.f.setglobalData('userPhone', data4)}
                    if (data6) {$.f.setglobalData('userName', data6)}
                    wx.hideLoading();
                    if (_this.checkSeeionkeyCallback) {//用于判断是否需要授权
                        _this.checkSeeionkeyCallback()
                    }
                } else {
                    console.log('重要值没有全部取到');
                    _this.getSeeionkey();
                }
            },
            fail() {
                // session_key 已经失效，需要重新执行登录流程
                console.log('session_key已经失效')
                _this.getSeeionkey()
            }
        })
    },
    getSeeionkey: function () {// session_key失效或userSessionkey不存在 获取用户openid
        var _this = this
        wx.login({
            success: res => {
                console.log('wx.login返回', res);
                //发送 res.code 到后台换取 openId, sessionKey, unionId
                let params = {
                    code: res.code,
                    appid: $.AppID,
                    secret: $.secret,
                };
                $.Http.request($.HttpURL.getOpenId, params, false, function (res) {
                    $.f.setglobalData('userSessionKey', res.session_key)
                    $.f.setglobalData('userUnionId', res.unionid)
                    $.f.setglobalData('userOpenId', res.appopenid)
                    $.f.setglobalData('userOpenIds', res.appopenids)
                    $.f.setglobalData('userId', res.id)
                    $.f.setglobalData('userWxOpenId', res.wxopenid)
                    $.f.setglobalData('userUserId', res.userid)

                    $.f.setStorageSync('userSessionKey', res.session_key)
                    $.f.setStorageSync('userUnionId', res.unionid)
                    $.f.setStorageSync('userOpenId', res.appopenid)
                    $.f.setStorageSync('userOpenIds', res.appopenids)
                    $.f.setStorageSync('userId', res.id)
                    $.f.setStorageSync('userWxOpenId', res.wxopenid)
                    $.f.setStorageSync('userUserId', res.userid)
                    wx.hideLoading();
                    // 由于是网络请求，可能会在 Page.onLoad 之后才返回
                    // 所以此处加入 callback 以防止这种情况
                    if (_this.userSeeionkeyCallback) {
                        _this.userSeeionkeyCallback(res)
                    }
                })
            }
        })
    },
    getUserInfo: function () {//在用户已授权的情况下获取基本信息
        wx.getSetting({
            success: res => {
                if (res.authSetting['scope.userInfo']) {
                    // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
                    wx.getUserInfo({
                        success: res => {
                            // 解密用户信息
                            var data = $.f.decipher(res.encryptedData, res.iv)
                            $.f.setglobalData('userInfo', data)
                            // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
                            // 所以此处加入 callback 以防止这种情况
                            if (this.userInfoReadyCallback) {
                                this.userInfoReadyCallback(res)
                            }
                        }
                    })
                } else {
                    console.log('用户未授权登录')
                }
            }
        })
    },
    updataApp: function () {//版本更新
        if (wx.canIUse('getUpdateManager')) {
            const updateManager = wx.getUpdateManager()
            updateManager.onCheckForUpdate(function (res) {
                // console.log(res)
                if (res.hasUpdate) { // 请求完新版本信息的回调
                    updateManager.onUpdateReady(function () {
                        wx.showModal({
                            title: '更新提示',
                            content: '新版本已经准备好，是否重启应用？',
                            success: function (res) {
                                if (res.confirm) {// 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
                                    updateManager.applyUpdate()
                                }
                            }
                        })
                    })
                    updateManager.onUpdateFailed(function () {
                        wx.showModal({// 新的版本下载失败
                            title: '已经有新版本了哟~',
                            content: '新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~',
                        })
                    })
                }
            })
        } else {
            wx.showModal({// 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
                title: '提示',
                content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
            })
        }
    },
    overShare: function () { //重写分享方法
        //监听路由切换
        //间接实现全局设置分享内容
        wx.onAppRoute(function (res) {
            //获取加载的页面
            let pages = getCurrentPages();
            //获取当前页面的对象
            let view = pages[pages.length - 1];
            //重置分享
            let data = view.data;
            if (!data.isOverShare) {//若某个页面不需通用分享。请把该页的data.isOverShare:true
                view.onShareAppMessage = function () {
          //调用分享接口,进行分享
          setTimeout(function() {
            let params = {
              unionId: getApp().globalData.userUnionId,
              openId: getApp().globalData.userOpenId,
              channelFlag: "03",
              operateType: "04",
              phoneNumber: getApp().globalData.userPhone
            };
            $.Http.request($.HttpURL.finishTask, params, false, function(res) {
              // if (res.result.score == 30) {
              //   //分享成功
              //   wx.showToast({
              //     title: '分享成功',
              //   })
              // } else {
              //   // wx.showToast({
              //   // 	title: '您今日已分享3次，请明日再来！',
              //   // })
              //   wx.showModal({
              //     title: '',
              //     content: '您今日已分享3次，请明日再来！',
              //   })
              // }
            })
          }, 1500)
                    return {
                        path: '/pages/index/index',
                        imageUrl: $.imgurl + 'shareimg.png',
                    }
                }
            }
        })
    },
    sharepush:function (video) { //分享统计回传
        if (video) {//视频的统计重新给shareobj进行赋值
            $.f.setglobalData('shareobj', getApp().globalData.shareobj2);
        }
        if (getApp().globalData.shareobj==''){console.log('非分享链接进入或以记录过');return}
        let obj = JSON.parse(decodeURIComponent(getApp().globalData.shareobj));
        let UnionId = getApp().globalData.userUnionId;
        if (UnionId == 'false' || UnionId == 'none' || UnionId == null || UnionId == undefined) {
            UnionId = '';
        }
        obj.referenceOpenid = getApp().globalData.userOpenIds;
        obj.referenceUnionid = UnionId;
        let timeobj = $.time.showDate(new Date());
        let Time = timeobj.a.replace(/\//g, '-') + ' ' + timeobj.d;
        obj.referenceTime = Time;
        obj.sourceFlag = '1'//空中服务小程序标志
        if (video) {//视频统计
            obj.videoServiceSuccessFlag = '1'
        } else {
            obj.videoServiceSuccessFlag = '0'
        }
        $.Http.request($.HttpURL.shareCount, obj, false, function (res) {})//不进行处理
        $.f.setglobalData('shareobj', '')//上传成功滞空，防止切换导致多次上传
    },
    globalData: {
        userSessionKey: '',//Sessionkey
        userUnionId: '',//用户unionid-加密
        userId: '',//用户id
        userOpenId: '',//用户小程序openid
        userOpenIds: '',//用户小程序openid-加密
        userWxOpenId: '',//用户公众号openid-加密
        userUserId: '',//用户userid
        userPhone: '',//用户手机号
        userInfo: null,//用户个人信息
        address:null,//当前地理位置
        ProviceCityData:null,//省市区三级联动数据，由于不打在包里采用请求的方式故需要个标志
        addressls:null,//用户未定位时选择的地区，为了避免用户未定位的情况下选择一次之后再次进入还会在让选一次的问题
        comcodeandcompany: null,//用户所属分公司，用来在分公司页面复现分公司
        iscomcodetype:false,//用于选择分公司页面是否更改了的标志,用来处理切换之后只发起少数的请求不用刷新首页
        userName:null,//用户绑定的姓名，用来在我的页面复现
        userloading:false,//授权遮罩是否以显示,用来防止用户未授权的情况下点击tab
        authorization:null,//请求token.安全验证
        shareobj:'',//分享进入时的参数
        shareobj2: '',//分享进入时的参数.由于避免多次统计shareobj会情况。所以定义个shareobj2保持这些信息
    signShow: "", //积分获取弹框显示情况
    phoneWindowShow: "", //手机号输入弹框显示
    userPhone: "", //用户手机号
    score: "", //积分豆
    signShowMy: "", //我的页面的展示
    phoneWindowShowMy: "", //我的页面的展示
    signShowService: "", //服务页面的展示
    phoneWindowShowService: "",
   
   
    fenxiangsharePerson:"",//由分享链接进入小程序的unionid--解密后的
    iffenxiang:0,//是否从分享进入的标识0--不是分享进入，1--从分享进入
    myshares:"",//加密的分享人unionid
    }
})
$.Http = require('utils/http.js');
$.f = require('utils/constf.js');
$.time = require('utils/newtime.js');
$.newData = $.time.showDate(new Date());
$.xbossdebug = xbossdebug;