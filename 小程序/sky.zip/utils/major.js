
const url1 = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5668b394c2053c79&redirect_uri=https%3a%2f%2fwechat.chinalife-p.com.cn%2fwechatpageview%2f'; //生产长前半部

const url2 = '%3fappid%3dwx5668b394c2053c79&response_type=code&aaa=aa&scope=snsapi_base&state=appeal#wechat_redirect'; //生产长后半部

const url3 = '%3fappid%3dwx5668b394c2053c79&response_type=code&aaa=aa&scope=snsapi_base&state='; //生产长链接拼参数个别情况后半部（产品仓库之类的会用）

const url4 = 'https://wechat.chinalife-p.com.cn/wechatpageview/'; //生产短链接前半部

//id作为函数寻找对应链接的标识不建议改动
var arr = [ //首页功能图
    {
        'text': '买车险',
        'path': 'WeChatStore_36.png',
        'link': '',
        'id': '0036'
    },
    {
        'text': '查保单',
        'path': 'WeChatStore_10.png',
        'link': url1 + 'myInsure_index.html' + url2,
        'id': '0010'
    },
    {
        'text': '办理赔',
        'path': 'WeChatStore_3.png',
        'link': url4 + 'selfhelpReport_index.html',
        'id': '0003'
    },
    {
        'text': '理赔查询',
        'path': 'WeChatStore_37.png',
        'link': url1 + 'Claimlistwx_index.html' + url2,
        'id': '0037'
    },
    {
        'text': '保单验真',
        'path': 'WeChatStore_34.png',
        'link': url1 + 'warranty_index.html' + url2,
        'id': '0034'
    },
    {
        'text': '网点导航',
        'path': 'WeChatStore_9.png',
        'link': url4 + 'girdcheck_index.html?',
        'id': '0009'
    },
    {
        'text': '祝福家',
        'path': 'WeChatStore_56.png',
        'link': '',
        'id': '0056'
    },
    {
        'text': '验车拍照',
        'path': 'WeChatStore_35.png',
        'link': url1 + 'WeChatScrutineeringwx_index.html' + url2,
        'id': '0035'
    },

    // {
    //     'text': '客服电台',
    //     'path': 'WeChatStore_33.png',
    //     'link': url1 + 'serviceAudio_index.html' + url2,
    //     'id': '0033'
    // },
    {
        'text': '我的权益',
        'path': 'WeChatStore_38.png',
        'link': url1 + 'myQuanyi_index.html' + url2,
        'id': '0038'
    },
    {
        'text': '卡单激活',
        'path': 'WeChatStore_11.png',
        'link': url1 + 'cardActivatewx_index.html' + url2,
        'id': '0011'
    },
    {
        'text': '保险商城',
        'path': 'WeChatStore_6.png',
        'link': url4 + 'WareHouse_index.html?',
        'id': '0006'
    },
    {
        'text': '电子发票',
        'path': 'WeChatStore_8.png',
        'link': url1 + 'Eleinvoice_index.html' + url2,
        'id': '0008'
    },
    {
        'text': '我的诉求',
        'path': 'WeChatStore_7.png',
        'link': url1 + 'myAppealwx_index.html' + url2,
        'id': '0007'
    },
    {
        'text': '天气提醒',
        'path': 'WeChatStore_100.png',
        'link': url1 + 'weatherRemindwx_index.html' + url3,
        'id': '0100'
    },
    {
        'text': '道路救援',
        'path': 'WeChatStore_23.png',
        'link': url1 + 'roadSidewx_index.html' + url2,
        'id': '0023',
    },
    {
        'text': '酒店优享',
        'path': 'WeChatStore_24.png',
        'link': url1 + 'OasisHotel_index.html' + url2,
        'id': '0024',
    },
    {
        'text': '反保险欺诈举报',
        'path': 'WeChatStore_0.png',
        'link': url1 + 'Antifraud.html' + url2,
        'id': '0077',
    },
    {
      'text': '证件更新',
      'path': 'cardupdate.png',
      'link': url1 +"certificateUpdate_index.html"+url2,
      'id': '0083',
    },
];
var arr1 = [ //全心全意差异化链接
    {
        'text': '保险商城',
        'path': 'shopping.png',
        'link': url4 + 'WareHouse_index.html?',
        'id': '0006',
        'color': '#009B63'
    },
    {
        'text': '道路救援',
        'path': 'rescue.png',
        'link': url1 + 'roadSidewx_index.html' + url2,
        'id': '0023',
        'color': '#BF323A'
    },
    // {
    //     'text': '酒店优享',
    //     'path': 'hotel.png',
    //     'link': url1 + 'OasisHotel_index.html' + url2,
    //     'id': '0024',
    //     'color': '#1A7FD1'
    // },
      {
        'text': '自由保',
        'path': 'ziyoubao.png',
        'link': "",
        'id': '0091',
        'color': '#1A7FD1'
      },
];
var arr2 = [ //热销产品
    // {
    //     pro_description: '意外身故/伤残',
    //     pro_id: '143',
    //     pro_name: '熊孩子险',
    //     pro_pic_base64: '',
    //     pro_pic_url: 'pro1.png',
    //     pro_price: '35'
    // },
    {
      pro_description: '家财无忧/责任无忧/费用无忧',
      pro_id: '125',
      pro_name: '居家无忧',
      pro_pic_base64: '',
      pro_pic_url: 'jjwy2.png',
      pro_price: '198'
    },
    {
        pro_description: '意外身故/伤残/意外医疗',
        pro_id: '131',
        pro_name: '安心驾',
        pro_pic_base64: '',
        pro_pic_url: 'pro3.png',
        pro_price: '45'
    },
    {
        pro_description: '超值服务/全面保障/专业推荐',
        pro_id: '220',
        pro_name: '2019家财险',
        pro_pic_base64: '',
        pro_pic_url: 'pro2.png',
        pro_price: '20'
    },
];
var arr4 = [ //首页轮播图
    {
        'comCode': '00000000',
        'imgAddress': 'https://wechat.chinalife-p.com.cn/viewimages/kzimages/images/Wechatbanner0.jpg',
        'sliLink': 'Wechatbanner0'
    },
    {
        'comCode': '00000000',
        'imgAddress': 'https://wechat.chinalife-p.com.cn/viewimages/kzimages/images/Wechatbanner1.png',
        'sliLink': 'Wechatbanner1'
    },
    {
        'comCode': '00000000',
        'imgAddress': 'https://wechat.chinalife-p.com.cn/viewimages/kzimages/images/Wechatbanner2.png',
        'sliLink': 'Wechatbanner2'
    },
    {
        'comCode': '00000000',
        'imgAddress': 'https://wechat.chinalife-p.com.cn/viewimages/kzimages/images/Wechatbanner3.png',
        'sliLink': 'Wechatbanner3'
    },
];
var arr5 = [ //不进行展示的链接
    {
        'text': '个人信息个人',
        'path': 'WeChatStore_0.png',
        'link': url1 + 'personalInformation_index.html' + url2,
        'id': '0099'
    },
    {
        'text': '个人信息',
        'path': 'WeChatStore_40.png',
        'link': url1 + 'myInformation_index.html' + url2,
        'id': '0040',
    },
    {
        'text': '我的保险',
        'path': 'WeChatStore_41.png',
        'link': url1 + 'myInsure_index.html' + url2,
        'id': '0041',
    },
    {
        'text': '热门活动',
        'path': 'WeChatStore_2.png',
        'link': url1 + 'activity_index.html' + url2,
        'id': '0002'
    },
    {
        'text': '内部服务',
        'path': 'WeChatStore_4.png',
        'link': url1 + 'myStafftrance_index.html' + url2,
        'id': '0004'
    },
    {
        'text': '服务引导',
        'path': 'WeChatStore_5.png',
        'link': url1 + 'serviceGuide_index.html' + url2,
        'id': '0005'
    },
    {
        'text': '签到有礼',
        'path': 'cardupdate.png',
        'link': url1 + "SignInPolite_index.html" + url2,//生产
        //  'link': 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxb1b70bf91a06f3e5&redirect_uri=http%3a%2f%2fwechattest.chinalife-p.com.cn%2fwechatpageview%2fSignInPolite_index.html%3fappid%3dwxb1b70bf91a06f3e5&response_type=code&aaa=aa&scope=snsapi_base&state=appeal#wechat_redirect',
        'id': '00001',
    },
];
var arr7 = [ //更多精彩-公司新闻
    {
        'text': '王滨董事长致国寿大家庭的一封信！',
        'link': 'https://mp.weixin.qq.com/s/oVVcUnepGgp1VrlQ3Cl92Q',       
        'img':  'jianshe',
        'time': '2019-11-18',
        'id': '02'
        // 'id': '0091'
    },
    {
        'text': '书信写初心，国寿载使命——中国人寿举行70周年书信展演活动！',
        'link': 'https://mp.weixin.qq.com/s/REk9mGd9JMaKXRUpeboxyg',
        'img':  'gong2',
        'time': '2019-11-18',
        'id': '01'
    },
    {
        'text': '荣誉 | 中国人寿CBA赞助品牌营销传播再获殊荣！',
        'link': 'https://mp.weixin.qq.com/s/HtMEYw4HJ6FJlW9AW75yDQ',
        'img': 'gong3',
        'time': '2019-11-18',
        'id': '03'
    },
];
var arr8 = [ //更多精彩-更多动态
    {
        'text': '扶贫 | 无惧风雪，雪莲花开！',
        'link': 'https://mp.weixin.qq.com/s/x6rdOWpyEyyBL6mBBlBF1Q',
        'img': 'fengxue',
        'time': '2019-11-18',
        'id': '06'
    },
    {
        'text': '守护 | 聚星光微力，被看见，才安全！',
        'link': 'https://mp.weixin.qq.com/s/wdMNXqTmuRH00hn8_cZacw',
        'img': 'xingguang',
        'time': '2019-11-18',
        'id': '04'
    },
    {
        'text': '风采 | 遇见更优秀的自己！',
        'link': 'https://mp.weixin.qq.com/s/fdKvDluUB8IOpk00e3qSzw',
        'img': 'youxiu',
        'time': '2019-11-18',
        'id': '05'
    },
];
var arr9 = [ //地区省份、直辖市、单列市、国家行政区划码表
    {
        t: '北京市',
        code: '110000'
    },
    {
        t: '天津市',
        code: '120000'
    },
    {
        t: '上海市',
        code: '310000'
    },
    {
        t: '重庆市',
        code: '500000'
    },
    {
        t: '陕西省',
        code: '610000'
    },
    {
        t: '山西省',
        code: '140000'
    },
    {
        t: '河北省',
        code: '130000'
    },
    {
        t: '河南省',
        code: '410000'
    },
    {
        t: '湖南省',
        code: '430000'
    },
    {
        t: '江苏省',
        code: '320000'
    },
    {
        t: '云南省',
        code: '530000'
    },
    {
        t: '浙江-非宁波',
        code: '330000'
    },
    {
        t: '浙江-宁波',
        code: '330200'
    },
    {
        t: '辽宁-非大连',
        code: '210000'
    },
    {
        t: '辽宁-大连',
        code: '210200'
    },
    {
        t: '吉林省',
        code: '220000'
    },
    {
        t: '黑龙江省',
        code: '230000'
    },
    {
        t: '安徽省',
        code: '340000'
    },
    {
        t: '福建-非厦门',
        code: '350000'
    },
    {
        t: '福建-厦门',
        code: '350200'
    },
    {
        t: '江西省',
        code: '360000'
    },
    {
        t: '山东-非青岛',
        code: '370000'
    },
    {
        t: '山东-青岛',
        code: '370200'
    },
    {
        t: '湖北省',
        code: '420000'
    },
    {
        t: '广东-非深圳',
        code: '440000'
    },
    {
        t: '广东-深圳',
        code: '440300'
    },
    {
        t: '海南省',
        code: '460000'
    },
    {
        t: '四川省',
        code: '510000'
    },
    {
        t: '贵州省',
        code: '520000'
    },
    {
        t: '甘肃省',
        code: '620000'
    },
    {
        t: '青海省',
        code: '630000'
    },
    {
        t: '台湾省',
        code: '710000'
    },
    {
        t: '内蒙古自治区',
        code: '150000'
    },
    {
        t: '广西壮族自治区',
        code: '450000'
    },
    {
        t: '西藏自治区',
        code: '540000'
    },
    {
        t: '宁夏回族自治区',
        code: '640000'
    },
    {
        t: '新疆维吾尔自治区',
        code: '650000'
    },
    {
        t: '香港特别行政区',
        code: '810000'
    },
    {
        t: '澳门特别行政区',
        code: '820000'
    }
];
var arr10 = [ //单列市,国家行政区划码表
    {
        t: '宁波市',
        code: '330200'
    },
    {
        t: '大连市',
        code: '210200'
    },
    {
        t: '厦门市',
        code: '350200'
    },
    {
        t: '青岛市',
        code: '370200'
    },
    {
        t: '深圳市',
        code: '440300'
    },
];

module.exports = {
    arr,
    arr1,
    arr2,
    arr4,
    arr5,
    arr7,
    arr8,
    arr9,
    arr10,
}