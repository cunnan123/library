const app = getApp();
const $ = app.global;
const WXBizDataCrypt = require('RdWXBizDataCrypt.js');// 解密
const Base64 = require('cryptojs-master/lib/Base64.js');//base加解密
const major = require('major.js');//功能链接
function findcode(x){
    let a;
    let b;
    if (x.substring(2, 6) == '0000' && x != '810000' && x != '820000') {
        a = x;
        b = x.substring(0, 3) + '100';
    } else {
        a = x.substring(0, 2) + '0000';
        b = x.substring(0, 4) + '00';
    }
    return [a,b]
}
//寻找link
function findlink(x){
    let arr = major.arr;
    let arr1 = major.arr1;
    let arr5 = major.arr5;
    for(var i = 0;i<arr.length;i++){
        if (arr[i].id == x) { return arr[i].link}
    }
    for (var j = 0; j < arr1.length; j++) {
        if (arr1[j].id == x) { return arr1[j].link }
    }
    for (var j = 0; j < arr5.length; j++) {
        if (arr5[j].id == x) { return arr5[j].link }
    }
    return ''
}
//解密
function decipher(x, y) {
    try{
        var Decrypt = {
            encryptedData: x,
            iv: y,
            appId: $.AppID,
            sessionKey: app.globalData.userSessionKey
        }
        console.log('before', JSON.stringify(Decrypt))
        var pc = new WXBizDataCrypt(Decrypt.appId, Decrypt.sessionKey)
        var DecryptUser = pc.decryptData(Decrypt.encryptedData, Decrypt.iv)
        console.log('after', JSON.stringify(DecryptUser))
        return DecryptUser
    }catch(e){return ''}
}
//获取时间相关
function nowtime() {
    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const hour = date.getHours();
    const minute = date.getMinutes();
    const second = date.getSeconds();
    const week = date.getDay();
    switch (week) {
        case 0: x = "星期日";
            break;
        case 1: x = "星期一";
            break;
        case 2: x = "星期二";
            break;
        case 3: x = "星期三";
            break;
        case 4: x = "星期四";
            break;
        case 5: x = "星期五";
            break;
        case 6: x = "星期六";
            break;
    }
    var time = {
        't1': [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':'),
        't2': x,
        't3':'',
    };
    return time
}
//加载遮罩
function showLoading(e) {
    // wx.showLoading({//不使用微信原有的
    //     title: e || '加载中',
    //     mask: true
    // })
    e.show();
}
//隐藏加载遮罩
function hideLoading(e) {
    // wx.hideLoading();//不使用微信原有的
    e.hide();
}
//处理市级字段。去掉市、盟、地区
function getcity(x){
    if (x.substring(x.length - 1, x.length) == "市" || x.substring(x.length - 1, x.length) == "盟") {
        var s = x.substring(0, x.length - 1);
    } else if (x.substring(x.length - 1, x.length) == "州") {
        var s = x.substring(0, 2);
    } else if (x.substring(x.length - 2, x.length) == "地区") {
        var s = x.substring(0, x.length - 2);
    }else{
        var s = x;
    }
    return s
}
//处理地区字段
function getproandcity(x){
    if (x.substring(x.length - 1, x.length) == "市" || x.substring(x.length - 1, x.length) == "盟" || x.substring(x.length - 1, x.length) == "省" || x.substring(x.length - 1, x.length) == "洲") {
        var s = x.substring(0, x.length - 1);
    } else if (x.substring(x.length - 5, x.length) == "特别行政区") {
        var s = x.substring(0, x.length - 5);
    } else if (x.substring(x.length - 3, x.length) == "自治区") {
        var s = x.substring(0, x.length - 3);
    } else {
        var s = x;
    }
    return s
}
//特殊处理省级字段，取前两位
function getprovince(x){
    return x.substring(0,2)
}
//判断是否是单列市
function judgecity(x){
	let list = major.arr10;
	for(var i=0;i<list.length;i++){
		if(x==list[i].t){return true}
	}
	return false
}
//模态框
function showModal(json) {
    if (json.confirm == undefined || json.confirm == null || json.confirm == '') {
        json.confirm = function() {
            console.log('你点击了确定')
        }
    }
    if (json.cancel == undefined || json.cancel == null || json.cancel == '') {
        json.cancel = function() {
            console.log('你点击了取消')
        }
    }
    if (json.cancelText != undefined && json.cancelText != null && json.cancelText != ''){
        json.showCancel=true
    }
    wx.showModal({
        title: json.title || '',
        content: json.content,
        showCancel: json.showCancel || false,
        cancelText: json.cancelText || '取消',
        confirmText: json.confirmText || '确定',
        success: function(res) {
            if (res.confirm) {
                json.confirm()
            }
            if (res.cancel) {
                json.cancel()
            }
        }
    });
}
//提示框
function showToast(x,y){
    wx.showToast({
        title: x,
        icon: y || 'none'
    });
}
//取缓存
function getStorageSync(e) {
    console.log('get', e, wx.getStorageSync(e))
    return wx.getStorageSync(e)
}
//存缓存
function setStorageSync(e, v) {
    wx.setStorageSync(e, v)
    try {
        console.log('set', e, JSON.stringify(wx.getStorageSync(e)))
    } catch (e) {
        console.log('set', e, wx.getStorageSync(e))
    }
}
//打开webview
function webview(e){
    let a = encodeURIComponent(e)
    if(a!=''){
        wx.navigateTo({
            url: '/pages/webview/webview?url=' + a
        })
  } else {
    console.log('url为空')
  }
}
//打开webviewNew,签到有礼专用
function webviewNew(e) {
  let a = encodeURIComponent(e)
  if (a != '') {
    wx.navigateTo({
      url: '/pages/webviewNew/webviewNew?url=' + a
    })
  } else {
    console.log('url为空')
  }
}
//设置全局数据
function setglobalData(e, v) {
    if (app.globalData.hasOwnProperty(e)){
        app.globalData[e] = v;
        console.log('set globalData', e, app.globalData[e]);
    }else{
        app.globalData[e] = v;
        console.log('set new globalData', e, app.globalData[e]);
    }
}

module.exports = {
    Base64,
    decipher,
    showLoading,
    hideLoading,
    showModal,
    showToast,
    getStorageSync,
    setStorageSync,
    webview,
  webviewNew,
    setglobalData,
    getcity,
    getprovince,
    findlink,
	judgecity,
    getproandcity,
    findcode
}