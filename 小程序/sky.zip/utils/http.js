const app = getApp();
const $ = app.global;
// http
function request(k, params, loading, result, tokentrue) {//loading不需要时传false,需要时需传入组件,页面调用时别传tokentrue实参
    if (k.length == 0 || k == undefined || k == null || k == '') return;
    var url = k.url;
    var idx = url.indexOf('http://');
    var idx2 = url.indexOf('https://');
    if (idx == -1 && idx2 == -1) {url = $.HttpDomain + url}
    if (loading) { $.f.showLoading(loading)}
    var header = {'Content-Type': 'application/json'}
    if (app.globalData.authorization){header.Authorization = 'Bearer ' + app.globalData.authorization}
    console.log(url,'入参',JSON.stringify(params));
    wx.request({
        url: url,
        data: params,
        header:header,
        method: 'post',
        success: function (res) {
            if (res.statusCode == 200) {
                if (res.data.tokenError == '安全验证失败！') {//token失效重新获取
                    if (tokentrue=='tokentrue'){//已经失败过一次，又一次验证失败抛出异常
                        $.f.setglobalData('authorization', null)//重新置为null
                        if(loading){
                            $.f.showModal({content: '服务异常tokenerror，请稍后再试'})
                        }
                    } else { getToken(k, params, loading, result);}
                    return
                }
                console.log(url, '出参', res.data);
                result(res.data);
                if (loading) {$.f.hideLoading(loading)}
            } else {
                if (loading){
                    $.f.hideLoading(loading)
                    $.f.showModal({ content: '服务异常，请稍后再试' + res.statusCode})
                }
            }
        },
        fail: function (res) {
            console.log(res);
            if (loading){
                $.f.hideLoading(loading)
                $.f.showModal({content: '网络异常，请检查网络'})
            }
        },
    })
}
function getToken(k, params, loading, result){
    console.log('token失效重新获取-----');
    wx.request({
        url: $.HttpDomain + $.HttpURL.getToken.url,
        data:{},
        header: { 'Content-Type': 'application/json' },
        method: 'post',
        success: function (res) {
            $.f.setglobalData('authorization', res.data.token)
            request(k, params, loading, result,'tokentrue');
        },
        fail: function (res) {
            $.f.showModal({content: '服务异常，请稍后再试!'})
        },
    })
}
function uploadfile(params, filePath, result, progress) {//progress进度条。需要时需传入
    if (filePath.length == 0 || !result) return;
    var url = 'https://' + $.webSplatform + '/' + $.AppID + '/upload';
    console.log('上传入参', url, params, filePath);
    const uploadTask = wx.uploadFile({
        url: url,
        filePath: filePath,
        name: 'file',
        header: {'content-type': 'multipart/form-data'},
        formData: params,
        success: function (res) {
            if (res.statusCode == 200) {
                console.log('上传出参',res.data)
                result(JSON.parse(res.data));
            } else {
                $.f.showModal({content: '服务异常，请稍后再试' + res.statusCode})
            }
        },
        fail: function (e) {
            $.f.showModal({content: '网络异常，请检查网络' + e.statusCode})
        }
    })

    uploadTask.onProgressUpdate((res) => {
        console.log('上传进度', res.progress+'%')
        // console.log('已经上传的数据长度', res.totalBytesSent)
        // console.log('预期需要上传的数据总长度', res.totalBytesExpectedToSend)
        if (progress) {progress(res)}
    });
}

function bfd(actionname,obj) {//百分点埋点探头请求
    try{
        obj.appkey = $.bfdkey;
        obj.actionname = actionname;
        obj.openid = app.globalData.userOpenId;
        obj.random = new Date().getTime();
        if (!obj['uid']) {
            obj.uid = app.globalData.userUnionId || ''
        }
        wx.request({
            url: $.bfdurl,
            data: obj,
            header: {'Content-Type': 'application/json'},
            method: 'get',
            complete: function (res) {
                console.log('--bfd--',obj,res.data)
            },
        })
    }catch(e){}
}

module.exports = {
    request: request,
    uploadfile: uploadfile,
    getToken: getToken,
    bfd: bfd
}
