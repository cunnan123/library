var obj = {
    getOpenIdold: {
        url: 'wechatpageservice/programCustomer/login.do'
    }, // 获取openid--老
    getOpenId: {
        url: 'wechatpageservice/programCustomer/appopenidInsertOrUpdate.do'
    }, // 获取openid
    sendtranslate: {
        url: 'wechatpageservice/programCustomer/sendtranslate.do'
    }, // 视频客服评价
    getSession: {
        url: 'https://spkf.chinalife-p.com.cn/videocustomer/videoCustomer/getSession'//生产
        //url: 'https://wechattest.chinalife-p.com.cn/videocustomer/videoCustomer/getSession'//测试
    }, // 获取视频seeion
    getCheckCode: {
        url: 'wechatpageservice/programCustomer/getCheckCode.do'
    }, // 视频客服获取验证码
    oneWeather: {
        url: 'wechatpageservice/servicehall/oneWeather.do'
    }, // 首页天气接口
    oilprice: {
        url: 'wechatpageservice/servicehall/oilprice.do'
    }, // 首页油价接口
    querySliderInfo: {
        url: 'wechatpageservice/serviceHall/querySliderInfo.do'
    }, // 轮播图
    querySortedFunctions: {
        url: 'wechatpageservice/serviceHall/querySortedFunctions.do'
    }, // 功能图
    dataQuery: {
        url: 'wechatpageservice/DataQuery/getDataQueryaa.do'
    }, // 常见问题
    getPartyIDAction: {
        url: 'wechatpageservice/getPartyIDAction/getPartyIDAction.do'
    }, // 获取partyid
    getCustServiceLevelaa: {
        url: 'wechatpageservice/CustServiceLevel/getCustServiceLevelaa.do'
    }, // 获取客户等级
    locationSave: {
        url: 'wechatpageservice/location/locationSave.do'
    }, // 切换分公司
    locationQuery: {
        url: 'wechatpageservice/location/locationQuery.do'
    }, // 获取分公司
    queryProductList: {
        url: 'wechatpageservice/productManage/queryProductList.do'
    }, // 获取热销险种
    messageInfquery: {
        url: 'wechatpageservice/servicehall/MessageInfQuery.do'
    }, // 获取消息
    getMyBussinessCard: {
        url: 'wechatpageservice/myBussinessCardAction/getMyBussinessCard.do'
    }, // 获取名片列表
    desUnionId: {
        url: 'wechatpageservice/miniProgram/desUnionId.do'
    }, // 解密UnionId //解密接口
    desStringUserId: {
        url: 'wechatpageservice/selfhelp/desStringUserId.do'
    }, // 加密UnionId //加密接口
    updateUnionid: {
        url: 'wechatpageservice/programCustomer/updateUnionid.do'
    }, //回传用户unionID接口
    getBranchByMyLocation: {
        url: 'wechatpageservice/branchH5/getBranchByMyLocation.do'
    }, //查询5公里内距离最近的网点
    getBranchByPandC: {
        url: 'wechatpageservice/branchH5/getBranchByPandC.do'
    }, //根据省份与城市获取网点列表
    selbrlist: {
        url: 'wechatpageservice/branchH5/selbrlist.do'
    }, //根据模糊搜索查询网点
    exist: {
        url: 'wechatpageservice/valiCarUpload/exist.do'
    },//验车拍照查询车牌，投保单号接口
    getTodayCarCode: {
        url: 'wechatpageservice/valiCar/getTodayCarCode.do'
    },//获取到验车码
    validateCarUpload: {
        url: 'wechatpageservice/valiCar/validateCarUpload.do'
    },//图片上传调用接口
    valiCarUploadSubmit: {
        url: 'wechatpageservice/valiCar/valiCarUploadSubmit.do'
    },//点击确认上传
    checkResult: {
        url: 'wechatpageservice/valiCar/checkResult.do'
    },//检查上传车牌号信息
    Moving: {
        url: 'wechatpageservice/weather/Moving.do'
    },//展示定位天气动态信息
    TianQiYuBao: {
        url: 'wechatpageservice/weather/TianQiYuBao.do'
    },//调取天气预报接口
    mycity: {
        url: 'wechatpageservice/city/mycity.do'
    },//调取我的城市接口
    checkhotcity: {
        url: 'wechatpageservice/city/checkhotcity.do'
    },//热门城市
    DingYue: {
        url: 'wechatpageservice/weather/DingYue.do'
    },//订阅城市
    TuiDing: {
        url: "wechatpageservice/weather/TuiDing.do"
    },//退订城市
    checkcity: {
        url: "wechatpageservice/city/checkcity.do"
    },//查询城市
    queryPolicyInf: {
        url: 'wechatpageservice/ereceipt/queryPolicyInf.do'
    },//电子发票通过车牌号查询
    queryreceiptInf: {
        url: 'wechatpageservice/ereceipt/queryreceiptInf.do'
    },//保单列表页面保单号查询
    queryWholeReceiptInf: {
        url: 'wechatpageservice/ereceipt/queryWholeReceiptInf.do'
    },//点击查看全部
    queryRadioTypeURL: {
        url: "wechatpageservice/serviceRadio/queryRadioType.do"
    },//获取客服电台列表接口
    updateRadioTypeSubscribeURL: {
        url: "wechatpageservice/serviceRadio/updateRadioTypeSubscribe.do"
    },//改变订阅状态接口
    queryServiceRadioURL: {
        url: "wechatpageservice/serviceRadio/queryServiceRadio.do"
    },//获取音频列表接口
    getValidateCodeURL: {
        url: "wechatpageservice/validatePhone/getValidateCode.do"
    },//电商获取验证码
    getCheckCodeOneURL: {
        url: "wechatpageservice/bind/getCheckCode1.do"
    },//微信内部获取验证码
    checkValidateCodeURL: {
        url: "wechatpageservice/validatePhone/checkValidateCode.do"
    },//点击下一步验证验证码
    queryUserInfoByPhoneURL: {
        url: "wechatpageservice/userInfForApp/queryUserInfoByPhone.do"
    },//下一步验证码时根据手机号获取三要素
    bindWithQuestionURL: {
        url: "wechatpageservice/bind/bindWithQuestion.do"
    },//绑定接口
    queryProductAssort: {
        url: 'wechatpageservice/productManage/queryProductAssort.do'
    },//保险商城热门险种接口
    queryProductAllAssort: {
        url: 'wechatpageservice/productManage/queryProductAllAssort.do'
    },//保险商城导航条接口
    queryProductByAssort: {
        url: 'wechatpageservice/productManage/queryProductByAssort.do'
    },//保险商城险种列表接口
    policyInfoQuery: {
        url: 'wechatpageservice/query/getMyPolicyDetailInfByFourParameter.do'
    },//保单验真按保单号查询接口
    OthersPolicyQuery: {
        url: 'wechatpageservice/policy/OthersPolicyQuery.do'
    },//保单验真按车牌号查询接口
    CheckUserMatchThreeParameter: {
        url: 'wechatpageservice/query/CheckUserMatchThreeParameter.do'
    },//保单验真验证是否完全绑定
    checkpolicy: {
        url: 'wechatpageservice/electpolicy/check.do'
    },//保单验真中保单详情页查看电子保单接口
    getMyPolicyDetailInf: {
        url: 'wechatpageservice/query/getMyPolicyDetailInf.do'
    },//保单验真中按车牌号查询保单列表页获取保单详情接口
    sendToEmail: {
        url: 'wechatpageservice/policy/sendToEmail.do'
    },//保单验真中保单详情页发送电子保单到邮箱接口
    checkBindWithoutLimit: {
        url: 'wechatpageservice/bind/checkBindWithoutLimit.do'
    }, //不完全绑定接口
    checkBindWithLimit: {
        url: 'wechatpageservice/bind/checkBindWithLimit.do'
    }, //完全绑定接口
    paySYT: {
        url: 'wechatpageservice/prodectpay/saveProductPayData.do'
        // https://wechattest.chinalife-p.com.cn//
    },
    getToken: {
        url: 'wechatpageservice/Createtoken/creattoken.do'
    },//获取token.安全校验使用的
    shareCount: {
        url: 'wechatpageservice/miniProgramShareCount/miniProgramShareCountAction.do'
    },//分享统计接口
    paying: {//支付成功接口
      url: 'wechatpageservice/prodectpay/selpolicy.do'
      // https://wechattest.chinalife-p.com.cn/
    },
    pushmessage: {//推送消息接口
      url: 'wechatpageservice/prodectpay/sendtemp.do'
  },
	finishTask: { //登录认证接口
		url: 'wechatpageservice/integral/finishTask.do'
  },
	geterCode: { //获取验证码
		url: 'wechatpageservice/validatePhone/getValidateCode.do'
	},
	senderCode: { //获取验证码
		url: 'wechatpageservice/bind/getCheckCode1.do'
	},
	checkValidateCode: { //验证验证码
		url: 'wechatpageservice/validatePhone/checkValidateCode.do'
	},
	checkwxChatCode: { //验证验证码
		url: 'wechatpageservice/appeal/checkMessageAuthen.do'
	},
	bindPhone:{
		url:"wechatpageservice/integral/addUserInfo.do"
	},
	getphone: {
		url: "wechatpageservice/integral/queryUser.do"
	},
	querytask: {
		url: "wechatpageservice/integral/queryOwnToday.do"
	},
};
module.exports = obj;