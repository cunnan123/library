// pages/pay/payorder/payorder.js
const app = getApp();
const $ = app.global;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
        pid:"",
        ifdata: 0,//控制有数据的时候不显示，为空的时候显示
        myinterval:undefined,
        count:0,//控制调用的次数
        hasdata:1,//控制保单展示模块是否显示
        nodata:0,
        certi_no: "",//投保单号
        state:"",//支付状态
        res:{},
        product_name: "",//产品名称
        policy_person: "",//投保人
        prepay_id:"",//form_id
        paynum:"",//保费金额
    },
    payend:function(){
      var that=this;
      var loading = that.loading;
      let params = { "pid": that.data.pid }
      $.Http.request($.HttpURL.paying, params, false, function (res) {
        console.log("支付完成", res.result)
        var state = res.result.RESP_CODE==4?"成功":"失败"
        that.setData({
          state:state,
          res:res.result,
          paynum: res.result.TRANS_AMT/100+"元"
        })
        var num=that.data.count+1
        that.setData({
          count:num
        })
        console.log("调用次数",that.data.count)
        // if (res.result != "kong"){
        //   that.setData({
        //     ifdata: 0,//有数据的时候不显示订单生成中
        //     hasdata: 1,//保单详情模块展示
        //     nodata: 0,//未查到保单详情
        //   })
        //   console.log("有数据清除计时器")
        //   clearInterval(that.myinterval)
        // }else{
        //   that.setData({
        //     ifdata: 0,//为空的时候显示订单生成中的loading
        //     hasdata: 0,//保单详情模块隐藏
        //     nodata: 1,//未查到保单详情
        //   })
        // }
        if(res.result=="kong"){
          that.setData({
            ifdata:1,//为空的时候显示订单生成中的loading
            hasdata:0,//保单详情模块隐藏
            nodata: 0,//未查到保单详情
          })
        }else{
          that.setData({
            ifdata: 0,//有数据的时候不显示订单生成中
            hasdata: 1,//保单详情模块展示
            nodata: 0,//未查到保单详情
          })
          console.log("有数据清除计时器")  
          clearInterval(that.myinterval)   
          that.getmessage(res.result)//调用推送消息函数 
          // that.getmessage()//调用推送消息函数
        }



        if (that.data.count >= 6) {//如果调用了5次以上，清除计时器不再调用
          clearInterval(that.myinterval)
          that.setData({
            nodata: 1,
            ifdata: 0,
            hasdata: 0
          })
        }
        if (that.data.count >= 6 && res.result == "kong"){//如果调用了5次以上而且也没查到数据，清除计时器，展示未查到保单详情
          clearInterval(that.myinterval)
          that.setData({
            nodata:1,
            ifdata:0,
            hasdata:0
          })
          // that.getmessage()//调用推送消息函数
        }
      })
    },
    getdata:function(){//每隔5秒调用一次获取保单数据
      var that=this;
      that.myinterval=setInterval(()=>{
        that.payend()        
      },5000)
    },
    goback:function(){//点击返回按钮
      // var that=this;
      var arr=$.major.arr
      arr.forEach(function(e){
        if (e.text =="保险商城"){
          // if (e.currentTarget.dataset.id == '0006') { //产品仓库
            let aurl = e.link;
            if (app.globalData.address == null && app.globalData.addressls == null) {//未定位,未选择让用户选择
              this.showactionsheet();
            } else if (app.globalData.address == null && app.globalData.addressls != null) {//未定位, 已选择
              
              let n = app.globalData.userOpenId
              let cc = app.globalData.addressls;
              let a = cc[0].code;
              let b = cc[1].code;
              let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b;
              $.f.webview(url);
            } else {//定位的情况
              let cc = app.globalData.address.ad_info.adcode;
              let n = app.globalData.userOpenId;
              let c = cc.substring(0, 2) + '0000';
              let x = cc.substring(0, 4) + '00';
              let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x;
              $.f.webview(url)
            }
            return
          // }
        }
      })

      
    },
    getmessage:function(x){//推送消息
      var that=this;
      let params={
        "openid": app.globalData.userOpenIds,
        "page":"pages/index/index",
        "form_id": that.data.prepay_id,//that.data.prepay_id,
        //"wx1715513507900695a97ef54a1845551800"
        "keyword1value": that.data.product_name,//that.data.product_name,//保险名称
        "keyword2value": x.POLICY_NO,//x.POLICY_NO,//保单号
        "keyword3value": that.data.policy_person,//that.data.policy_person,//投保人
        "keyword4value": that.data.paynum,//x.TRANS_AMT,//保费金额
        //"keyword5value":"",//生效时间
        "firstvalue":"",
        "keyword01value":"",
        "keyword02value":"",
        "remark":""
      }
      $.Http.request($.HttpURL.pushmessage, params, false,function(res){
        console.log("推送消息成功")
      })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      console.log(options)
      this.loading = this.selectComponent("#loading");
      let openids = app.globalData.userOpenIds
      console.log("openid", openids)
      var that=this;
      var lastpid = options.pid
      var certino=options.certi_no
      var product_name = options.product_name
      var policy_person = options.policy_person
      var prepay_id = options.form_id
      that.setData({
        ifdata:1,
        hasdata:0,
        nodata:0,
        pid:lastpid,
        certi_no: certino,//投保单号
        product_name: product_name,//产品名称
        policy_person: policy_person,// 投保人
        prepay_id: prepay_id,//form_id
      })
      // that.mytimeout=setTimeout(()=>{
      //   that.payend()
      // },5000)
            
      if (that.data.count < 6){
        that.getdata()
      } else if (that.data.count >= 6) {//如果调用了5次以上，清除计时器不再调用
        clearInterval(that.myinterval)
      }
      
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})