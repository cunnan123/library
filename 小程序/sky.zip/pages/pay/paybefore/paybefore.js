// pages/pay/paybefore/paybefore.js
const app = getApp();
const $ = app.global;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        param:null,
        pid:"",
        certi_no:"",//投保单号
        product_name: "",//产品名称
        policy_person: "",// 投保人
        form_id:"",//preypay_id
        sharePerson:"",//分享人
    },
    /**
     * 发起支付请求
     */
    paybefore: function () {
        let _this = this;
        let loading = this.loading;
        // let params = {
        //     'pid': '', //统一查询码，即业务流水号
        //     'transamt': '1', //金额单位分
        //     'insurinfo': [{
        //         'certi_no': '',//投保单号
        //         'price': ''
        //     }],
        //     'openid': app.globalData.userOpenId, //授权用户的openid
        // }


        let params = _this.data.param;
        params.openid = app.globalData.userOpenId; //授权用户的openid
        $.Http.request($.HttpURL.paySYT, params, loading, function (res) {
          console.log("入参",params)
            console.log("支付",res.result)
            _this.setData({
              pid:res.result.pid,
              form_id: res.result.package1.split("=")[1]
            })
            _this.pay(res.result);
        })
    },
    // getsubscribeMessage: function () {//调起订阅消息
    //   console.log("哈哈哈")
    //   wx.requestSubscribeMessage({
    //     tmplIds: ['FHIEU2BtQDXcIR9exrX2gwfpMaWny0xwfBEBFv0ycQk'],
    //     success(res) {
    //       console.log("订阅消息", res)
    //     },
    //     fail(res){
    //       console.log("订阅消息失败")
    //     }
    //   })
    // },
    /**
     * 发起支付
     */
    pay:function(x){
      var that=this;
        wx.requestPayment({
            "package": x.package1,
            "appId": x.appid,
            "timeStamp": x.timeStamp,
            "signType": x.signType,
            "nonceStr": x.nonceStr,
            "paySign": x.paySign,
            success(res) {
                console.log("支付成功")
                var subscribetype="";//订阅消息状态--1代表允许-——0代表不允许——2代表接口失败fail
                wx.requestSubscribeMessage({
                  tmplIds: ['FHIEU2BtQDXcIR9exrX2gwfpMaWny0xwfBEBFv0ycQk'],
                  success(res) {
                    console.log("订阅消息返参", res)
                    if (res["FHIEU2BtQDXcIR9exrX2gwfpMaWny0xwfBEBFv0ycQk"]  ==  "accept"){//用户允许订阅消息
                      var subscribetype="1";//允许订阅
                      console.log("用户允许订阅")
                      //跳转
                      wx.navigateTo({
                        url: `/pages/pay/payorder/payorder?pid=${that.data.pid}&certi_no=${that.data.certi_no}&product_name=${that.data.product_name}&policy_person=${that.data.policy_person}&form_id=${that.data.form_id}&subscribetype=${subscribetype}`,
                      })
                    } else if (res["FHIEU2BtQDXcIR9exrX2gwfpMaWny0xwfBEBFv0ycQk"] == "reject"){//不允许订阅
                      var subscribetype="0";//不允许订阅
                      console.log("用户不允许订阅")
                      //跳转
                      wx.navigateTo({
                        url: `/pages/pay/payorder/payorder?pid=${that.data.pid}&certi_no=${that.data.certi_no}&product_name=${that.data.product_name}&policy_person=${that.data.policy_person}&form_id=${that.data.form_id}&subscribetype=${subscribetype}`,
                      })
                    }
                  },
                  fail(res) {
                    console.log("订阅消息失败")
                    var subscribetype = "2";//不允许订阅
                    wx.navigateTo({
                      url: `/pages/pay/payorder/payorder?pid=${that.data.pid}&certi_no=${that.data.certi_no}&product_name=${that.data.product_name}&policy_person=${that.data.policy_person}&form_id=${that.data.form_id}&subscribetype=${subscribetype}`,
                    })
                  }
                })
            },
            fail(res) {
              console.log("支付失败",x)
                console.log(that.data.pid)
                // wx.navigateTo({
                //url:`/pages/pay/payorder/payorder?pid=${that.data.pid}&certi_no=${that.data.certi_no}&product_name=${that.data.product_name}&policy_person=${that.data.policy_person}&form_id=${that.data.form_id}`,
                // })
                wx.navigateBack({
                  delta: 1
                })
            }
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(options)
        this.loading = this.selectComponent("#loading");
        // let openids = app.globalData.userOpenIds
        // console.log("openid", openids)
        let a = JSON.parse(decodeURIComponent($.f.Base64.atob(options.param)))
        console.log(a)
        this.setData({
          param: a
        })
        this.setData({
          certi_no: a.insurinfo[0].certi_no,//投保单号
          product_name: a.product_name,//产品名称
          policy_person: a.policy_person,// 投保人
          sharePerson: a.sharePerson//分享人
        })
        console.log("第一个接口入参",this.data.param);
        console.log("投保单号",this.data.certi_no)
        this.paybefore();


        //开始改动联调
        // let data = { "result": { "timeStamp": "1565592078790", "paySign": "9NWHZYJEDWHDOQUU9MWWOW==", "appid": "wxa6cda9559941b008", "resp_code": "0000", "signType": "MD5", "pid": "2088000990000000090999", "package1": "prepay_id=wx05104248714515455939ba8e3373095955", "resp_msg": "系统发生异常，请稍后再试。", "nonceStr": "JFGEDYQBLLVMJHJNBTNMEXYGFDYSOPYU" } }
        // this.pay(data.result);
        //改动数据
    //   let data = {
    //     "result": { "package1": "prepay_id=wx2317262758501913b54b09b01358341400", "timeStamp": "1569230757732", "trans_id": "gbgswx20190923620020", "signType": "MD5", "resp_code": "0000", "appid": "wxa6cda9559941b008", "nonceStr": "URYFAGETZHWSKQJMNAAMNITCELGOIYFD", "pid": "fc20190923155426857e301efc2174cd", "paySign": "233E13C0B69D87DE269F362FA4B4F9C8" }
    // }
    // this.pay(data.result);
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})