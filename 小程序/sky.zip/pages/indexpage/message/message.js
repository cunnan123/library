// pages/indexpage/message/message.js
const app = getApp();
const $ = app.global;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
        messagelist:[],
        isno:false,//无新消息的提示
    },
    messagesHandle:function(t){//送回修消息处理
        let obj={};
        let t1 = t.split('***');
        obj.s0 = t1[0].split('：')[0];
        obj.s1 = { a: (t1[1].split('：')[0]).replace('名称',''), b: t1[1].split('：')[1] };
        obj.s2 = { a: t1[2].split('：')[0], b: t1[2].split('：')[1] };
        obj.s3 = { a: t1[3].split('：')[0], b: t1[3].split('：')[1] };
        obj.s4 = { a: (t1[4].split('：')[0]).replace('姓名', ''), b: t1[4].split('：')[1] };
        obj.s5 = { a: t1[5].split('：')[0], b: t1[5].split('：')[1] };
        obj.s6 = t1[6];
        return obj
    },
    getmessages:function(){//获取用户消息
        let _this = this;
        let id = app.globalData.userUnionId
        if (id == '' || id == 'null' || id == 'false' || id == 'none'){
            _this.setData({
                isno: true
            })
            return
        }
        let params = {
            openId: id
        };
        let loading = this.selectComponent("#loading");
        $.Http.request($.HttpURL.messageInfquery, params, loading, function (res) {
            if (res.mount=='0'){
                _this.setData({
                    isno:true
                })
                return
            }
            let list1 = res.info;
            let list = list1.filter(function(item){//过滤掉不是送回修的东西。
                return item.sendcontent.indexOf('已成功推荐送修')!=-1;
            })
            for(let i = 0;i<list.length;i++){
                list[i].sendcontent = _this.messagesHandle(list[i].sendcontent)
            }
            console.log(list);
            _this.setData({
                messagelist: list
            })
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.getmessages()
        // var _this = this;
        // let list1 = _this.data.message;
        // let list = list1.filter(function(item){//过滤掉不是送回修的东西。
        //     return item.sendcontent.indexOf('已成功推荐送修')!=-1;
        // })
        // for(let i = 0;i<list.length;i++){
        //     list[i].sendcontent = _this.messagesHandle(list[i].sendcontent)
        // }
        // console.log(list);
        // this.setData({
        //     messagelist: list
        // })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})