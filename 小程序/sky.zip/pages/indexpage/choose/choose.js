// pages/indexpage/choose/choose.js
const app = getApp();
const $ = app.global;
Page({
    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
        addresscompany:'',//显示的当前公司
        scrollviewheight: $.getSys.windowHeight*2-330,//滚动容器高度
        addresslist: [{
                "company": "中国人寿财险服务大厅"
            }, {
                "company": "北京市分公司"
            }, {
                "company": "天津市分公司"
            }, {
                "company": "河北省分公司"
            }, {
                "company": "山西省分公司"
            }, {
                "company": "内蒙古自治区分公司"
            },
            {
                "company": "辽宁省分公司"
            }, {
                "company": "大连市分公司"
            }, {
                "company": "吉林省分公司"
            }, {
                "company": "黑龙江省分公司"
            }, {
                "company": "上海市分公司"
            }, {
                "company": "江苏省分公司"
            },
            {
                "company": "浙江省分公司"
            }, {
                "company": "宁波市分公司"
            }, {
                "company": "安徽省分公司"
            }, {
                "company": "福建省分公司"
            }, {
                "company": "厦门市分公司"
            }, {
                "company": "江西省分公司"
            },
            {
                "company": "山东省分公司"
            }, {
                "company": "青岛市分公司"
            }, {
                "company": "河南省分公司"
            }, {
                "company": "湖北省分公司"
            }, {
                "company": "湖南省分公司"
            }, {
                "company": "广东省分公司"
            },
            {
                "company": "深圳市分公司"
            }, {
                "company": "广西壮族自治区分公司"
            }, {
                "company": "海南省分公司"
            }, {
                "company": "重庆市分公司"
            }, {
                "company": "四川省分公司"
            }, {
                "company": "贵州省分公司"
            },
            {
                "company": "云南省分公司"
            }, {
                "company": "陕西省分公司"
            }, {
                "company": "甘肃省分公司"
            }, {
                "company": "青海省分公司"
            }, {
                "company": "宁夏省分公司"
            }, {
                "company": "新疆自治区分公司"
            }, {
                "company": "西藏自治区分公司"
            }
        ],
        addresslist2: [{
            "company": "中国人寿财险服务大厅"
        }, {
            "company": "北京市分公司"
        }, {
            "company": "天津市分公司"
        }, {
            "company": "河北省分公司"
        }, {
            "company": "山西省分公司"
        }, {
            "company": "内蒙古自治区分公司"
        },{
            "company": "辽宁省分公司"
        }, {
            "company": "大连市分公司"
        }, {
            "company": "吉林省分公司"
        }, {
            "company": "黑龙江省分公司"
        }, {
            "company": "上海市分公司"
        }, {
            "company": "江苏省分公司"
        },{
            "company": "浙江省分公司"
        }, {
            "company": "宁波市分公司"
        }, {
            "company": "安徽省分公司"
        }, {
            "company": "福建省分公司"
        }, {
            "company": "厦门市分公司"
        }, {
            "company": "江西省分公司"
        },{
            "company": "山东省分公司"
        }, {
            "company": "青岛市分公司"
        }, {
            "company": "河南省分公司"
        }, {
            "company": "湖北省分公司"
        }, {
            "company": "湖南省分公司"
        }, {
            "company": "广东省分公司"
        },{
            "company": "深圳市分公司"
        }, {
            "company": "广西壮族自治区分公司"
        }, {
            "company": "海南省分公司"
        }, {
            "company": "重庆市分公司"
        }, {
            "company": "四川省分公司"
        }, {
            "company": "贵州省分公司"
        },{
            "company": "云南省分公司"
        }, {
            "company": "陕西省分公司"
        }, {
            "company": "甘肃省分公司"
        }, {
            "company": "青海省分公司"
        }, {
            "company": "宁夏省分公司"
        }, {
            "company": "新疆自治区分公司"
        }, {
            "company": "西藏自治区分公司"
        }],
    },
    addressInput:function(e){//输入监听
        if (e.detail.value==''){
            this.setData({
                addresslist: this.data.addresslist2
            })
        }else{
            var a = this.data.addresslist2;
            var b;
            b = a.filter(function (item) {
                return (item.company).indexOf(e.detail.value) !=-1
            })
            this.setData({
                addresslist: b
            })
        }
    },
    clickaddress:function(e){
        var a = e.currentTarget.dataset.text;
        if (a == this.data.addresscompany){
            $.f.showModal({
                'content': '尊敬的客户，您选择的地区和您投保的分公司所在地区一致，不能重复选择，谢谢！'
            })
            return
        }
        var obj = {
            content:'尊敬的客户，您所在的位置发生改变，请选择是否切换到 '+a+'？',
            cancelText:'取消',
            confirmText:'切换',
            confirm:function(){
                let params2
                if (true) {
                    let id = app.globalData.userOpenIds;//用户小程序OpenId-加密
                    if (a == '中国人寿财险服务大厅') {
                        params2 = {
                            openId: id,
                            company: '总公司',
                            comcode: '00000000',
                            province: '',
                            city: ''
                        }
                    } else {
                        params2 = {
                            openId: id,
                            company: '',
                            comcode: '',
                            province: a.substring(0, 2),
                            city: a.substring(0, 2)
                        }
                    }
                    $.Http.request($.HttpURL.locationSave, params2, false, function (res) {
                        let comcodeandcompany = {
                            comcode: res.result.comcode,
                            company: res.result.company,
                        }
                        $.f.setglobalData('comcodeandcompany', comcodeandcompany)
                        $.f.setglobalData('iscomcodetype', true)
                        wx.switchTab({
                            url: '/pages/index/index',
                        })
                    })
                    return
                }
            }
        }
        $.f.showModal(obj)
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let addresscompany = '';
        if (app.globalData.comcodeandcompany.company == '总公司') {
            addresscompany = '中国人寿财险服务大厅'
        } else {
            addresscompany = app.globalData.comcodeandcompany.company
        }
        this.setData({
            addresscompany: addresscompany
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})