// pages/indexpage/more/more.js
const app = getApp();
const $ = app.global;
Page({
    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
        majors: $.major.arr,
        proandcityrank: '2',//地区选择组件层级
        sharePerson: "",//从分享进入小程序的unionid
    },

    gowebview: function (e) { //打开webview
        var _this = this;
        try {
            $.Http.bfd('service_hall_button_click', {
                "button_name": e.currentTarget.dataset.t,
                "button_iid": e.currentTarget.dataset.id,
                "button_comCode": '00000000',
                "button_root": '1',
            })
        } catch (e) { }
        let aurl = $.f.findlink(e.currentTarget.dataset.id);
        if (e.currentTarget.dataset.id == '0077') { //反欺诈
            if (aurl.indexOf('state=appeal') > 0) {
                aurl = aurl.replace('state=appeal', 'state=kzfwxcx')
            }
            let a = encodeURIComponent(aurl)
            wx.reLaunch({
                url: '/pages/webview/webview?url=' + a
            })
            return
        }
        if (e.currentTarget.dataset.id == '0036') { //买车险
            let a = '110000';
            let b = '110100';
            let userid = app.globalData.userOpenId;
            try {
                a = (app.globalData.address.ad_info.adcode).substring(0, 2) + '0000';
                b = (app.globalData.address.ad_info.adcode).substring(0, 4) + '00';
            } catch (e) {}
            let link = $.producturllink + '/carInsure/html/homePagetest.html?Userid=' + userid + '&Userrole=4&Syssource=2002000&TransID=' + $.transID + '&Profitcode=&Activitycode=&TransCode=019060517170000744598c5eaee3dea2&TransType=000001&region=undefined&province=' + a + '&city=' + b + '&shareId1=&shareId2=&skinColor=&isSeat=0&time=' + new Date().getTime();
            $.f.webview(link);
            return
        }
        if (e.currentTarget.dataset.id == '0083') { //证件更新
          let addr = app.globalData.address;
          let lat = '39.46560';
          let lng = '116.19495';
          if (addr) {
            lat = addr.location.lat;
            lng = addr.location.lng;
          }
          if (aurl.indexOf('state=appeal') > 0) {
            aurl = aurl.replace('state=appeal', 'state=' + lat + '_' + lng);
          }
          $.f.webview(aurl);
          return
        }
        if (e.currentTarget.dataset.id == '0003') { //查理赔跳小程序
            wx.navigateToMiniProgram({
                appId: $.glappid2,
                path: '',
                extraData: {

                },
                success(res) {
                    console.log(res)
                },
                fail(res) {
                    console.log(res)
                },
            })
            return
        }
        if (e.currentTarget.dataset.id == '0056') { //祝福家跳小程序
            wx.navigateToMiniProgram({
                appId: $.glappid3,
                path: '',
                extraData: {

                },
                success(res) {
                    console.log(res)
                },
                fail(res) {
                    console.log(res)
                },
            })
            return
        }

        if (e.currentTarget.dataset.id == '0006') { //产品仓库
          if (app.globalData.address == null && app.globalData.addressls == null) {//未定位,未选择让用户选择
            this.showactionsheet();
          } else if (app.globalData.address == null && app.globalData.addressls != null) {//未定位, 已选择
            let aurl = $.f.findlink('0006');
            let n = app.globalData.userOpenId
            let cc = app.globalData.addressls;
            let a = cc[0].code;
            let b = cc[1].code;
            if (app.globalData.iffenxiang == 1) {//说明是分享进入的unionid
              let params = { "unionId": app.globalData.myshares }
              $.Http.request($.HttpURL.desUnionId, params, false, function (res) {
                console.log(res)
                var shareperson = "FX" + res.unionIdRes
                $.f.setglobalData("fenxiangsharePerson", shareperson)
                let sharePerson = app.globalData.fenxiangsharePerson
                console.log("商城分享人", sharePerson)
                // _this.setData({
                //   sharePerson: sharePerson
                // })
                let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson;
                $.f.webview(url);
              })
            } else {
              //直接在小程序打开的unionid
              let params = { "unionId": app.globalData.userUnionId }
              $.Http.request($.HttpURL.desUnionId, params, false, function (res) {
                console.log(res)
                var sharePerson = res.unionIdRes
                console.log("商城直接点击", sharePerson)
                // _this.setData({
                //   sharePerson: sharePerson
                // })
                let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson;
                $.f.webview(url);
              })
            }
          } else {//定位的情况
            let cc = app.globalData.address.ad_info.adcode;
            let n = app.globalData.userOpenId;
            let c = cc.substring(0, 2) + '0000';
            let x = cc.substring(0, 4) + '00';
            if (app.globalData.iffenxiang == 1) {//说明是分享进入的unionid
              let params = { "unionId": app.globalData.myshares }
              $.Http.request($.HttpURL.desUnionId, params, false, function (res) {
                console.log(res)
                var shareperson = "FX" + res.unionIdRes
                $.f.setglobalData("fenxiangsharePerson", shareperson)
                let sharePerson = app.globalData.fenxiangsharePerson
                console.log("商城分享人", sharePerson)
                // _this.setData({
                //   sharePerson: sharePerson
                // })
                let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x + "&sharePerson=" + sharePerson;
                $.f.webview(url);
              })
            } else {
              //直接在小程序打开的unionid
              let params = { "unionId": app.globalData.userUnionId }
              $.Http.request($.HttpURL.desUnionId, params, false, function (res) {
                console.log(res)
                var sharePerson = res.unionIdRes
                console.log("商城直接点击", sharePerson)
                // _this.setData({
                //   sharePerson: sharePerson
                // })
                let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x + "&sharePerson=" + sharePerson;
                $.f.webview(url);
              })
            }
          }
          return
        }
        
        if (e.currentTarget.dataset.id == '0009') { //网点查询
            if (app.globalData.address == null) {
                aurl = aurl + 'lat=39.908419&lng=116.397572'; //默认天安门
                $.f.webview(aurl)
            } else {
                let c = app.globalData.address.location.lat
                let x = app.globalData.address.location.lng
                aurl = aurl + 'lat=' + c + '&lng=' + x
                $.f.webview(aurl)
            }
            return
        }
        if (e.currentTarget.dataset.id == '0100') { //天气提醒
            if (app.globalData.address == null) {
                aurl = aurl + '北京#wechat_redirect'; //默认北京天气
                $.f.webview(aurl)
            } else {
                let a = $.f.getcity(app.globalData.address.ad_info.city);
                aurl = aurl + a + '#wechat_redirect'
                $.f.webview(aurl)
            }
            return
        }
      if (e.currentTarget.dataset.id == '0023') { //道路救援
        let aurl = $.f.findlink('0023');
        var params = app.globalData.userId + '_' + app.globalData.userPhone
        var link = aurl.replace('appeal', params)
        $.f.webview(link);
        return
      }
        $.f.webview(aurl)
    },
    showactionsheet: function () {//选择地区组件显示
        this.proandcity.show();
    },
    _confirmproandcity(e) {//选择地区组件确认事件
        $.f.setglobalData('addressls', e.detail);//存储选择的临时位置
        let aurl = $.f.findlink('0006');
        let n = app.globalData.userOpenId;
        let cc = app.globalData.addressls;
        let a = cc[0].code;
        let b = cc[1].code;
        let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b;
        $.f.webview(url);
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        this.proandcity = this.selectComponent("#proandcity");
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})