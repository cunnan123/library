// pages/mine/mine.js
const app = getApp();
const $ = app.global;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgurl: $.imgurl,
    userInfo: null,
    name: '',
    level: { //客户等级
      a: '普通',
      b: 'mybackgp',
      c: '#2F99E9'
    },
    score: "",
    signShowMy: false, //我的页面签到礼品
    isRead: false,
    codeText: '获取验证码', //获取验证码
    userPhone: "", //用户手机号
    code: "", //验证码
    phoneWindowShowMy: false, //手机号输入弹窗显示
    score: 0, //获得安心豆的数量
    unionId: "",
    codeState: false,
    userPhoneInput: "",
    signPut: true,
    prizeTest: false, //我的奖品验证框展示
  },
  gowebview: function(e) { //打开webview
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": e.currentTarget.dataset.t,
        "button_iid": e.currentTarget.dataset.id,
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    let aurl = $.f.findlink(e.currentTarget.dataset.id);
    $.f.webview(aurl)
    console.log(aurl)
    console.log($.f.findlink())
  },
  gowebviewgr: function(e) { //打开webview
    if (e.currentTarget.dataset.text == '前往验证') {
      let aurl = $.f.findlink('0040');
      $.f.webview(aurl)
    }
  },
  getUserInfo: function(e) {
    var _this = this;
    if (e.detail.errMsg == "getUserInfo:ok") {
      console.log(e)
      var data = $.f.decipher(e.detail.encryptedData, e.detail.iv)
      $.f.setglobalData('userInfo', data)
      _this.setData({
        userInfo: app.globalData.userInfo
      })
    } else {
      console.log('用户拒绝了授权')
    }
  },
  tel: function() { //拨打电话
    wx.makePhoneCall({
      phoneNumber: $.tel,
    })
  },
  getMyBussinessCard: function() { //获取客户名片列表
    let _this = this;
    let id = app.globalData.userUnionId
    if (id == 'null' || id == '' || id == 'false' || id == 'none') {
      return
    }
    let params = {
      openid: '',
      unionid: id
    };
    $.Http.request($.HttpURL.getMyBussinessCard, params, false, function(res) {
      let partyId;
      let name;
      try {
        let data = res.result;
        if (data.length == 0) {
          return
        }
        partyId = data[0].party_id;
        name = data[0].name;
        for (let i = 0; i < data.length; i++) {
          if (data[i].relation == '1') {
            partyId = data[i].party_id;
            name = data[i].name;
            break
          }
        }
        if (name != '' && name != undefined && name != null) { //查出来姓名就存一下先
          $.f.setglobalData('userName', name);
          $.f.setStorageSync('userName', name);
        }
        if (partyId != '' && partyId != undefined && partyId != null) {
          _this.getcustomerlevel(partyId)
        }
      } catch (e) {}
    })
  },
  getcustomerlevel: function(x) { //获取客户等级
    let _this = this;
    let params = { //partyId
      partyId: x
    };
    $.Http.request($.HttpURL.getCustServiceLevelaa, params, false, function(res) {
      let b = res.service_level;
      if (b != '') {
        if (b == '钻石卡') {
          _this.setData({
            level: {
              a: '钻石',
              b: 'mybackgz',
              c: '#333'
            },
          })
        }
        if (b == '金卡') {
          _this.setData({
            level: {
              a: '金卡',
              b: 'mybackgj',
              c: '#FFA11A'
            },
          })
        }
        if (b == '银卡') {
          _this.setData({
            level: {
              a: '银卡',
              b: 'mybackgy',
              c: '#999999'
            },
          })
        }
        if (b == '贵宾') {
          _this.setData({
            level: {
              a: '贵宾',
              b: 'mybackgg',
              c: '#BF323A'
            },
          })
        }
      }
    })
  },
  //点击签到有礼
  signClick: function() {
    //判断手机号是否存在
    const _this = this;
    if (app.globalData.userPhone == "") {
      //没有输入手机号,显示输入框
      _this.setData({
        phoneWindowShowMy: true
      })
    } else {
      //跳转到首页
      if (!_this.data.signPut) return
      _this.data.signPut = false
      _this.setData({
        userPhone: app.globalData.userPhone
      })
      let aurl = $.f.findlink('00001');
      // var params = 'xcx' + '%' + this.data.userPhone + '%' + app.globalData.userUnionId + '%' + app.globalData.userOpenId + '%' + '1'
      var params = this.data.userPhone + '_' + app.globalData.userId
      var link = aurl.replace('appeal', params)
      $.f.webviewNew(link);
      setTimeout(function() {
        _this.data.signPut = true
      }, 2000)
    }
  },
  //签到有礼
  closeSign: function(e) { //关闭弹窗
    var state = e.currentTarget.dataset.state
    const _this = this;
    _this.setData({
      [state]: false
    })
    $.f.setglobalData('signShowMy', false)
  },
  //获取手机号
  phoneInput: function(e) {
    this.setData({
      userPhoneInput: e.detail.value
    })
  },
  //获取输入的验证码
  codeInput: function(e) {
    this.setData({
      code: e.detail.value
    })
  },
  // 验证手机号
  checkPhone: function(e) {
    const _this = this
    const reg = /^(13|15|18|14|17|16|19)\d{9}$/
    const phone = _this.data.userPhoneInput * 1
    if (!reg.test(phone)) {
      $.f.showModal({
        'content': '请输入正确的手机号'
      })
      return false
    }
    return true
  },
  //请求获取验证码接口
  getCode: function() {
    const _this = this
    console.log("输入验证码")
    if (!_this.data.codeState) {
      _this.setData({
        codeState: true
      })
    }
    // 如果正在倒计时
    if (typeof this.data.codeText === 'number') return
    // 验证手机号
    if (_this.checkPhone() === false) return
    // 获取验证码倒计时
    this.setData({
      codeText: 60
    })
    var timer = setInterval(function() {
      _this.setData({
        codeText: --_this.data.codeText
      })
      if (_this.data.codeText === 0) {
        _this.setData({
          codeText: '获取验证码'
        })
        clearInterval(timer)
      }
    }, 1000)
    let params = {
      phoneNumber: _this.data.userPhoneInput
    };
    $.Http.request($.HttpURL.geterCode, params, false, function(res) {
      if (res.requestTime == "1") {
        $.f.showModal({
          'content': '尊敬的客户，您获取验证码的频率过高，请稍后获取！'
        })
        return;
      }
      _this.setData({ //电商可以验证码
        checkInfo_type: 0
      })
      if (res.getValidateCode1.respCode == "01") {
        console.log("电商可以验证码1")
        wx.showToast({
          title: '已发送',
        })
        _this.setData({
          validateCodeType: "01" //注册调用成功
        })
        //验证码倒数函数
      } else if (res.getValidateCode1.respCode == "10") {
        //电商不能获取验证码
        that.setData({
          checkInfo_type: 1
        })
        console.log("电商不能验证码1，即将走微信内部验证码")
        _this.sentErCode(); //微信内部获取验证码
      } else {
        if (res.getValidateCode2.respCode == "01") {
          $.f.showModal({
            'content': '手机验证码已经发出！'
          })
          _this.setData({ //登录调用成功
            validateCodeType: "02"
          })
          console.log("电商可以验证码2")

          //验证码倒数函数
        } else {
          if (res.getValidateCode1.respCode == "10" || res.getValidateCode1.respCode == "49" ||
            res.getValidateCode2.respCode == "10" || res.getValidateCode2.respCode == "49") {
            //电商获取不到验证码
            _this.setData({
              checkInfo_type: 1 //登录调用成功
            })
            console.log("电商不能获取验证码2，即将走微信")
            _this.sentErCode(); //微信内部获取验证码
          } else {
            $.f.showModal({
              'content': '发送验证码失败，请稍后再次获取！'
            })
          }
        }
      }
    })
  },
  //微信内部获取验证码
  sentErCode: function() {
    let _this = this;
    let params = {
      open_id: app.globalData.userOpenIds,
      mobile_Phone: _this.data.userPhoneInput
    }
    $.Http.request($.HttpURL.senderCode, params, false, function(res) {
      if (res.result == "1") {
        wx.showToast({
          title: '已发送',
        })
        _this.setData({
          checkInfoPhone: _this.data.userPhoneInput
        })
        //验证码倒数
      } else if (res.result == "2") {
        $.f.showModal({
          'content': '尊敬的客户，您获取验证码的频率过高，请稍后获取！'
        })
      } else {
        $.f.showModal({
          'content': '发送手机验证码失败，请重新获取！'
        })
      }
    })
  },
  //点击开启，发送验证接口
  cheackCode: function() {
    //验证手机号
    const _this = this;
    if (!_this.data.codeState) {
      //还未获取验证码
      $.f.showModal({
        'content': '请先获取验证码'
      })
      return
    }
    if (_this.checkPhone() === false) return
    if (_this.data.code == "") {
      $.f.showModal({
        'content': '请输入验证码'
      })
      return
    }
    if (!_this.data.isRead) {
      $.f.showModal({
        'content': '请阅读活动规则'
      })
      return
    }
    //调用验证接口,如果成功则展示成功
    let params = {
      phoneNumber: _this.data.userPhoneInput,
      validateCode: _this.data.code,
      validateCodeType: _this.data.validateCodeType
    }

    if (this.data.checkInfo_type == 0) {
      //电商发送的验证码，发送接口校验电商的验证码
      $.Http.request($.HttpURL.checkValidateCode, params, false, function(res) {
          //校验接口，如果通过了，将手机号的值存在全局，并且展示弹出的跳转路径的页面
          var data = JSON.parse(decodeURIComponent($.f.Base64.atob(res.result)));
          if (data.checkValidateCode1.respCode == "01") {
            _this.setData({
              phoneWindowShowMy: false,
              userPhoneInput: data.phoneNumber,
              userPhone: data.phoneNumber
            })
            $.f.setglobalData('userPhone', data.phoneNumber)
            _this.checkLogin()
            _this.bindPhone()
          } else {
            $.f.showModal({
              'content': '验证未通过，请重新验证！'
            })
          }
      })
    } else {
      //电商没有发送验证码，发送验证码的是微信
      _this.information_checkMessage() //用户执行微信内容判断
    }
  },
  //中奖信息验证
  cheackPrize: function() {
    //验证手机号
    const _this = this;
    if (!_this.data.codeState) {
      //还未获取验证码
      $.f.showModal({
        'content': '请先获取验证码'
      })
      return
    }
    if (_this.checkPhone() === false) return
    if (_this.data.code == "") {
      $.f.showModal({
        'content': '请输入验证码'
      })
      return
    }
    //调用验证接口,如果成功则展示成功
    let params = {
      phoneNumber: _this.data.userPhoneInput,
      validateCode: _this.data.code,
      validateCodeType: _this.data.validateCodeType
    }
    if (this.data.checkInfo_type == 0) {
      //电商发送的验证码，发送接口校验电商的验证码
      $.Http.request($.HttpURL.checkValidateCode, params, false, function(res) {
        var data = JSON.parse(decodeURIComponent($.f.Base64.atob(res.result)));
        if (data.checkValidateCode1.respCode == "01") {
					console.log(data)
          //短信校验成功，调用是否参加活动接口，输入框关闭
					_this.prizeHoldCheck(data.phoneNumber)
        } else {
          $.f.showModal({
            'content': '验证未通过，请重新验证！'
          })
        }
      })
    } else {
      //电商没有发送验证码，发送验证码的是微信
      _this.prize_checkMessage() //用户执行微信内容判断
    }
  },
  //用户执行微信内容验证--中奖信息
  prize_checkMessage: function() {
    var that = this;
    if (that.data.checkInfoPhone != that.data.userPhoneInput) { //判断你输入的手机号和你发请求获取验证码的手机号是不是同一个
      $.f.showModal({
        title: "",
        content: "您的手机号和验证码不匹配，请查证后再次验证，谢谢！",
        confirmText: "OK"
      })
      return;
    }
    let params = {
      open_id: app.globalData.userOpenIds,
      verifyCode: that.data.code
    }
    $.Http.request($.HttpURL.checkwxChatCode, params, false, function(res) {
      if (res.result == 1) {
        //短信校验成功，调用是否参加过活动，校验框关闭
				that.prizeHoldCheck(that.data.checkInfoPhone)
      } else if (res.result == 2) {
        $.f.showModal({
          title: "",
          content: "短信验证码已失效，请重新获取！",
          confirmText: "OK"
        })
        return;
      } else {
        $.f.showModal({
          title: "",
          content: "短信验证码不正确，请重新填写！",
          confirmText: "OK"
        })
        return;
      }
    })
  },
  //参加活动校验
  prizeHoldCheck: function(phone) {
		const _this=this;
		var phonePrize=phone
    let params = {
			"phoneNumber": phonePrize
		}
    $.Http.request($.HttpURL.queryPrize, params, false, function(res) {
			if (res.result.errCode =="100000"){
				//未参加过活动
				_this.setData({
					prizeTest:false
				})
				$.f.showModal({
					title: "",
					content: "抱歉，您没有参加过抽奖活动！",
				})
			} else if(res.result.errCode == "000000"){
				_this.setData({
					prizeTest: false
				})
				//参加过活动跳转到新的页面
				wx.navigateTo({
					url: '/pages/prize/prize?phonePrize=' + res.result.phoneNumber,
				})
			}
    })
  },
  //用户执行微信内容判断
  information_checkMessage: function() {
    var that = this;
    if (that.data.checkInfoPhone != that.data.userPhoneInput) { //判断你输入的手机号和你发请求获取验证码的手机号是不是同一个
      $.f.showModal({
        title: "",
        content: "您的手机号和验证码不匹配，请查证后再次验证，谢谢！",
        confirmText: "OK"
      })
      return;
    }
    let params = {
      open_id: app.globalData.userOpenIds,
      verifyCode: that.data.code
    }
		$.Http.request($.HttpURL.checkwxChatCode, params, false, function (res) {
			if (res.result == 1) {
				_this.setData({
					phoneWindowShowMy: false,
					userPhoneInput: _this.data.checkInfoPhone,
					userPhone: _this.data.checkInfoPhone
				})
				$.f.setglobalData('userPhone',  _this.data.checkInfoPhone)
				_this.checkLogin()
				_this.bindPhone()
			} else if (res.result == 2) {
				$.f.showModal({
					title: "",
					content: "短信验证码已失效，请重新获取！",
					confirmText: "OK"
				})
				return;
			} else {
				$.f.showModal({
					title: "",
					content: "短信验证码不正确，请重新填写！",
					confirmText: "OK"
				})
				return;
			}
		})
  },
  //查询用户登录情况
  checkLogin: function() {
    const _this = this;
    let params = {
      openId: app.globalData.userOpenId,
      channelFlag: "03",
      operateType: "02",
      phoneNumber: app.globalData.userPhone,
      unionId: app.globalData.userUnionId
    };
    $.Http.request($.HttpURL.finishTask, params, false, function(res) {
      if (JSON.stringify(res) == "{}") return
      _this.setData({
        score: Number(res.result.score) + Number(_this.data.score),
      })
      $.f.setglobalData('score', res.result.score)
      //调用微信公众号接口
      if (_this.data.score != 0) {
        _this.setData({
          signShowMy: true
        })
      }
    })
  },
  //绑定手机号接口
  bindPhone: function() {
    const _this = this;
    var params = {
      phoneNumber: _this.data.userPhone,
      openId: app.globalData.userOpenId,
      unionId: app.globalData.userUnionId
    }
    $.Http.request($.HttpURL.bindPhone, params, false, function(res) {
      //返参证
      if (res.flag == 1) {
        //绑定成功
        _this.setData({
          signShowMy: true,
          phoneWindowShowMy: false,
        })
      }
    })
  },
  //关闭手机验证弹出窗口
  closePhoneWindow: function() {
    const _this = this;
    this.setData({
      phoneWindowShowMy: false
    })
  },
  //关闭我的奖品手机号验证弹框
  closePrizeTest: function() {
    const _this = this;
    this.setData({
      prizeTest: false
    })
  },
  //点击我的奖品，打开手机号验证弹框
  toprizeTest: function() {
    const _this = this;
    this.setData({
      prizeTest: true
    })
  },
  //判断是否阅读
  isReadChange: function() {
    const _this = this;
    _this.setData({
      isRead: !_this.data.isRead
    })
  },
  //跳转到webview页面
  toSign: function(e) {
    //判断是调到抽奖还是签到页面
    const _this = this;
    _this.setData({
      signShowMy: false
    })
    if (e.currentTarget.dataset.type == "reward") {
      //抽奖
      let aurl = "https://hub.chinalife-p.com.cn/ydthtihroh/Home/JiuGongGe"
      var link = aurl + "?phoneNumber=" + this.data.userPhone
      $.f.webviewNew(link);

    } else if (e.currentTarget.dataset.type == "sign") {
      //首页
      let aurl = $.f.findlink('00001');
      // var params = 'xcx' + '%' + this.data.userPhone + '%' + app.globalData.userUnionId + '%' + app.globalData.userOpenId + '%' + '1'
      var params = this.data.userPhone + '_' + app.globalData.userId
      var link = aurl.replace('appeal', params)
      $.f.webviewNew(link);
    }
  },
  //点击活动规则
  goRules: function() {
    wx.navigateTo({
      url: '/pages/sign/sign',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      userInfo: app.globalData.userInfo
    })
    app.userInfoReadyCallback = res => { //用户信息Callback
      var data = $.f.decipher(res.encryptedData, res.iv)
      $.f.setglobalData('userInfo', data)
      this.setData({
        userInfo: data
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getMyBussinessCard(); //获取客户partyid然后查等级
		//签到有礼部分内容
    // $.f.setglobalData('signShow', false)
    // $.f.setglobalData('phoneWindowShow', false)
    // $.f.setglobalData('signShowService', false)
    // $.f.setglobalData('phoneWindowShowService', false)
    // this.setData({
    //   score: app.globalData.score,
    //   signShowMy: app.globalData.signShowMy, //我的页面的展示
    //   phoneWindowShowMy: app.globalData.signShowMy,
    // })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})