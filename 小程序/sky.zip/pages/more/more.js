// pages/more/more.js
const app = getApp();
const $ = app.global;
const QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
		funTestShow:true,
    imgurl: $.imgurl,
    isOverShare: true, //不使用通用分享
    reNew: 0,
    phone: "",
    //页面初始化传值
    idCheckFlag: {
      flag: "1",
      score: "50"
    },
    todaySignFlag: '0',
    todayScore: '30',
    openProFlag: {
      flag: "0",
      score: "100"
    },
    roadRescueFlag: {
      flag: "0",
      score: "50"
    },
    shareProFlag: {
      flag: "0",
      score: "30"
    },
    shareConsFlag: {
      flag: "0",
      score: "30"
    },
    funTestFlag: {
      flag: "0",
      score: "30",
      state: "0"
    },
    policyInquiryFlag: {
      flag: "0",
      score: "20"
    },
    claimProgressFlag: {
      flag: "0",
      score: "20"
    },
    claimTimesFlag: {
      flag: "0",
      score: "20"
    }, //理赔次数
    idCheck: "0"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    const _this = this
    if (_this.data.phone == "") {
      //不存在
      _this.setData({
        phone: options.phone
      })
    } else {
      _this.setData({
        phone: _this.data.phone
      })
    }
    _this.query()
    setTimeout(function() {
      _this.setData({
        reNew: 1
      })
    }, 1000)
  },
  onShow: function() {
    const _this = this;
    if (_this.data.reNew == 1) {
      _this.onLoad()
    }
  },
  // querytask
  query: function() {
    console.log("查询信息")
    const _this = this;
    let params = {
      phoneNumber: _this.data.phone,
      openId: app.globalData.userOpenId,
      unionId: app.globalData.userUnionId,
      publicId: "",
    }
    console.log(params)
    $.Http.request($.HttpURL.querytask, params, false, function(res) {
      console.log(res)
      var res = res.result
      _this.setData({
        idCheckFlag: res.idCheckFlag,
        todaySignFlag: res.todaySignFlag,
        todayScore: res.todayScore,
        openProFlag: res.openProFlag,
        roadRescueFlag: res.roadRescueFlag,
        shareProFlag: res.shareProFlag,
        shareConsFlag: res.shareConsFlag,
        funTestFlag: res.funTestFlag,
        policyInquiryFlag: res.policyInquiryFlag,
        claimProgressFlag: res.claimProgressFlag,
        claimTimesFlag: res.claimTimesFlag, //理赔次数
        idCheck: res.idCheck,
      })
			var funTestFlag = _this.data.funTestFlag
			if ((funTestFlag.flag == "1" || funTestFlag.flag == "0" || funTestFlag.flag == "2") && Number(funTestFlag.state)< 6){
				_this.setData({
					funTestShow:true
				})
			}
			if (funTestFlag.flag == "3" || Number(funTestFlag.state) >= 6){
				_this.setData({
					funTestShow: false
				})
			}
    })
  },
  goTask: function(e) {
    const _this = this;
    console.log(e.currentTarget.dataset.task)
    var task = e.currentTarget.dataset.task
    if (task == "task2") {
      //身份认证 跳转至常用联系人
      let aurl = $.f.findlink('0040');
      $.f.webview(aurl);
    } else if (task == "task3") {
      let aurl = $.f.findlink('00001');
      var params = _this.data.phone
      var link = aurl.replace('appeal', params)
      $.f.webview(link);
    } else if (task == "task4") {
      //打开空中服务小程序
      //一定是已经完成
    } else if (task == "task5") {
      //道路救援
      let aurl = $.f.findlink('0023'); 
      var params = app.globalData.userId+'_' + app.globalData.userPhone
      var link = aurl.replace('appeal', params)
      $.f.webview(link);
    }
    // else if (task == "task6") {
    //   //分享空中服务
    //   _this.onShareAppMessage()
    // 	_this.onLoad()
    //   //签到
    // }
    else if (task == "task7") {
      //分享空中咨询小程序
      _this.gooninlecar()
    } else if (task = "task8") {
      //趣味测试
      _this.gooninlecar()
    } else if (task = "task9") {
      //保单查询
      _this.gooninlecar()
    } else if (task = "task10") {
      //理赔查询
      _this.gooninlecar()
    } else if (task = "task11") {
      //理赔查询
      _this.gooninlecar()
    }
  },
  gooninlecar: function() { //在线服务-跳另一个小程序
  const _this=this;
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": '在线服务',
        "button_iid": '02',
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    let city = '';
    let lng = '';
    let lat = '';
    let phone = _this.data.phone || '';
    let name = app.globalData.userName || '';
    try {
      if (app.globalData.address == null && app.globalData.addressls == null) { //没定位没选择
        city = ''
      } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
        city = $.f.getproandcity(app.globalData.addressls[0].name)
      } else {
        city = app.globalData.address.address;
        lat = app.globalData.address.location.lat;
        lng = app.globalData.address.location.lng;
      }
    } catch (e) {}
    console.log(city, lat, lng, name, phone)
    wx.navigateToMiniProgram({
      appId: $.glappid1,
      path: '',
      extraData: {
        userName: name,
        city: city,
        lng: lng,
        lat: lat,
        phone: phone,
        userId: app.globalData.userUserId,
        channel: '001'
      },
      success(res) {
        console.log(res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    const _this = this;
    setTimeout(function() {
      let params = {
        unionId: app.globalData.userUnionId,
        openId: app.globalData.userOpenId,
        channelFlag: "03",
        operateType: "04",
				phoneNumber: _this.data.phone
      };
      $.Http.request($.HttpURL.finishTask, params, false, function(res) {
        // if (res.result.score == 30) {
        //   //分享成功
        //   wx.showToast({
        //     title: '分享成功，恭喜获得10安心豆',
        //   })
        // } else {
        //   wx.showToast({
        //     title: '您今日已分享3次，请明日再来！',
        //   })
        // }
        _this.onLoad()
      })
    }, 2000)
    // let obj = encodeURIComponent(JSON.stringify({
    //   shareOpenid: app.globalData.userOpenIds, //分享者openid
    //   // shareUnionid: UnionId, //分享者UnionId
    //   // shareTime: Time,
    //   sharePage: '/pages/index/index'
    // }));
    let path = '/pages/index/index';
    return {
      path: path,
      imageUrl: $.imgurl + 'shareimg.png',
    }
  }
})