// pages/more/more.js
const app = getApp();
const $ = app.global;
const QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
		funTestShow:true,
    imgurl: $.imgurl,
    isOverShare: true, //不使用通用分享
    reNew: 0,
    phone: "",
    //页面初始化传值
    idCheckFlag: {
      flag: "1",
      score: "50"
    },
    todaySignFlag: '0',
    todayScore: '30',
    openProFlag: {
      flag: "0",
      score: "100"
    },
    roadRescueFlag: {
      flag: "0",
      score: "50"
    },
    shareProFlag: {
      flag: "0",
      score: "30"
    },
    shareConsFlag: {
      flag: "0",
      score: "30"
    },
    funTestFlag: {
      flag: "0",
      score: "30",
      state: "0"
    },
    policyInquiryFlag: {
      flag: "0",
      score: "20"
    },
    claimProgressFlag: {
      flag: "0",
      score: "20"
    },
    claimTimesFlag: {
      flag: "0",
      score: "20"
    }, //理赔次数
		scanProductFlag:{
			flag: "0",
			score: "20"
		},
		insuranceTrialFlag:{
			flag: "0",
			score: "100"
		},
		videoAgentFlag: {
			flag: "0",
			score: "100"
		},
		ownRepoFlag: {
			flag: "0",
			score: "100"
		},
    idCheck: "0",
		imgurl: $.imgurl,
		majors: $.major.arr,
		proandcityrank: '2',//地区选择组件层级
		sharePerson: "",//从分享进入小程序的unionid
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    const _this = this
    this.proandcity = this.selectComponent("#proandcity");
    if (_this.data.phone == "") {
      //不存在
      _this.setData({
        phone: options.phone
      })
    } else {
      _this.setData({
        phone: _this.data.phone
      })
    }
    _this.query()
    setTimeout(function() {
      _this.setData({
        reNew: 1
      })
    }, 1000)
  },
  onShow: function() {
    const _this = this;
    if (_this.data.reNew == 1) {
      _this.onLoad()
    }
  },
  // querytask
  query: function() {
		wx.showLoading({
			title: '加载中',
			mask: true
		})
    console.log("查询信息")
    const _this = this;
    let params = {
      phoneNumber: _this.data.phone,
      openId: app.globalData.userOpenId,
      unionId: app.globalData.userUnionId,
      publicId: "",
    }
    console.log(params)
    $.Http.request($.HttpURL.querytask, params, false, function(res) {
      console.log(res)
      var res = res.result
      _this.setData({
        idCheckFlag: res.idCheckFlag,
        todaySignFlag: res.todaySignFlag,
        todayScore: res.todayScore,
        openProFlag: res.openProFlag,
        roadRescueFlag: res.roadRescueFlag,
        shareProFlag: res.shareProFlag,
        shareConsFlag: res.shareConsFlag,
        funTestFlag: res.funTestFlag,
        policyInquiryFlag: res.policyInquiryFlag,
        claimProgressFlag: res.claimProgressFlag,
        claimTimesFlag: res.claimTimesFlag, //理赔次数
        idCheck: res.idCheck,
        scanProductFlag: res.scanProductFlag,
        insuranceTrialFlag: res.insuranceTrialFlag,
        videoAgentFlag: res.videoAgentFlag,
        ownRepoFlag: res.ownRepoFlag
      })
			var funTestFlag = _this.data.funTestFlag
			if ((funTestFlag.flag == "1" || funTestFlag.flag == "0" || funTestFlag.flag == "2") && Number(funTestFlag.state)< 6){
				_this.setData({
					funTestShow:true
				})
			}
			if (funTestFlag.flag == "3" || Number(funTestFlag.state) >= 6){
				_this.setData({
					funTestShow: false
				})
			}
      // 浏览保险商城数据处理
      var scanProductFlag = _this.data.scanProductFlag
      if ((scanProductFlag.flag == "1" || scanProductFlag.flag == "0" || scanProductFlag.flag == "2") && Number(scanProductFlag.state) < 6) {
        _this.setData({
          scanProductShow: true
        })
      }
      if (scanProductFlag.flag == "3" || Number(scanProductFlag.state) >= 6) {
        _this.setData({
          scanProductShow: false
        })
      }
			wx.hideLoading()
    })
  },
  goTask: function(e) {
    const _this = this;
    console.log(e.currentTarget.dataset.task)
    var task = e.currentTarget.dataset.task
    if (task == "task2") {
      //身份认证 跳转至常用联系人
      let aurl = $.f.findlink('0040');
      $.f.webview(aurl);
    } else if (task == "task3") {
      let aurl = $.f.findlink('00001');
      var params = _this.data.phone
      var link = aurl.replace('appeal', params)
      $.f.webview(link);
    } else if (task == "task4") {
      //打开空中服务小程序
      //一定是已经完成
    } else if (task == "task5") {
      //道路救援
      let aurl = $.f.findlink('0023'); 
      var params = app.globalData.userId+'_' + _this.data.phone
      var link = aurl.replace('appeal', params)
      $.f.webview(link);
    }
    // else if (task == "task6") {
    //   //分享空中服务
    //   _this.onShareAppMessage()
    // 	_this.onLoad()
    //   //签到
    // }
    else if (task == "task7") {
      //分享空中咨询小程序
      _this.gooninlecar()
    } else if (task == "task8") {
      //趣味测试
      _this.gooninlecar()
    } else if (task == "task9") {
      //保单查询
      _this.gooninlecar()
    } else if (task == "task10") {
      //理赔查询
      _this.gooninlecar()
    } else if (task == "task11") {
      //理赔查询
      _this.gooninlecar()
    } else if (task == "task12") {
      console.log("task12,保险商城")
      //浏览保险商城
			_this.scanProduct()
    } else if (task == "task13") {
      console.log("车险试算")
      _this.carInsure()
    } 
		// else if (task == "task14") {
    //   console.log("视频坐席")
    //   _this.govideo()
    // }
		else if (task == "task15") {
      console.log("自主报案")
      _this.gooninlecar()
		} else if (task == "task16"){
			console.log("车险试算")
			_this.quick()
		}
  },
  // 车险试算
  quick: function() {
		const _this=this;
    if (app.globalData.address == null && app.globalData.addressls == null) { //未定位,未选择让用户选择
      this.showactionsheet('0036极速出单');
      return
    } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
      let cc = app.globalData.addressls;
			console.log(cc,"未定位")
			if (cc[1].name.indexOf("大连") > -1) {//说明是大连
				var a = 2102
			} else if (cc[1].name.indexOf("宁波") > -1) {//说明是宁波
				var a = 3302
			} else if (cc[1].name.indexOf("青岛") > -1) {//说明是青岛
				var a = 3702
			} else if (cc[1].name.indexOf("深圳") > -1) {//说明是深圳
				var a = 4403
			} else if (cc[1].name.indexOf("厦门") > -1) {//说明是厦门
				var a = 3502
			} else {
				var a = cc[0].code.substring(0, 2)//省
			}
      // let a = cc[0].code; //省
      let b = cc[1].code; //市
			let p = _this.data.phone //用户手机号
			var link = "https://hub.chinalife-p.com.cn/internet/index.html?systemSource=OWeC100&mechanismCode=" + a + "&operatorPhone=" + p
      // var link = "http://chinalifebeta.china-sunfield.com/internet/index.html?systemSource=OWeC100&mechanismCode=" + a + "&operatorPhone=" + p
    } else { //定位的情况
      let cc = app.globalData.address.ad_info.adcode;
			console.log(cc,"定位")
			if (app.globalData.address.ad_info.name.indexOf("大连") > -1) {//说明是大连
				var a = 2102
			} else if (app.globalData.address.ad_info.name.indexOf("宁波") > -1) {//说明是宁波
				var a = 3302
			} else if (app.globalData.address.ad_info.name.indexOf("青岛") > -1) {//说明是青岛
				var a = 3702
			} else if (app.globalData.address.ad_info.name.indexOf("深圳") > -1) {//说明是深圳
				var a = 4403
			} else if (app.globalData.address.ad_info.name.indexOf("厦门") > -1) {//说明是厦门
				var a = 3502
			} else {
				var a = cc.substring(0, 2)//省
			}
      // let a = cc.substring(0, 2) + '0000'; //省份
			let p = _this.data.phone //用户手机号
			var link = "https://hub.chinalife-p.com.cn/internet/index.html?systemSource=OWeC100&mechanismCode=" + a + "&operatorPhone=" + p
      // var link = "http://chinalifebeta.china-sunfield.com/internet/index.html?systemSource=OWeC100&mechanismCode=" + a + "&operatorPhone=" + p
    }
    $.f.webview(link);
  },
  // 自主报价
  carInsure: function() {
    let a = '110000';
    let b = '110100';
    let userid = app.globalData.userOpenId;
    try {
      a = (app.globalData.address.ad_info.adcode).substring(0, 2) + '0000';
      b = (app.globalData.address.ad_info.adcode).substring(0, 4) + '00';
    } catch (e) {}
    let link = $.producturllink + '/carInsure/html/homePagetest.html?Userid=' + userid + '&Userrole=4&Syssource=2002000&TransID=' + $.transID + '&Profitcode=&Activitycode=&TransCode=019060517170000744598c5eaee3dea2&TransType=000001&region=undefined&province=' + a + '&city=' + b + '&shareId1=&shareId2=&skinColor=&isSeat=0&time=' + new Date().getTime();
    $.f.webview(link);
  },
  // 视频客服
  govideo: function() { //视频报案
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": '视频服务',
        "button_iid": '01',
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    wx.navigateTo({
      url: "/pages/videopage/videobeforer/videobeforer",
    })
  },
  // 浏览保险商城
  scanProduct: function() {
		const _this=this;
    var aurl = $.f.findlink('0006');
    if (app.globalData.address == null && app.globalData.addressls == null) { //未定位,未选择让用户选择
      this.showactionsheet('0006保险商城');
      return
    } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
      let n = app.globalData.userOpenId
      let cc = app.globalData.addressls;
      let a = cc[0].code;
      let b = cc[1].code;
      if (app.globalData.iffenxiang == 1) { //说明是分享进入的unionid
        let params = {
          "unionId": app.globalData.myshares
        }
        $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
          console.log(res)
          var shareperson = "FX" + res.unionIdRes
          $.f.setglobalData("fenxiangsharePerson", shareperson)
          let sharePerson = app.globalData.fenxiangsharePerson
          console.log("商城分享人", sharePerson)
          // _this.setData({
          //   sharePerson: sharePerson
          // })
					let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson + "&mdPhoneNo=" + _this.data.phone;
          $.f.webview(url);
        })
      } else {
        //直接在小程序打开的unionid
        let params = {
          "unionId": app.globalData.userUnionId
        }
        $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
          console.log(res)
          var sharePerson = res.unionIdRes
          console.log("商城直接点击", sharePerson)
          // _this.setData({
          //   sharePerson: sharePerson
          // })
          console.log(aurl, "商城")
					let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson + "&mdPhoneNo=" + _this.data.phone;
          $.f.webview(url);
        })
      }
    } else { //定位的情况
      let cc = app.globalData.address.ad_info.adcode;
      let n = app.globalData.userOpenId;
      let c = cc.substring(0, 2) + '0000';
      let x = cc.substring(0, 4) + '00';
      if (app.globalData.iffenxiang == 1) { //说明是分享进入的unionid
        let params = {
          "unionId": app.globalData.myshares
        }
        $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
          console.log(res)
          var shareperson = "FX" + res.unionIdRes
          $.f.setglobalData("fenxiangsharePerson", shareperson)
          let sharePerson = app.globalData.fenxiangsharePerson
          console.log("商城分享人", sharePerson)
          // _this.setData({
          //   sharePerson: sharePerson
          // })
					let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x + "&sharePerson=" + sharePerson + "&mdPhoneNo=" + _this.data.phone;
          $.f.webview(url);
        })
      } else {
        //直接在小程序打开的unionid
        let params = {
          "unionId": app.globalData.userUnionId
        }
        $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
          console.log(res)
          var sharePerson = res.unionIdRes
          console.log("商城直接点击", sharePerson)
          // _this.setData({
          //   sharePerson: sharePerson
          // })
					let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x + "&sharePerson=" + sharePerson + "&mdPhoneNo=" + _this.data.phone;
          $.f.webview(url);
        })
      }
    }
  },
  // 跳转空中咨询
  gooninlecar: function() { //在线服务-跳另一个小程序
  const _this=this;
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": '在线服务',
        "button_iid": '02',
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    let city = '';
    let lng = '';
    let lat = '';
    let phone = _this.data.phone || '';
    let name = app.globalData.userName || '';
    try {
      if (app.globalData.address == null && app.globalData.addressls == null) { //没定位没选择
        city = ''
      } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
        city = $.f.getproandcity(app.globalData.addressls[0].name)
      } else {
        city = app.globalData.address.address;
        lat = app.globalData.address.location.lat;
        lng = app.globalData.address.location.lng;
      }
    } catch (e) {}
    console.log(city, lat, lng, name, phone)
    wx.navigateToMiniProgram({
      appId: $.glappid1,
      path: '',
      extraData: {
        userName: name,
        city: city,
        lng: lng,
        lat: lat,
        phone: phone,
        userId: app.globalData.userUserId,
        channel: '001'
      },
      success(res) {
        console.log(res)
      }
    })
  },
  showactionsheet: function(e) { //唤起地区选择组件
    this.flag = e;
    this.proandcity.show();
  },
	_confirmproandcity(e) { //三级联动地区组件确认事件
	const _this=this;
		console.log(e)
		$.f.setglobalData('addressls', e.detail); //存储选择的临时位置
		if (this.flag == '0006保险商城') { //商城唤起的。跳转商城
      var aurl = $.f.findlink('0006');
			let n = app.globalData.userOpenId;
			let cc = app.globalData.addressls;
			let a = cc[0].code;
			let b = cc[1].code;
			//加分享人字段开始
			if (app.globalData.iffenxiang == 1) {//说明是分享进入的unionid
        let params = {
          "unionId": app.globalData.myshares
        }
				$.Http.request($.HttpURL.desUnionId, params, false, function (res) {
					console.log(res)
					var shareperson = "FX" + res.unionIdRes
					$.f.setglobalData("fenxiangsharePerson", shareperson)
					let sharePerson = app.globalData.fenxiangsharePerson
					console.log("商城分享人", sharePerson)
					// _this.setData({
					//   sharePerson: sharePerson
					// })
					let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson + "&mdPhoneNo=" + _this.data.phone;
					$.f.webview(url);
				})
			} else {
				//直接在小程序打开的unionid
        let params = {
          "unionId": app.globalData.userUnionId
        }
				$.Http.request($.HttpURL.desUnionId, params, false, function (res) {
					console.log(res)
					var sharePerson = res.unionIdRes
					console.log("商城直接点击", sharePerson)
					// _this.setData({
					//   sharePerson: sharePerson
					// })
					let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson + "&mdPhoneNo=" + _this.data.phone;
					$.f.webview(url);
				})
			}
		} else if (this.flag == '0036极速出单') {//买车险极速出单唤起的，跳转
			let cc = app.globalData.addressls;
			if (cc[1].name.indexOf("大连") > -1) {//说明是大连
				var a = 2102
			} else if (cc[1].name.indexOf("宁波") > -1) {//说明是宁波
				var a = 3302
			} else if (cc[1].name.indexOf("青岛") > -1) {//说明是青岛
				var a = 3702
			} else if (cc[1].name.indexOf("深圳") > -1) {//说明是深圳
				var a = 4403
			} else if (cc[1].name.indexOf("厦门") > -1) {//说明是厦门
				var a = 3502
			} else {
				var a = cc[0].code.substring(0, 2)//省
			}
			let p = _this.data.phone //用户手机号
			// var sys = {
			//   "systemSource": "OWeC100",
			// }
			// var pro = {
			//   "mechanismCode": a
			// }
			// var pho = {
			//   "operatorPhone": p
			// }
			var link = "https://hub.chinalife-p.com.cn/internet/index.html?systemSource=OWeC100&mechanismCode=" + a + "&operatorPhone=" + p
			// let link = "http://chinalifebeta.china-sunfield.com/internet/index.html?systemSource=OWeC100&mechanismCode=" + a + "&operatorPhone=" + p
			$.f.webview(link);
		} else { //热销唤起的。跳转热销
			let userid = app.globalData.userOpenId;
			let cc = app.globalData.addressls;
			let a = cc[0].code;
			let b = cc[1].code;
			let link = $.producturllink + '/MSF/wecheat-html/product/producd' + this.flag + '.html?pid=' + this.flag + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63';
			$.f.webview(link);
		}
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },



  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    const _this = this;
    setTimeout(function() {
      let params = {
        unionId: app.globalData.userUnionId,
        openId: app.globalData.userOpenId,
        channelFlag: "03",
        operateType: "04",
				phoneNumber: _this.data.phone
      };
      $.Http.request($.HttpURL.finishTask, params, false, function(res) {
        // if (res.result.score == 30) {
        //   //分享成功
        //   wx.showToast({
        //     title: '分享成功，恭喜获得10安心豆',
        //   })
        // } else {
        //   wx.showToast({
        //     title: '您今日已分享3次，请明日再来！',
        //   })
        // }
        _this.onLoad()
      })
    }, 2000)
    // let path = '/pages/index/index';
    // return {
    //   path: path,
    //   imageUrl: $.imgurl + 'shareimg.png',
    // }   
    let timeobj = $.time.showDate(new Date());
    let Time = timeobj.a.replace(/\//g, '-') + ' ' + timeobj.d;
    let UnionId = app.globalData.userUnionId;
    if (UnionId == 'false' || UnionId == 'none' || UnionId == null || UnionId == undefined) {
      UnionId = '';
    }
    let obj = encodeURIComponent(JSON.stringify({
      shareOpenid: app.globalData.userOpenIds, //分享者openid
      shareUnionid: UnionId, //分享者UnionId
      shareTime: Time,
      sharePage: '/pages/index/index'
    }));
    let path = '/pages/index/index?shareobj=' + obj;
    return {
      path: path,
      imageUrl: $.imgurl + 'shareimg.png',
    } 
  }
})