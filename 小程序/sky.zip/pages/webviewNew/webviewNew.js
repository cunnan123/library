// pages/webview/webview.js
const app = getApp()
const $ = app.global;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgurl: $.imgurl,
    url: '',
    reNew: 0,
    webviewShow: true,
    isOverShare: true,
  },
  open: function(e) {
    console.log('openNew: ' + this.data.url)
  },
  openerror: function(e) {},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    const _this = this;
	
    var url = this.data.url;
    //已经进来过，并且是跳转到签到有礼页面
    if (url.indexOf('SignInPolite_index.html') > -1) { //是签到有礼页
			if (url.indexOf('#wechat_redirect') > -1){
				//小程序进的
				if (url.indexOf('&r=') > -1) { //含有&r=时
					var params = '&r=' + Math.random() + '#wechat_redirect'
					url = url.replace(/&r=0.\d*#wechat_redirect/, params)
					this.setData({
						url: url,
					})
					_this.setWebviewShow()
				} else {
					var params = '&r=' + Math.random() + '#wechat_redirect'
					url = url.replace('#wechat_redirect', params)
					this.setData({
						url: url,
					})
					_this.setWebviewShow()
				}
			}else{
				//app进的
				if (url.indexOf('&r=') > -1) { //含有&r=时
					var params = '&r=' + Math.random()
					url = url.replace(/&r=0.\d*/, params)
					this.setData({
						url: url,
					})
					_this.setWebviewShow()
				} else {
					var params = '&r=' + Math.random()
					url = url+params
					this.setData({
						url: url,
					})
					_this.setWebviewShow()
				}
			}
    } else {
      //没有进入这个页面，或者没有打开过webview
      if (_this.options.userId != undefined) {
        this.setData({
					url: $.HttpDomain+ "wechatpageview/SignInPolite_index.html?userId=" + _this.options.userId + "&r=" + Math.random(),
        })
				_this.setWebviewShow()
      } else {
        let data = decodeURIComponent(_this.options.url)
        this.setData({
          url: data,
        })
				_this.setWebviewShow()
      }

    }
    setTimeout(function() {
      _this.setData({
        reNew: 1
      })
    }, 1000)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {


  },
	//设置延时处理为true
	setWebviewShow:function(){
		const _this=this
		setTimeout(function () {
			if (!_this.data.webviewShow) {
				_this.setData({
					webviewShow: true
				})
			}
		}, 100)
	},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    const _this = this;
		console.log("show函数")
    console.log(_this.data.webviewShow)
		console.log(_this.data.reNew)
    if (_this.data.reNew == 1) {
    _this.setData({
      webviewShow: false
    })
      _this.onLoad()
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
})