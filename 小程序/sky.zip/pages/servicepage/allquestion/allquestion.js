// pages/servicepage/allquestion/allquestion.js
const app = getApp();
const $ = app.global;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
        querylistall:[//全部问题

        ]
    },
    goquestion: function (e) {//问题详情
        let _this = this;
        let index = e.currentTarget.dataset.index;
        let list = _this.data.querylistall;
        let isshow = list[index].show;
        list.forEach(function (item) {
            item.show = false;
        })
        list[index].show = !isshow;
        _this.setData({
            querylistall: list
        })
        // console.log(e.currentTarget.dataset.info);
        // let a = encodeURIComponent(JSON.stringify(e.currentTarget.dataset.info))
        // wx.navigateTo({
        //     url: '/pages/servicepage/question/question?info=' + a
        // })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var data = JSON.parse(decodeURIComponent(options.all));
        console.log(data);
        this.setData({
            querylistall:data
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})