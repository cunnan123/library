// pages/servicepage/reportingtype/reportingtype.js
const app = getApp();
const $ = app.global;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
        obj: {
            'title': '请在以下方式中选择您的报案类型',
            'content': [
                '车险报案',
                '非车险报案'
            ]
        }
    },
    govideo:function(){//视频报案
        wx.redirectTo({
            url: "/pages/videopage/videobefore/videobefore",
        })
    },
    showactionsheet:function(){
        this.actionsheet.show();
    },
    //actionsheet取消事件
    _cancelEvent() {
        console.log('你点击了取消');
        this.actionsheet.hide();
    },
    //actionsheet确认事件
    _confirmEvent(e) {
        this.actionsheet.hide();
        console.log('你选择了' + e.detail);
        if (e.detail =='车险报案'){
            this.gooninlecar()
        }else{
            this.gooninle()
        }
    },
    gooninlecar:function(){//车险在线报案-跳另一个小程序
        $.f.showModal({
            'content': '跳车险小程序'
        })
    },
    gooninle: function () {//车险在线报案
        $.f.showModal({
            'content': '非车险报案页面'
        })
    },






    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        this.actionsheet = this.selectComponent("#actionsheet");
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})