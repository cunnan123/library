// pages/index/index.js
const app = getApp();
const $ = app.global;
const QQMapWX = require('../../utils/qqmap-wx-jssdk.js');
Page({
  showorhideflag: false, //是否已完成授权判断
  flag: null, //唤起地区组件场景
  time: null, //可能出现的请求分公司定时器
  /**
   * 页面的初始数据
   */
  data: {
    isOverShare: true, //不使用通用分享
    imgurl: $.imgurl,
    movies: $.major.arr4,
    currentSwiper: 0, // 轮播图当前活动的swiper
    majors: ($.major.arr).slice(0, 7), //功能图列表的前7个
    differ: ($.major.arr1).slice(0, 3), //全心全意差异化前3个
    news1: $.major.arr7, //公司新闻
    news2: $.major.arr8, //更多动态
    productLists: $.major.arr2, //热销产品列表
    oilprice92: '****', //油价
    oilprice95: '****',
    oilprice0: '****',
    weatheraddress: '', //当前天气城市
    weather: { //天气未返回时先***
      "weatherno": "00",
      "areaid": "101010100",
      "areachiname": "北京",
      "temperature": "**",
      "daycentigrade": "**",
      "nightcentigrade": "**",
      "weathername": "*"
    },
    selet: true, //更多精彩切换标识
    newtime: $.newData, //当前日期
    addresscompany: '', //当前公司名称
    proandcityrank: '2', //地区选择组件层级
    signFirstShow: false, //首页签到有礼
    signShow: true, //每日登录有礼
    isRead: false,
    codeText: '获取验证码', //获取验证码
    userPhone: "", //用户手机号
    userPhoneInput: "", //输入的手机号
    code: "", //验证码
    phoneWindowShow: false, //手机号输入弹窗显示
    score: 0, //获得安心豆的数量
    unionId: "",
    codeState: false, //是否点击过获取验证码
    ifshare: 0, //是否是分享进入的小程序标志
    sharePerson: "", //从分享进入小程序的unionid
    validateCodeType: "", //客户类型
    checkInfo_type: "", //电商是否可以发送验证码
    signPut: true, //点击签到有礼
  },
  bannerclick: function(e) {
    let a = e.currentTarget.dataset.link;
    try {
      $.Http.bfd('scrollbar_click', {
        "scrollbar_name": a,
        "scrollbar_iid": '001',
      })
    } catch (e) {}
    if (a == 'Wechatbanner0') {
      return
    }
    if (a == 'Wechatbanner1') {
      let aurl = $.f.findlink('0040');
      $.f.webview(aurl);
      return
    }
    if (a == 'Wechatbanner2') {
      wx.navigateTo({
        url: '/pages/videopage/videobeforer/videobeforer',
      })
      return
    }
    if (a == 'Wechatbanner3') {
      let a = '110000';
      let b = '110100';
      let userid = app.globalData.userOpenId;
      try {
        a = (app.globalData.address.ad_info.adcode).substring(0, 2) + '0000';
        b = (app.globalData.address.ad_info.adcode).substring(0, 4) + '00';
      } catch (e) {}
      let link = $.producturllink + '/carInsure/html/homePagetest.html?Userid=' + userid + '&Userrole=4&Syssource=2002000&TransID=' + $.transID + '&Profitcode=&Activitycode=&TransCode=019060517170000744598c5eaee3dea2&TransType=000001&region=undefined&province=' + a + '&city=' + b + '&shareId1=&shareId2=&skinColor=&isSeat=0&time=' + new Date().getTime();
      $.f.webview(link);
      return
    }
  },
  //小图标移动
  move: function(e) {
    console.log(e)
  },
  gowebview: function(e) { //打开webview
    var _this = this;
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": e.currentTarget.dataset.t,
        "button_iid": e.currentTarget.dataset.id,
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    let aurl = $.f.findlink(e.currentTarget.dataset.id);
    if (e.currentTarget.dataset.id == '0036') { //买车险
      let a = '110000';
      let b = '110100';
      let userid = app.globalData.userOpenId;
      try {
        a = (app.globalData.address.ad_info.adcode).substring(0, 2) + '0000';
        b = (app.globalData.address.ad_info.adcode).substring(0, 4) + '00';
      } catch (e) {}
      let link = $.producturllink + '/carInsure/html/homePagetest.html?Userid=' + userid + '&Userrole=4&Syssource=2002000&TransID=' + $.transID + '&Profitcode=&Activitycode=&TransCode=019060517170000744598c5eaee3dea2&TransType=000001&region=undefined&province=' + a + '&city=' + b + '&shareId1=&shareId2=&skinColor=&isSeat=0&time=' + new Date().getTime();
      $.f.webview(link);
      return
    }
    if (e.currentTarget.dataset.id == '0003') { //查理赔跳小程序
      wx.navigateToMiniProgram({
        appId: $.glappid2,
        path: '',
        extraData: {

        },
        success(res) {
          console.log(res)
        },
        fail(res) {
          console.log(res)
        },
      })
      return
    }
    if (e.currentTarget.dataset.id == '0056') { //祝福家小程序
      wx.navigateToMiniProgram({
        appId: $.glappid3,
        path: '',
        extraData: {

        },
        success(res) {
          console.log(res)
        },
        fail(res) {
          console.log(res)
        },
      })
      return
    }
    if (e.currentTarget.dataset.id == '0091') { //自由保小程序
      wx.navigateToMiniProgram({
        appId: $.glappid4,
        path: '',
        extraData: {
          tag: "kzff",
        },
        success(res) {
          console.log(res)
        },
        fail(res) {
          console.log(res)
        },
      })
      return
    }
    if (e.currentTarget.dataset.id == '0006') { //产品仓库
      if (app.globalData.address == null && app.globalData.addressls == null) { //未定位,未选择让用户选择
        this.showactionsheet('0006保险商城');
        return
      } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
        let aurl = $.f.findlink('0006');
        let n = app.globalData.userOpenId
        let cc = app.globalData.addressls;
        let a = cc[0].code;
        let b = cc[1].code;
        if (app.globalData.iffenxiang == 1) { //说明是分享进入的unionid
          let params = {
            "unionId": app.globalData.myshares
          }
          $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
            console.log(res)
            var shareperson = "FX" + res.unionIdRes
            $.f.setglobalData("fenxiangsharePerson", shareperson)
            let sharePerson = app.globalData.fenxiangsharePerson
            console.log("商城分享人", sharePerson)
            // _this.setData({
            //   sharePerson: sharePerson
            // })
            let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson;
            $.f.webview(url);
          })
        } else {
          //直接在小程序打开的unionid
          let params = {
            "unionId": app.globalData.userUnionId
          }
          $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
            console.log(res)
            var sharePerson = res.unionIdRes
            console.log("商城直接点击", sharePerson)
            // _this.setData({
            //   sharePerson: sharePerson
            // })
            let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b + "&sharePerson=" + sharePerson;
            $.f.webview(url);
          })
        }
      } else { //定位的情况
        let cc = app.globalData.address.ad_info.adcode;
        let n = app.globalData.userOpenId;
        let c = cc.substring(0, 2) + '0000';
        let x = cc.substring(0, 4) + '00';
        if (app.globalData.iffenxiang == 1) { //说明是分享进入的unionid
          let params = {
            "unionId": app.globalData.myshares
          }
          $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
            console.log(res)
            var shareperson = "FX" + res.unionIdRes
            $.f.setglobalData("fenxiangsharePerson", shareperson)
            let sharePerson = app.globalData.fenxiangsharePerson
            console.log("商城分享人", sharePerson)
            // _this.setData({
            //   sharePerson: sharePerson
            // })
            let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x + "&sharePerson=" + sharePerson;
            $.f.webview(url);
          })
        } else {
          //直接在小程序打开的unionid
          let params = {
            "unionId": app.globalData.userUnionId
          }
          $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
            console.log(res)
            var sharePerson = res.unionIdRes
            console.log("商城直接点击", sharePerson)
            // _this.setData({
            //   sharePerson: sharePerson
            // })
            let url = aurl + 'unionId=' + n + '&add=' + c + '&add1=' + x + "&sharePerson=" + sharePerson;
            $.f.webview(url);
          })
        }
      }
      return
    }
    if (e.currentTarget.dataset.id == '0009') { //网点查询
      if (app.globalData.address == null) {
        aurl = aurl + 'lat=39.908419&lng=116.397572'; //默认天安门
        $.f.webview(aurl);
      } else {
        let c = app.globalData.address.location.lat
        let x = app.globalData.address.location.lng
        aurl = aurl + 'lat=' + c + '&lng=' + x
        $.f.webview(aurl);
      }
      return
    }
    if (e.currentTarget.dataset.id == '0100') { //天气提醒
      if (app.globalData.address == null) {
        aurl = aurl + '北京#wechat_redirect'; //默认北京天气
        $.f.webview(aurl);
      } else {
        let a = $.f.getcity(app.globalData.address.ad_info.city);
        aurl = aurl + a + '#wechat_redirect'
        $.f.webview(aurl);
      }
      return
    }
    if (e.currentTarget.dataset.id == '0023') { //道路救援
      let aurl = $.f.findlink('0023');
      var params = app.globalData.userId + '_' + app.globalData.userPhone
      var link = aurl.replace('appeal', params)
      $.f.webview(link);
      return
    }
    $.f.webview(aurl);
  },
  clickproduct: function(e) { //点击热销产品
    var _this = this;
    try {
      $.Http.bfd('product_visit', {
        "product_name": e.currentTarget.dataset.t,
        "product_iid": e.currentTarget.dataset.link,
        "product_category": '首页热销',
      })
    } catch (e) {}
    let id = e.currentTarget.dataset.link;
    let a = '110000';
    let b = '110100';
    let userid = app.globalData.userOpenId;
    if (app.globalData.iffenxiang == 1) { //说明是分享进入的unionid
      //对FX加unionid进行解密
      let params = {
        "unionId": app.globalData.myshares
      }
      $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
        console.log(res)
        var shareperson = "FX" + res.unionIdRes
        $.f.setglobalData("fenxiangsharePerson", shareperson)
        let sharePerson = app.globalData.fenxiangsharePerson
        console.log("产品分享人", sharePerson)
        // _this.setData({
        //   sharePerson: sharePerson
        // }) 
        // console.log("产品全局",_this.data.sharePerson)
        let link = $.producturllink + '/MSF/wecheat-html/product/producd' + id + '.html?pid=' + id + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63' + "&sharePerson=" + sharePerson;
        $.f.webview(link);
      })
    } else {
      //直接在小程序打开的unionid
      let params = {
        "unionId": app.globalData.userUnionId
      }
      $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
        console.log(res)
        var sharePerson = res.unionIdRes
        console.log("产品直接点击", sharePerson)
        // _this.setData({
        //   sharePerson: sharePerson
        // })
        // console.log("产品全局", _this.data.sharePerson)
        let link = $.producturllink + '/MSF/wecheat-html/product/producd' + id + '.html?pid=' + id + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63' + "&sharePerson=" + sharePerson;
        $.f.webview(link);
      })
      // let sharePerson = app.globalData.userUnionId
      // _this.setData({
      //   sharePerson: sharePerson
      // })
      // let link = $.producturllink + '/MSF/wecheat-html/product/producd' + id + '.html?pid=' + id + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63' + "&sharePerson=" + _this.data.sharePerson;
      // $.f.webview(link);
    }
    if (app.globalData.address == null && app.globalData.addressls == null) { //未定位,未选择让用户选择
      this.showactionsheet(id);
      return
    } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
      let cc = app.globalData.addressls;
      a = cc[0].code;
      b = cc[1].code;
      if (app.globalData.iffenxiang == 1) {
        //对FX加unionid进行解密
        let params = {
          "unionId": app.globalData.myshares
        }
        $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
          console.log(res)
          var shareperson = "FX" + res.unionIdRes
          $.f.setglobalData("fenxiangsharePerson", shareperson)
          let sharePerson = app.globalData.fenxiangsharePerson
          console.log("产品分享人", sharePerson)
          // _this.setData({
          //   sharePerson: sharePerson
          // }) 
          // console.log("产品全局",_this.data.sharePerson)
          let link = $.producturllink + '/MSF/wecheat-html/product/producd' + id + '.html?pid=' + id + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63' + "&sharePerson=" + sharePerson;
          $.f.webview(link);
        })
      } else {
        //直接在小程序打开的unionid
        let params = {
          "unionId": app.globalData.userUnionId
        }
        $.Http.request($.HttpURL.desUnionId, params, false, function(res) {
          console.log(res)
          var sharePerson = res.unionIdRes
          console.log("产品直接点击", sharePerson)
          // _this.setData({
          //   sharePerson: sharePerson
          // })
          // console.log("产品全局", _this.data.sharePerson)
          let link = $.producturllink + '/MSF/wecheat-html/product/producd' + id + '.html?pid=' + id + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63' + "&sharePerson=" + sharePerson;
          $.f.webview(link);
        })
      }
    } else { //定位的情况
      try {
        a = (app.globalData.address.ad_info.adcode).substring(0, 2) + '0000';
        b = (app.globalData.address.ad_info.adcode).substring(0, 4) + '00';
      } catch (e) {}
    }
  },
  showactionsheet: function(e) { //唤起地区选择组件
    this.flag = e;
    this.proandcity.show();
  },
  _confirmproandcity(e) { //三级联动地区组件确认事件
    $.f.setglobalData('addressls', e.detail); //存储选择的临时位置
    if (this.flag == '0006保险商城') { //商城唤起的。跳转商城
      let aurl = $.f.findlink('0006');
      let n = app.globalData.userOpenId;
      let cc = app.globalData.addressls;
      let a = cc[0].code;
      let b = cc[1].code;
      let url = aurl + 'unionId=' + n + '&add=' + a + '&add1=' + b;
      $.f.webview(url);
    } else { //热销唤起的。跳转热销
      let userid = app.globalData.userOpenId;
      let cc = app.globalData.addressls;
      let a = cc[0].code;
      let b = cc[1].code;
      let link = $.producturllink + '/MSF/wecheat-html/product/producd' + this.flag + '.html?pid=' + this.flag + '&sysId=6163300&Userrole=4&userId=' + userid + '&TransID=' + $.transID + '&province=' + a + '&city=' + b + '&skinColor=009b63';
      $.f.webview(link);
    }
  },
  majomore: function() { //功能图标更多
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": '更多功能',
        "button_iid": '3333',
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    wx.navigateTo({
      url: '/pages/indexpage/more/more'
    })
  },
  switchaddress: function(e) { //切换分公司
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": '切换分公司',
        "button_iid": '3333',
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    wx.navigateTo({
      url: '/pages/indexpage/choose/choose'
    })
  },
  gonews: function(e) { //查看新消息
    try {
      $.Http.bfd('service_hall_button_click', {
        "button_name": '消息中心',
        "button_iid": '2222',
        "button_comCode": '00000000',
        "button_root": '0',
      })
    } catch (e) {}
    wx.navigateTo({
      url: '/pages/indexpage/message/message'
    })
  },
  gonewsdetail: function(e) { //查看新闻详情
    console.log(e.currentTarget.dataset.link);
    if (e.currentTarget.dataset.id == '0091') { //自由保小程序
      wx.navigateToMiniProgram({
        appId: $.glappid4,
        path: '',
        extraData: {
          tag: "kzff",
        },
        success(res) {
          console.log(res)
        },
        fail(res) {
          console.log(res)
        },
      })
      return
    } else {
      $.f.webview(e.currentTarget.dataset.link);
    }
  },
  switchNav: function() { //更多精彩切换函数
    this.setData({
      selet: !this.data.selet
    })
  },
  getLocation: function() { //获取地理位置
    var _this = this;
    if (!app.globalData.address) { //判断是否定位过。先打开的其他页面时会有这种情况
      wx.getLocation({
        type: 'gcj02',
        success: function(res) {
          console.log(res);
          _this.showAddress(res.longitude, res.latitude)
        },
        cancel: function(res) {
          console.log(res)
          _this.showAddressafter() //按定位成功逻辑
        },
        fail: function(res) {
          console.log(res)
          _this.showAddressafter() //按定位成功逻辑
        }
      })
    } else {
      _this.showAddressafter() //按定位成功逻辑
    }
  },
  _Location: function(e) { //组件地理位置回调
    let _this = this;
    let res = e.detail
    if (res == null) { //用户拒绝定位
      _this.showAddressafter() //按定位成功逻辑
    } else { //定位成功
      _this.showAddress(res.longitude, res.latitude)
    }
  },
  showAddress: function(longitude, latitude) { //腾讯sdk解析地理位置
    var _this = this;
    // 实例化腾讯地图API核心类  
    var qqmapsdk = new QQMapWX({
      key: $.qqmapkey //此处使用你自己申请的key  
    });
    // 腾讯地图调用接口  
    qqmapsdk.reverseGeocoder({
      location: {
        latitude: latitude,
        longitude: longitude
      },
      coord_type: 5, //GCJ02坐标系
      success: function(res) {
        console.log(res)
        if (res.status == 0) {
          res.result.location.lat = latitude;
          res.result.location.lng = longitude;
          $.f.setglobalData('address', res.result);
          _this.showAddressafter() //定位成功逻辑
        } else {
          _this.showAddressafter() //定位成功逻辑
        }
      },
      fail: function(error) {
        console.log(error)
        _this.showAddressafter() //按定位成功逻辑
      },
    });
  },
  showAddressafter: function() { //定位之后获取天气，油价,分公司,热销产品
    this.getweather(); //获取天气
    this.getoilprice(); //获取油价
    this.getlocationQuery(); //获取分公司
    app.sharepush(); //分享信息统计
  },
  userloadshoworhide: function() { //通过userUnionId判断是否需要授权登录
    let _this = this;
    if (_this.showorhideflag) return
    let u = app.globalData.userUnionId;
    if (u == '') return
    if (u == 'none') { //未查到时会后台接口会返回'none'。拒绝之后缓存为'false'。为了用户体验生命周期只弹出1次
      _this.userloading.show();
      _this.showorhideflag = true;
    } else {
      _this.getLocation(); //授权地理位置
      _this.showorhideflag = true;
    }
  },
  getweather: function() { //获取天气信息
    var _this = this;
    let a = '北京'
    try {
      a = $.f.getcity(app.globalData.address.address_component.city)
    } catch (e) {}
    let params = { //城市
      areaname: a
    };
    $.Http.request($.HttpURL.oneWeather, params, false, function(res) {
      try {
        _this.setData({
          weather: res.result,
          weatheraddress: $.f.getprovince(a)
        })
      } catch (e) {}
    })
  },
  getoilprice: function() { //获取油价信息
    var _this = this
    let a = '北京'
    try {
      a = (app.globalData.address.address_component.city).substring(0, 2)
    } catch (e) {}
    let params = { //省份
      cityname: a
    };
    $.Http.request($.HttpURL.oilprice, params, false, function(res) {
      let data = res.result;
      if (data == undefined) {
        return
      }
      data.forEach(function(item) {
        if (item.oilname == '92') {
          _this.setData({
            'oilprice92': '￥' + item.oilprice
          })
        }
        if (item.oilname == '95') {
          _this.setData({
            'oilprice95': '￥' + item.oilprice
          })
        }
        if (item.oilname == '0') {
          _this.setData({
            'oilprice0': '￥' + item.oilprice
          })
        }
      })
    })
  },
  getlocationQuery: function() { //获取用户分公司
    let _this = this;
    if (app.globalData.userOpenIds) {
      this.getlocationQuery2();
    } else {
      _this.time = setTimeout(function() {
        _this.getlocationQuery2();
      }, 5000)
    }
  },
  getlocationQuery2: function() { //新获取分公司
    let _this = this;
    let params = {
      openId: app.globalData.userOpenIds
    };
    $.Http.request($.HttpURL.locationQuery, params, false, function(res) {
      let data = res.result;
      let comcodeandcompany = {
        comcode: data.comcode,
        company: data.company,
      }
      if (_this.time) {
        clearTimeout(_this.time)
      }
      $.f.setglobalData('comcodeandcompany', comcodeandcompany)
      _this.getlocationQueryafter(); //执行取得之后的函数
    })
  },
  getlocationQueryafter: function() { //取得用户分公司之后轮播
    let addresscompany = '';
    if (app.globalData.comcodeandcompany.company == '总公司') {
      addresscompany = '中国人寿财险服务大厅'
    } else {
      addresscompany = app.globalData.comcodeandcompany.company
    }
    this.setData({ //展示的公司名称显示
      addresscompany: addresscompany
    });
  },
  comcodeafterfun: function() { //判断是否从选择分公司返回的
    let _this = this;
    let iscomcodetype = app.globalData.iscomcodetype
    if (iscomcodetype) { //表明分公司选择页改变分公司返回
      _this.getlocationQueryafter();
    }
  },
  //签到有礼
  closeSign: function(e) { //关闭弹窗
    var state = e.currentTarget.dataset.state
    console.log(e.currentTarget.dataset)
    const _this = this;
    _this.setData({
      [state]: false
    })
    $.f.setglobalData('signShow', false)
  },
  //获取手机号
  phoneInput: function(e) {
    this.setData({
      userPhoneInput: e.detail.value
    })
  },
  //获取输入的验证码
  codeInput: function(e) {
    this.setData({
      code: e.detail.value
    })
  },
  // 验证手机号
  checkPhone: function(e) {
    const _this = this
    const reg = /^(13|15|18|14|17|16|19)\d{9}$/
    const phone = _this.data.userPhoneInput * 1
    if (!reg.test(phone)) {
      $.f.showModal({
        'content': '请输入正确的手机号'
      })
      return false
    }
    return true
  },
  //请求获取验证码接口
  getCode: function() {
    const _this = this
    console.log("输入验证码")
    if (!_this.data.codeState) {
      _this.setData({
        codeState: true
      })
    }
    // 如果正在倒计时
    if (typeof this.data.codeText === 'number') return
    // 验证手机号
    if (_this.checkPhone() === false) return
    // 获取验证码倒计时
    this.setData({
      codeText: 60
    })
    var timer = setInterval(function() {
      _this.setData({
        codeText: --_this.data.codeText
      })
      if (_this.data.codeText === 0) {
        _this.setData({
          codeText: '获取验证码'
        })
        clearInterval(timer)
      }
    }, 1000)
    let params = {
      phoneNumber: _this.data.userPhoneInput
    };
    $.Http.request($.HttpURL.geterCode, params, false, function(res) {
      if (res.requestTime == "1") {
        $.f.showModal({
          'content': '尊敬的客户，您获取验证码的频率过高，请稍后获取！'
        })
        return;
      }
      _this.setData({ //电商可以验证码
        checkInfo_type: 0
      })
      if (res.getValidateCode1.respCode == "01") {
        console.log("电商可以验证码1")
        wx.showToast({
          title: '已发送',
        })
        _this.setData({
          validateCodeType: "01" //注册调用成功
        })
        //验证码倒数函数
      } else if (res.getValidateCode1.respCode == "10") {
        //电商不能获取验证码
        that.setData({
          checkInfo_type: 1
        })
        console.log("电商不能验证码1，即将走微信内部验证码")
        _this.sentErCode(); //微信内部获取验证码
      } else {
        if (res.getValidateCode2.respCode == "01") {
          $.f.showModal({
            'content': '手机验证码已经发出！'
          })
          _this.setData({ //登录调用成功
            validateCodeType: "02"
          })
          console.log("电商可以验证码2")
          //验证码倒数函数
        } else {
          if (res.getValidateCode1.respCode == "10" || res.getValidateCode1.respCode == "49" ||
            res.getValidateCode2.respCode == "10" || res.getValidateCode2.respCode == "49") {
            //电商获取不到验证码
            _this.setData({
              checkInfo_type: 1 //登录调用成功
            })
            console.log("电商不能获取验证码2，即将走微信")
            _this.sentErCode(); //微信内部获取验证码
          } else {
            $.f.showModal({
              'content': '发送验证码失败，请稍后再次获取！'
            })
          }
        }
      }
    })
  },
  //微信内部获取验证码
  sentErCode: function() {
    let _this = this;
    let params = {
      open_id: app.globalData.userOpenId,
      mobile_Phone: _this.data.userPhoneInput
    }
    $.Http.request($.HttpURL.senderCode, params, false, function(res) {
      if (res.result == "1") {
        wx.showToast({
          title: '已发送',
        })
        _this.setData({
          checkInfoPhone: _this.data.userPhoneInput
        })
        //验证码倒数
      } else if (res.result == "2") {
        $.f.showModal({
          'content': '尊敬的客户，您获取验证码的频率过高，请稍后获取！'
        })
      } else {
        $.f.showModal({
          'content': '发送手机验证码失败，请重新获取！'
        })
      }
    })
  },

  //点击开启，发送验证接口
  cheackCode: function() {
    //验证手机号
    const _this = this;
    if (!_this.data.codeState) {
      //还未获取验证码
      $.f.showModal({
        'content': '请先获取验证码'
      })
      return
    }
    if (_this.checkPhone() === false) return
    if (_this.data.code == "") {
      $.f.showModal({
        'content': '请输入验证码'
      })
      return
    }
    if (!_this.data.isRead) {
      $.f.showModal({
        'content': '请阅读活动规则'
      })
      return
    }
    //调用验证接口,如果成功则展示成功
    let params = {
      phoneNumber: _this.data.userPhoneInput,
      validateCode: _this.data.code,
      validateCodeType: _this.data.validateCodeType
    }

    if (this.data.checkInfo_type == 0) {
      //电商发送的验证码，发送接口校验电商的验证码
      $.Http.request($.HttpURL.checkValidateCode, params, false, function(res) {
        //校验接口，如果通过了，将手机号的值存在全局，并且展示弹出的跳转路径的页面
        var data = JSON.parse(decodeURIComponent($.f.Base64.atob(res.result)));
        if (data.checkValidateCode1.respCode == "01") {
          _this.setData({
            phoneWindowShow: false,
            userPhoneInput: data.phoneNumber,
            userPhone: data.phoneNumber
          })
          $.f.setglobalData('userPhone', data.phoneNumber)
          _this.bindPhone()
          _this.checkLogin()
        } else {
          $.f.showModal({
            'content': '验证未通过，请重新验证！'
          })
        }
      })
    } else {
      //电商没有发送验证码，发送验证码的是微信
      _this.information_checkMessage() //用户执行微信内容判断
    }
  },

  //用户执行微信内容判断
  information_checkMessage: function() {
    var that = this;
    if (that.data.checkInfoPhone != that.data.userPhoneInput) { //判断你输入的手机号和你发请求获取验证码的手机号是不是同一个
      $.f.showModal({
        title: "",
        content: "您的手机号和验证码不匹配，请查证后再次验证，谢谢！",
        confirmText: "OK"
      })
      return;
    }
    let params = {
      open_id: app.globalData.userOpenId,
      verifyCode: that.data.code
    }
		$.Http.request($.HttpURL.checkwxChatCode, params, false, function(res) {
      if (res.result == 1) {
        _this.setData({
          // signShow: true,
          phoneWindowShow: false,
          userPhoneInput: _this.data.checkInfoPhone,
          userPhone: _this.data.checkInfoPhone
        })
        $.f.setglobalData('userPhone', data.phoneNumber)
        _this.bindPhone()
        _this.checkLogin()
      } else if (res.result == 2) {
        $.f.showModal({
          title: "",
          content: "短信验证码已失效，请重新获取！",
          confirmText: "OK"
        })
        return;
      } else {
        $.f.showModal({
          title: "",
          content: "短信验证码不正确，请重新填写！",
          confirmText: "OK"
        })
        return;
      }
    })
  },
  //绑定手机号接口
  bindPhone: function() {
    const _this = this;
    var params = {
      phoneNumber: _this.data.userPhone,
      openId: app.globalData.userOpenId,
      unionId: app.globalData.userUnionId
    }
    $.Http.request($.HttpURL.bindPhone, params, false, function(res) {
      //返参证
      if (res.flag == 1) {
        //绑定成功
        _this.setData({
          signShow: true,
          phoneWindowShow: false,
        })
      }
    })
  },
  //关闭手机验证弹出窗口
  closePhoneWindow: function() {
    console.log("关闭手机号输入窗口")
    const _this = this;
    this.setData({
      phoneWindowShow: false
    })
  },

  //阅读规则转换
  isReadChange: function() {
    const _this = this;
    _this.setData({
      isRead: !_this.data.isRead
    })
  },
  //签到和立即抽奖跳转跳转到webview页面
  toSign: function(e) {
    const _this = this;
    _this.setData({
      signShow: false
    })
    //判断是调到抽奖还是签到页面
    if (e.currentTarget.dataset.type == "reward") {
      //抽奖
      let aurl = "https://hub.chinalife-p.com.cn/ydthtihroh/Home/JiuGongGe"
      var link = aurl + "?phoneNumber=" + this.data.userPhone
      $.f.webviewNew(link);
    } else if (e.currentTarget.dataset.type == "sign") {
      //首页
      let aurl = $.f.findlink('00001');
      // var params = 'xcx' + '%' + this.data.userPhone + '%' + app.globalData.userUnionId + '%' + app.globalData.userOpenId + '%' + '1'
      var params = this.data.userPhone + '_' + app.globalData.userId
      var link = aurl.replace('appeal', params)
      $.f.webviewNew(link);
    }
  },
  //点击活动规则
  goRules: function() {
    wx.navigateTo({
      url: '/pages/sign/sign',
    })
  },
  //点击签到有礼，判断情况是否直接跳转
  signClick: function() {
    //判断手机号是否存在
    const _this = this;
    if (_this.data.userPhone == "") {
      //没有输入手机号,显示输入框
      _this.setData({
        phoneWindowShow: true
      })
    } else {
      //跳转到签到页面，即首页
      if (!_this.data.signPut) return
      _this.data.signPut = false
      let aurl = $.f.findlink('00001');
      // var params = 'xcx' + '%' + this.data.userPhone + '%' + app.globalData.userUnionId + '%' + app.globalData.userOpenId + '%' + '1'
      var params = this.data.userPhone + '_' + app.globalData.userId
      var link = aurl.replace('appeal', params)
      console.log(link)
      $.f.webviewNew(link);
      setTimeout(function() {
        _this.data.signPut = true
      }, 2000)
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let _this = this;
    console.log("分享数据", options.shareobj)
    var aaa = decodeURIComponent(options.shareobj)
    console.log("分享解json数据", aaa)

    if (options.shareobj) { //如果有数据说明是分享过来的
      // var shareperson = "FX"+app.globalData.userUnionId
      var myshare = decodeURIComponent(options.shareobj).split("shareUnionid")[1].split(":")[1].split(",")[0]
      console.log(myshare)
      $.f.setglobalData('iffenxiang', 1) //保存全局是否是分享进入的
      $.f.setglobalData("myshares", myshare)
      _this.setData({
        ifshare: 1, //分享进入的标志
        // sharePerson: shareperson//从分享进入的加了FX
      })
      console.log(_this.sharePerson)
    }
    if (options.shareobj) {
      $.f.setglobalData('shareobj', options.shareobj);
      $.f.setglobalData('shareobj2', options.shareobj);
    }
    this.proandcity = this.selectComponent("#proandcity");
    this.loading = this.selectComponent("#loading");
    this.userloading = this.selectComponent("#userloading");
    app.checkSeeionkeyCallback = res => {
      console.log('app.checkSeeionkeyCallback')
      _this.userloadshoworhide(); //判断是否需要授权
      _this.getPhone();
    };
    app.userSeeionkeyCallback = res => {
      console.log('app.userSeeionkeyCallback')
      $.f.setglobalData('userSessionKey', res.session_key)
      $.f.setglobalData('userUnionId', res.unionid)
      $.f.setglobalData('userId', res.id)
      $.f.setglobalData('userOpenId', res.appopenid)
      $.f.setglobalData('userOpenIds', res.appopenids)
      $.f.setglobalData('userWxOpenId', res.wxopenid)
      $.f.setglobalData('userUserId', res.userid)

      $.f.setStorageSync('userSessionKey', res.session_key)
      $.f.setStorageSync('userUnionId', res.unionid)
      $.f.setStorageSync('userId', res.id)
      $.f.setStorageSync('userOpenId', res.appopenid)
      $.f.setStorageSync('userOpenIds', res.appopenids)
      $.f.setStorageSync('userWxOpenId', res.wxopenid)
      $.f.setStorageSync('userUserId', res.userid)
      wx.hideLoading();
      _this.userloadshoworhide(); //判断是否需要授权
      _this.getPhone();
    }
    _this.userloadshoworhide(); //判断是否需要授权
    _this.getPhone();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  signShow: function() {
    this.setData({
      signShow: app.globalData.signShow
    })
    console.log(this.data.signShow)
  },
  //查询用户信息
  getPhone: function() {
    const _this = this;
    let params = {
      openId: app.globalData.userOpenId,
    };
    if (app.globalData.userOpenId == "") return
    $.Http.request($.HttpURL.getphone, params, false, function(res) {
      console.log(res)
      if (res.result != "") {
        //如果不为空存储
        _this.setData({
          userPhone: res.result,
          phoneWindowShow: false
        })
        $.f.setglobalData('userPhone', res.result)
        _this.checkLogin()
      } else {
        if (app.globalData.userPhone == "") {
          _this.setData({
            phoneWindowShow: true
          })
          // setTimeout(function() {
          //   _this.setData({
          //     phoneWindowShow: true
          //   })
          // }, 80)
        }
      }
    })

  },
  //查询用户登录情况
  checkLogin: function() {
    const _this = this;
    let params = {
      openId: app.globalData.userOpenId,
      channelFlag: "03",
      operateType: "02",
      phoneNumber: app.globalData.userPhone,
      unionId: app.globalData.userUnionId
    };
    $.Http.request($.HttpURL.finishTask, params, false, function(res) {
      if (JSON.stringify(res) == "{}") return
      _this.setData({
        score: Number(res.result.score) + Number(_this.data.score),
      })
      $.f.setglobalData('score', res.result.score)
      //调用微信公众号接口
      if (_this.data.score != 0) {
        _this.setData({
          signShow: true
        })
      }
      // _this.wePubLoginCheck()
    })
  },
  // //查询微信公众号登录情况
  // wePubLoginCheck: function() {
  //   const _this = this;
  //   let params = {
  //     unionId: app.globalData.userUnionId,
  //     openId: app.globalData.userOpenId,
  //     channelFlag: "03",
  //     operateType: "01",
  // 		phoneNumber: app.globalData.userPhone
  //   };
  //   $.Http.request($.HttpURL.finishTask, params, false, function(res) {
  //     _this.setData({
  //       score: Number(_this.data.score) + Number(res.result.score)
  //     })
  //     $.f.setglobalData('score', _this.data.score)
  //     //判断有没有分数，确定是不是展示
  //     if (_this.data.score != 0) {
  //       _this.setData({
  //         signShow: true
  //       })
  //     }
  //   })
  // },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.comcodeafterfun(); //判断是否从选择分公司返回的
    this.setData({
      signShow: app.globalData.signShow,
      userPhone: app.globalData.userPhone
    })
    $.f.setglobalData('signShowMy', false)
    $.f.setglobalData('phoneWindowShowMy', false)
    $.f.setglobalData('signShowService', false)
    $.f.setglobalData('phoneWindowShowService', false)
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    let uid = app.globalData.userloading;
    if (uid) { //遮罩显示的情况下进行页面切换==点击关闭
      this.userloading.clickchoose();
    }
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
    setTimeout(function() {
      let params = {
        unionId: app.globalData.userUnionId,
        openId: app.globalData.userOpenId,
        channelFlag: "03",
        operateType: "04",
        phoneNumber: app.globalData.userPhone
      };
      $.Http.request($.HttpURL.finishTask, params, false, function(res) {
        // if (res.result.score == 30) {
        // 	//分享成功
        // 	wx.showToast({
        // 		title: '分享成功，恭喜获得10安心豆',
        // 	})
        // } else {
        // 	wx.showToast({
        // 		title: '您今日已分享3次，请明日再来！',
        // 	})
        // }
      })
    }, 1500)
    let timeobj = $.time.showDate(new Date());
    let Time = timeobj.a.replace(/\//g, '-') + ' ' + timeobj.d;
    let UnionId = app.globalData.userUnionId;
    if (UnionId == 'false' || UnionId == 'none' || UnionId == null || UnionId == undefined) {
      UnionId = '';
    }
    let obj = encodeURIComponent(JSON.stringify({
      shareOpenid: app.globalData.userOpenIds, //分享者openid
      shareUnionid: UnionId, //分享者UnionId
      shareTime: Time,
      sharePage: '/pages/index/index'
    }));
    let path = '/pages/index/index?shareobj=' + obj;
    return {
      path: path,
      imageUrl: $.imgurl + 'shareimg.png',
    }
  }
})