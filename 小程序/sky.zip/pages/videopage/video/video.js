// pages/videopage/video/video.js
const app = getApp();
const $ = app.global;
const innerAudioContext = wx.createInnerAudioContext();
innerAudioContext.loop = true;
innerAudioContext.volume = 0.4;
innerAudioContext.src = $.imgurl + 'ring.mp3';
Page({
    socketMsgQueue: [], //消息队列
    liveTimeoutTimer: undefined, //等待时间计时-16秒开始滚动,
    liveTimeoutTimer2: undefined, //等待时间计时-40秒停止滚动显示按钮,
    liveTimeoutTimer3: undefined, //等待时间计时-60秒强制结束开始滚动,
    liveTimeoutTimer4: undefined, //接通45秒上传记录定时器,
    interval: undefined, //滚动定时器
    pushCtx: undefined, //推流
    playCtx: undefined, //拉流
    socketConfig: false, //socket是否初始化
    socketopen: false, //socket是否以open
    activeClose: false, //是否主动关闭
    cmdclose: false, //客服挂断
    retryCount: 0, //重连次数
    heart: true, //第一次接收到心跳
    cmd2:true,//第一次收到接起时间
    phoneTel:'',//打日志用的
    sessionen: '', //登录态
    evaluate: {
        Satisfaction: false, //满意度标识
        actid: '', //任务编号
        sid: '', //会话标识id
        empCode: '', //用户ID
        agentCode: '', //座席工号
    },
    imageId:1,//图片编号
    /**
     * 页面的初始数据
     */
    data: {
        antext:'',//显示的文字状态
        imgurl: $.imgurl,
        animationData: {},
        SID: '', //会话标识id
        CaseID: '', //报案单号
        pushUrl: '', //推流地址
        playUrl: '', //拉流地址
        showimg: true, //等待图片
        showloading: false, //是否等待了很久
        showPusher: false, //是否显示推流
        showPlayer: false, //是否显示拉流
    },

    textRoll: function(top) { //文字滚动
        if (top == undefined || top == '' || top == null) {
            top = 50
        }
        var _this = this;
        _this.animation = wx.createAnimation();
        _this.animation.opacity(1).right('100%').step({
                duration: 8000
            })
            .opacity(0).right('-100%').step({
                duration: 1
            })
            .opacity(0).top(top + '%').step({
                duration: 1
            })
            .opacity(1).step({
                duration: 1
            });
        _this.setData({
            animationData: _this.animationanimation.export()
        });
    },
    textRollTime: function() { //文字滚动定时器
        var _this = this;
        _this.liveTimeoutTimer = setTimeout(function() { // 16秒开始滚动
            _this.liveTimeoutTimer = undefined;
            _this.interval = setInterval(function() {
                if (!_this.data.showloading) {
                    _this.setData({ //显示按钮
                        showloading: true
                    });
                }
                _this.textRoll(Math.round(Math.random() * 4 + 3) * 10)
            }, 8000)
        }, 8000);
        _this.liveTimeoutTimer2 = setTimeout(function() { // 设置40s结束滚动
            _this.liveTimeoutTimer2 = undefined;
            if (_this.interval != undefined) { //清除滚动计时器
                clearInterval(_this.interval);
                _this.interval = undefined;
            }
        }, 40000);
        _this.liveTimeoutTimer3 = setTimeout(function() { // 60秒强制结束
            _this.liveTimeoutTimer3 = undefined;
            _this.cleartime();//清除所有定时器
            if (_this.socketopen) _this.closeSocket();
            wx.redirectTo({
				url: '/pages/videopage/videobeforer/videobeforer?Un=video2'
            })
        }, 60000);
    },
    cleartime: function() { //清除所有定时器
        var _this = this;
        if (_this.liveTimeoutTimer != undefined) {
            clearTimeout(_this.liveTimeoutTimer);
            _this.liveTimeoutTimer = undefined;
        }
        if (_this.liveTimeoutTimer2 != undefined) {
            clearTimeout(_this.liveTimeoutTimer2);
            _this.liveTimeoutTimer2 = undefined;
        }
        if (_this.liveTimeoutTimer3 != undefined) {
            clearTimeout(_this.liveTimeoutTimer3);
            _this.liveTimeoutTimer3 = undefined;
        }
        if (_this.liveTimeoutTimer4 != undefined) {
            clearTimeout(_this.liveTimeoutTimer4);
            _this.liveTimeoutTimer4 = undefined;
        }
        if (_this.interval != undefined) {
            clearInterval(_this.interval);
            _this.interval = undefined;
        }
    },
    Socketconfig: function() { //websocket初始化
        var _this = this;
        if (_this.socketConfig) return
        _this.connectSocket();
        wx.onSocketOpen(function(res) { //监听WebSocket连接打开事件。
            _this.SocketOpen(res);
        });
        wx.onSocketError(function(res) { //监听WebSocket错误。
            _this.SocketError(res);
        });
        wx.onSocketMessage(function(res) { //监听WebSocket接受到服务器的消息事件。
            _this.SocketMessage(JSON.parse(res.data))
        });
        wx.onSocketClose(function(res) { //监听WebSocket已关闭。
            _this.SocketClose(res)
        });
        _this.socketConfig = true;
    },
    connectSocket: function() { //创建websocket
        wx.connectSocket({
            url: 'wss://' + $.webSplatform + '/' + $.AppID + '/websocket',
            data: {
                'session': this.sessionen
            }
        })
    },
    SocketOpen: function(data) { //WebSocket打开。
        var _this = this;
        _this.socketopen = true;
        for (var i = 0; i < _this.socketMsgQueue.length; i++) {
            _this.sendMsg(_this.socketMsgQueue[i])
        }
        _this.socketMsgQueue = [];
        console.log('WebSocket连接已打开！',data);
		_this.Launchvideo() //WebSocket打开后发起视频请求
    },
    SocketError: function(data) { //WebSocket错误。
        var _this = this;
        console.log('WebSocket连接打开失败，请检查！',data)
        _this.socketopen = false;
        if (!_this.activeClose && _this.retryCount < 2) { // 尝试重连2次
            console.log('重连')
            _this.connectSocket();
            _this.retryCount += 1;
            return true
        }
        if (!_this.activeClose && _this.retryCount == 2) { //重连也失败。服务出问题
            console.log('重连也失败。服务出问题')
            wx.showModal({
                title: '',
                content: '服务异常，请挂断视频退出重新尝试',
                showCancel: false,
            });
        }
    },
    SocketMessage: function(data) { //WebSocket接受到服务器的消息
        var _this = this;
        var cmd = data.cmd;
        if (cmd == 0) { //心跳
            if (_this.heart) {
                _this.heart = false;
                return true
            } else {
                return true
            }
        }
		console.log('接受到来自WebSocket的消息：',data)
        if (cmd == 2&&_this.cmd2) { //受理理赔视频
            _this.cleartime();
            _this.setData({
                SID: data.sid,
                CaseID: data.orderid,
                pushUrl: data.sendurl,
                playUrl: data.playurl,
                showimg: false,
                showPusher: true,
                antext: ''
            });
            innerAudioContext.stop(); //结束提示音
            //创建推拉流实例
            _this.pushCtx = wx.createLivePusherContext('pusher');
            _this.playCtx = wx.createLivePlayerContext('player');
            _this.createLive(); //开始推流
            _this.cmd2 = false;//开始推流后第一次接收的标志变为false(这全是电话中心导致的。为啥会返回好多次。。坑)
        }
        if (cmd == 3) { //文字消息
            data.msg = JSON.parse(data.msg);
            if (data.msg.id == '95D74152AA10A126EEF40CB3A3397ED5') { //满意度标识。
                console.log('收到评价标识')
                _this.evaluate.Satisfaction = true;
                _this.evaluate.actId = data.msg.actId;
                _this.evaluate.sid = data.msg.sid;
                _this.evaluate.empCode = data.msg.empCode;
                _this.evaluate.agentCode = data.msg.agentCode;
            }
            if (data.msg.id == 'FB11FDEBF98E9473D5EF45F67FDADC0A') { //快照上传标识
                console.log('收到快照标识')
                _this.snapshot(); //快照
            }
        }
        if (cmd == 5) { //结束聊天
            _this.cmdclose = true;
            _this.Endthechat()
        }
        try {
            $.xbossdebug.error(_this.phoneTel+'videoooooo+get' + JSON.stringify(data))
        } catch (e) { }
    },
    SocketClose: function(data) { //WebSocket已关闭
        var _this = this;
        console.log('WebSocket 已关闭！',data)
        _this.socketopen = false;
    },
    closeSocket: function() { //关闭WebSocket
        var _this = this
        _this.socketConfig = false;
        _this.socketopen = false;
        _this.activeClose = true;
        _this.socketMsgQueue = [];
        wx.closeSocket();
    },
    sendMsg: function(params) { //发送数据
        var _this = this;
        if (!_this.socketopen) {
            _this.socketMsgQueue = _this.socketMsgQueue.push(params)
            _this.connectSocket();
        } else {
			console.log('发送至WebSocket的消息：' + JSON.stringify(params))
            wx.sendSocketMessage({
                data: JSON.stringify(params)
            });
            try {
                $.xbossdebug.error(_this.phoneTel+'videoooooo+send' + JSON.stringify(params))
            } catch (e) { }
        }
    },
    getaddress: function() { //获取地区code
        var _this = this;
        let x = '110000';//地区国家行政区划表.先默认北京
        let ad1 = app.globalData.address;
        let ad2 = app.globalData.addressls;
        if (ad1 != null){//定位
            if (ad1.address_component.nation != '中国'){//海外
                x = 'areacode';
			} else if ($.f.judgecity(ad1.address_component.city)){//单列市
                x = (ad1.ad_info.adcode).substring(0,4) + '00';
            }else{
                x = (ad1.ad_info.adcode).substring(0, 2) + '0000';
            }
        }else{//选择
            if ($.f.judgecity(ad2[1].name)){//单列市
                x = ad2[1].code
            }else{
                x = ad2[0].code
            }
        }
        return  x
    },
	getlpseeion: function () {//获取发起理赔所需的seeion
		let _this = this;
		var params = {
			"appId": $.AppID,
            "phoneNumber": app.globalData.userPhone || '02161694627',
		};
		$.Http.request($.HttpURL.getSession, params, false, function (res) {
			_this.sessionen = res.data;
            _this.cmd2 = true;//发起后第一次接起的标志变为true(这全是电话中心导致的。为啥会返回好多次。。坑)
			_this.Socketconfig(); //初始化Socket
            try {
                _this.phoneTel = params.phoneNumber;
                res.getseeionrucan = params;
                $.xbossdebug.error(_this.phoneTel+'videoooooo+getSession' + JSON.stringify(res))
            } catch (e) { }
		})
	},
    Launchvideo: function() { //发起理赔视频
        console.log('发起理赔视频')
        var _this = this;
        let address = String(_this.getaddress());
        _this.cleartime();//先进行定时器的清除
        _this.sendMsg({
            cmd: 1,
            session: _this.sessionen,
            ext: address
        });
        _this.textRollTime(); //计定时开始
        _this.setData({
            antext: '接通中..'
        })
        innerAudioContext.play(); //播放提示音
    },
    pushStateChange: function(ret) { //推流控制
        console.log('推流' + ret.detail.code);
        if (ret.detail.code == 1002) { //推流成功
            console.log('推流成功2');
        } else if (ret.detail.code == -1307) //网络断连，且经多次重连抢救无效，更多重试请自行重启推流
        {
            console.log('重新推流2');
            this.pushCtx.start(); //重新推流
        } else if (ret.detail.code < 0) { //推流失败
            console.log('推流失败重新推流3');
            this.pushCtx.start(); //重新推流
        }
        try {
            $.xbossdebug.error(this.phoneTel +'videoooooo+pushStateChange' + ret.detail.code)
        } catch (e) { }
    },
    pushError: function (ret){
        let _this = this;
        console.log(ret)
        if (ret.detail.errCode == 10004 || ret.detail.errCode == 10003 || ret.detail.errCode == '10004' || ret.detail.errCode == '10003') {
            _this.pushCtx.start(); //可能是10004造成的。问题不大重新推流
        }
        try {
            let obj = {
                SID:_this.data.SID,
                CaseID: _this.data.CaseID,
                pushUrl: _this.data.pushUrl,
                playUrl: _this.data.playUrl,
                tel: _this.phoneTel,
                videoooooo:'videoooooo+pushError'
            }
            ret.thisobj = obj
            $.xbossdebug.error(ret)
        } catch (e) { }
    },
    playStateChange: function(ret) { //拉流控制
        console.log('拉流' + ret.detail.code);
        if (ret.detail.code == 2004) {
            console.log('拉流成功2');
        } else if (ret.detail.code == -2301) //网络断连，且经多次重连抢救无效，更多重试请自行重启播放
        {
            console.log('重新拉流2');
            this.playCtx.play(); //重新拉流
        } else if (ret.detail.code < 0) { //拉流失败
            console.log('拉流失败重新拉流3');
            this.playCtx.play(); //重新拉流
        }
        try {
            $.xbossdebug.error(this.phoneTel +'videoooooo+playStateChange' + ret.detail.code)
        } catch (e) { }
    },
    createLive: function() { //开始视频聊天
        var _this = this;
        console.log('开始推流')
        _this.pushCtx.start({ //开始推流
            success: function() {
                console.log('推流成功1')
            },
            fail: function() {
                console.log('推流失败1')
            },
            complete: function() {
                console.log('开始拉流')
                _this.setData({
                    showPlayer: true,
                });
                _this.playCtx.play({ //开始拉流
                    success: function() {
                        console.log('拉流成功1')
                    },
                    fail: function() {
                        console.log('拉流失败1')
                    },
                });
            }
        });
        _this.liveTimeoutTimer4 = setTimeout(function () { // 视频超过45秒上传视频记录.由于延迟增加3秒
            app.sharepush('video');
            clearTimeout(_this.liveTimeoutTimer4);
            _this.liveTimeoutTimer4 = undefined;;//请求成功后清除4号定时器
        }, 48000);
    },
    switchCameraTap: function() { //切换摄像头
        this.pushCtx.switchCamera();
    },
    Endchat: function() { //放弃呼叫
        var _this = this;
        try {
            $.xbossdebug.error(_this.phoneTel + 'videoooooo+放弃呼叫')
        } catch (e) { }
        _this.cleartime();
        if (_this.socketopen) _this.closeSocket();
        wx.redirectTo({
			url: '/pages/videopage/videobeforer/videobeforer?Un=video'
        })
    },
    makePhoneCall: function() { //拨打电话
        var _this = this;
        wx.makePhoneCall({
			phoneNumber: $.tel,
            success: function() {
                console.log("成功拨打电话");
                try {
                    $.xbossdebug.error(_this.phoneTel + 'videoooooo+拨打电话')
                } catch (e) { }
                _this.Endchat()
            },
        })
    },
    customchat: function() { //人工聊天
        var _this = this;
        let city = '';
        let lng = '';
        let lat = '';
        let phone = app.globalData.userPhone || '';
        let name = app.globalData.userName || '';
        try {
            if (app.globalData.address == null && app.globalData.addressls == null) {//没定位没选择
                city = ''
            } else if (app.globalData.address == null && app.globalData.addressls != null) {//未定位, 已选择
                city = $.f.getproandcity(app.globalData.addressls[0].name)
            } else {
                city = app.globalData.address.address;
                lat = app.globalData.address.location.lat;
                lng = app.globalData.address.location.lng;
            }
        } catch (e) {}
        wx.navigateToMiniProgram({
            appId: $.glappid1,
            path: '',
            extraData: {
                userName: name,
                city: city,
                lng: lng,
                lat: lat,
                phone: phone,
                userId: app.globalData.userUserId,
                channel: '001'
            },
            success(res) {
                try {
                    $.xbossdebug.error(_this.phoneTel + 'videoooooo+人工聊天')
                } catch (e) { }
                _this.Endchat();
            },
        })
    },
    Endthechat: function() { //结束视频聊天
        var _this = this;
        try {
            $.xbossdebug.error(_this.phoneTel + 'videoooooo+结束视频聊天')
        } catch (e) { }
        if (_this.socketopen) {
            if (!_this.cmdclose) { //客服结束的就不发
                _this.sendMsg({
                    cmd: 4,
                    sid: _this.data.SID
                })
            }
            if (_this.data.showPusher) {
                _this.pushCtx.stop();
                _this.playCtx.stop();
            }
            _this.closeSocket();
        }
        if (_this.evaluate.Satisfaction == true) {
            wx.redirectTo({
				url: '/pages/videopage/evaluate/evaluate?sid=' + _this.evaluate.sid + '&empCode=' + _this.evaluate.empCode + '&agentCode=' + _this.evaluate.agentCode + '&actId=' + _this.evaluate.actId
            })
        } else {
            wx.redirectTo({
				url: '/pages/videopage/videobeforer/videobeforer?Un=video'
            })
        }
    },
    snapshot: function() { //快照
        let _this = this;
        try {
            $.xbossdebug.error(_this.phoneTel+'videoooooo+开始截屏')
        } catch (e) { }
        _this.pushCtx.snapshot({
            success: function(res) {
                try {
                    $.xbossdebug.error(_this.phoneTel+'videoooooo+截屏成功' + JSON.stringify(res))
                } catch (e) { }
                var path = res.tempImagePath;
                _this.uploadimg(path);//上传图片
            },
            fail:function(res) {
                try {
                    $.xbossdebug.error(_this.phoneTel+'videoooooo+截屏失败' + JSON.stringify(res))
                } catch (e) { }
            }
        });
    },
    uploadimg :function(x){//上传图片
        let _this = this;
        let params = {
            sid:_this.data.SID,
            type: _this.imageId.toString(),
        }
        try {
            $.xbossdebug.error(_this.phoneTel+'videoooooo+开始上传截屏')
        } catch (e) {}
        $.Http.uploadfile(params,x,function(res){
            if (res.error == 0) {
                _this.imageId++;
                 $.f.showToast('截屏上传成功','success');
                try {
                    $.xbossdebug.error(_this.phoneTel + 'videoooooo+截屏上传成功' + JSON.stringify(res))
                } catch (e) { }
            } else {
                 $.f.showToast('截屏上传失败');
                try {
                    $.xbossdebug.error(_this.phoneTel + 'videoooooo+截屏上传失败' + JSON.stringify(res))
                } catch (e) { }
            }
        })
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log('onload')
        this.getlpseeion(); //获取视频登录态
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        console.log('onready')
    },
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        console.log('show')
        wx.setKeepScreenOn({ //防止熄屏
            keepScreenOn: true
        });
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
        console.log('onhide')
        wx.setKeepScreenOn({
            keepScreenOn: false
        });
    },
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
        console.log('onUnload')
        innerAudioContext.stop();
        this.setData({
            antext:''
        })
		this.cleartime();
		if (this.socketopen) this.closeSocket();
    },
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },


})