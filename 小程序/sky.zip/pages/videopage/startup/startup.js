Page({
    data: {},
    onShow: function () {//废弃页面，可能还被分公司引用着。直接去首页
        wx.switchTab({
            url: '/pages/index/index',
        })
    },
})