// pages/videopage/phonenum/phonenum.js
const app = getApp();
const $ = app.global;
const SmsCodeTimeSpan = 60;
Page({
  phone: '',
  smsCode: '',
  nextPageType: 0,
  timerID: 0,
  countDown: SmsCodeTimeSpan,
  /**
   * 页面的初始数据
   */
  data: {
      imgurl: $.imgurl,
    code:'',
    sendSmsCodeBtnText: '获取验证码',
    loginBtnDisabled: true,//登录按钮是否可点击
    codeBtnDisabled: true,//验证码按钮是否可点击
    phonereadonly:false,//手机号码是否可修改
    codereadonly: true,//验证码是否可修改
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  // 检查参数
  checkPhone: function () {
    if (this.phone.length == 0) {
      $.f.showModal({
        'content': '请输入手机号码'
      })
      return false;
    }
    return true;
  },
  checkSmsCode: function () {
    if (this.smsCode.length == 0) {
      $.f.showModal({
        'content': '请输入验证码'
      })
      return false;
    }
    return true;
  },
  // 获取验证码
  sendSmsCodeTap: function () {
    if (this.data.codeBtnDisabled) {
      return;
    }
    this.startCountDown();
  },
  // 发送验证码倒计时
  startCountDown: function () {
    if (this.timerID != 0) return;
    this.getorsendcode(this.phone, '');//发送请求
    // 点击后立刻倒计时
    this.setData({
      codeBtnDisabled: true,//验证码按钮不可点击
      phonereadonly: false,//手机号可编辑(额，这里原来改为true不让改了)
      codereadonly:false,//验证码可编辑
    });
    if (this.countDown == SmsCodeTimeSpan) {
      this.setData({
        sendSmsCodeBtnText: '(' + this.countDown + 's)',
      });
      this.countDown--;
    }
    var _this = this;
    this.timerID = setInterval(function () {
      _this.setData({
        sendSmsCodeBtnText: '(' + _this.countDown + 's)',
      });
      _this.countDown--;
      if (_this.countDown == 0) {
        _this.stopCountDown();
      }
    }, 1000);
  },

  stopCountDown: function () {
    if (this.timerID == 0) return;
    clearInterval(this.timerID);
    this.timerID = 0;
    this.countDown = SmsCodeTimeSpan;
    this.setData({
      sendSmsCodeBtnDisabled: false,
      sendSmsCodeBtnText: '获取验证码',
      codeBtnDisabled: false
    });
  },
  checkvcodeBtn: function () {//获取验证码按钮验证
    if (this.phone.length > 10 ) {
      this.setData({
        codeBtnDisabled: false
      });
    }else{
      this.setData({
        codeBtnDisabled: true
      });
    }
  },
  checkLoginBtn: function () {//登录按钮验证
    var disabeled = true;
    if (this.phone.length > 0 && this.smsCode.length > 0 ) {
      disabeled = false;
    }
    this.setData({
      loginBtnDisabled: disabeled
    });
  },
  // 输入监听
  phoneInput: function (e) {
    this.phone = e.detail.value;
    this.checkvcodeBtn();
  },
  smsCodeInput: function (e) {
    this.smsCode = e.detail.value;
    this.checkLoginBtn();
  },
  //登录
  loginTap:function(){
    var _this=this
    console.log(_this.phone)
    console.log(_this.smsCode)
    _this.getorsendcode(_this.phone,_this.smsCode)
  },

  getorsendcode:function(X,Y){//获取或验证验证码
    var _this=this
    var params = {
        'mobile_Phone': X,
        'checkCode': Y,
        'open_id': app.globalData.userOpenId,
    };
    $.Http.request($.HttpURL.getCheckCode, params, false, function (res) {
        if (res.result == '0') {
            $.f.showModal({
                content: '获取验证码失败，请稍候再试',
            })
        }
      if (res.result == '3') {
            $.f.showModal({
                content: '间隔小于60s，获取验证码失败',
            })
        }
      if (res.result == '4') {
            $.f.showModal({
                content: '验证码不匹配，请核对后再试',
            })
        }
      if (res.result == '1') {
        wx.showToast({
          title: '已发送',
          icon: 'success',
        })
      }
      if (res.result == '2') {
        $.f.setglobalData('userPhone', X)
        $.f.setStorageSync('userPhone', X)
        wx.redirectTo({
			url: '/pages/videopage/videobeforer/videobeforer'
        })
      }
    })
  },
})