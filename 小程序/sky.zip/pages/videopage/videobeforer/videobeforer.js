// pages/videopage/videobeforer/videobeforer.js
const app = getApp();
const $ = app.global;
Page({
    /**
     * 页面的初始数据
     */
    data: {
        imgurl: $.imgurl,
		btngovideo:true,
        proandcityrank: '2',//地区选择组件层级
    },
    showactionsheet: function () {//选择地区组件显示
        this.proandcity.show();
    },
    _confirmproandcity(e) {//选择地区组件确认事件
        $.f.setglobalData('addressls', e.detail);//存储选择的临时位置
		this.getsetgovideo();
    },
	govideo: function (){//前往视频页
		// if (!this.time_range("08:00", "18:00")) {
		if (!this.time_range("08:00", "24:00")) {
			$.f.showModal({
				content: '亲爱的客官，现在是我下班充电时刻，请客官明天08:00 至 18:00再来吧，我们将以饱满的精神迎接您。或者客官也可拨打24小时服务热线：95519，由我的小伙伴们为您服务。',
			})
			return true
		}
		if (app.globalData.address == null && app.globalData.addressls == null){//未定位，未选择让用户选择
			this.showactionsheet();
			return true
		}
		this.getsetgovideo();
	},
	getsetgovideo: function () {//获取各权限的状态判断是否去视频
		wx.getSetting({//获取各权限的状态
			success: (res) => {
				console.log(res);
				if (!res.authSetting["scope.camera"] || !res.authSetting["scope.record"]) {
                    wx.redirectTo({
						url: '/pages/videopage/empower/empower'
					})
				} else {
					console.log('相机录音权限已获得')
					wx.redirectTo({
						// url: '/pages/videopage/video/video'
						url: '/pages/videopage/video2/video2'
					})
				}
			}
		})
	},
	getPhoneNumber: function (e) {//手机号授权
		var _this = this
		console.log(e);
		if (e.detail.encryptedData == '' || e.detail.encryptedData == undefined || e.detail.encryptedData == null) {//不同意授权转到输入页
			console.log('用户不同意授权')
			wx.redirectTo({
				url: '/pages/videopage/phonenum/phonenum'
			})
		} else {//同意授权
			console.log('用户同意授权')
			var encryptedData = e.detail.encryptedData;
			var iv = e.detail.iv;
			var data = $.f.decipher(encryptedData, iv)
			$.f.setglobalData('userPhone', data.phoneNumber)
			$.f.setStorageSync('userPhone', data.phoneNumber)
            _this.setData({
                btngovideo:true
            })
			_this.govideo();//前往视频页
		}
	},




	time_range: function (beginTime, endTime) {//视频时间段判断
		var strb = beginTime.split(":");
		var stre = endTime.split(":");

		var b = new Date();
		var e = new Date();
		var n = new Date();

		b.setHours(strb[0]);
		b.setMinutes(strb[1]);
		e.setHours(stre[0]);
		e.setMinutes(stre[1]);

		if (n.getTime() - b.getTime() > 0 && n.getTime() - e.getTime() < 0) {
			return true;
		} else {
			// console.log("当前时间是：" + n.getHours() + ":" + n.getMinutes() + "，不在该时间范围内！");
			return false;
		}
	},
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
		let un='';
		if (app.globalData.userPhone == '') {
			console.log('未获取到手机号');
			this.setData({
				btngovideo:false
			})
		}
		console.log(options)
		if (options) {un = options.Un;}
		if (un == 'video2') {//繁忙提示
			$.f.showModal({
				content: '十分抱歉当前坐席忙,请您稍后再次尝试连接！',
			})
		}
		if (un == 'video' || un == 'eval' || un == 'video2') {
			//表明肯定不是第一次进入，无需进行后续的授权验证
			return true
		}
		// 可以通过 wx.getSetting 先查询一下用户是否授权了 "scope.record" 这个 scope
		wx.getSetting({
			success(res) {
				if (!res.authSetting['scope.record']) {
					wx.authorize({
						scope: 'scope.record',
						success() {
							// 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
							wx.startRecord()
						},
						fail() {
							//用户拒绝录音权限
							console.log('用户拒绝录音权限');
						}
					})
				}
			}
		})

		// 可以通过 wx.getSetting 先查询一下用户是否授权了 "scope.camera" 这个 scope
		wx.getSetting({
			success(res) {
				if (!res.authSetting['scope.camera']) {
					wx.authorize({
						scope: 'scope.camera',
						success() {
							// 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
							wx.startRecord()
						},
						fail() {
							//用户拒绝摄像头权限
							console.log('用户拒绝摄像头权限');
						}
					})
				}
			}
		})
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        this.proandcity = this.selectComponent("#proandcity");
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})