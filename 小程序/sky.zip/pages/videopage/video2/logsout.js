const app = getApp();
const $ = app.global;
const phoneTel=app.globalData.userPhone || '02161694627'
module.exports =function(obj){
  console.log(obj)
  // return
  try {
    $.xbossdebug.error(`${phoneTel}======>${JSON.stringify(obj)}`)
  } catch (e) { }
}