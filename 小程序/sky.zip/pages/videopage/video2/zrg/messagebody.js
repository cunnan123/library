module.exports = {
  "nested": {
    "MessageBody": {
      "fields": {
        "title": {
          "type": "string",
          "id": 1
        },
        "content": {
          "type": "string",
          "id": 2
        },
        "time": {
          "type": "string",
          "id": 3
        },
        "type": {
          "type": "uint32",
          "id": 4
        },
        "extend": {
          "type": "string",
          "id": 5
        },
        "cid": {
          "type": "string",
          "id": 6
        }
      }
    }
  }
}