module.exports = {
  "nested": {
    "Model": {
      "fields": {
        "version": {
          "type": "string",
          "id": 1
        },
        "deviceId": {
          "type": "string",
          "id": 2
        },
        "cmd": {
          "type": "uint32",
          "id": 3
        },
        "sender": {
          "type": "string",
          "id": 4
        },
        "receiver": {
          "type": "string",
          "id": 5
        },
        "groupId": {
          "type": "string",
          "id": 6
        },
        "msgtype": {
          "type": "uint32",
          "id": 7
        },
        "flag": {
          "type": "uint32",
          "id": 8
        },
        "platform": {
          "type": "string",
          "id": 9
        },
        "platformVersion": {
          "type": "string",
          "id": 10
        },
        "token": {
          "type": "string",
          "id": 11
        },
        "appKey": {
          "type": "string",
          "id": 12
        },
        "timeStamp": {
          "type": "string",
          "id": 13
        },
        "sign": {
          "type": "string",
          "id": 14
        },
        "content": {
          "type": "bytes",
          "id": 15
        },
        "chatModel": {
          "type": "uint32",
          "id": 16
        },
        "userType": {
          "type": "uint32",
          "id": 17
        },
        "route": {
          "type": "uint32",
          "id": 18
        },
        "agent": {
          "type": "string",
          "id": 19
        },
        "sourceNo": {
          "type": "string",
          "id": 20
        },
        "isAutoConnect": {
          "type": "uint32",
          "id": 21
        },
        "isAllowChat": {
          "type": "uint32",
          "id": 22
        }
      }
    }
  }
}