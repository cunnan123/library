const app = getApp();
const $ = app.global;
const logsout = require('./logsout.js')
const innerAudioContext = wx.createInnerAudioContext();
innerAudioContext.loop = true;
innerAudioContext.volume = 0.4;
innerAudioContext.src = $.imgurl + 'ring.mp3';


var protobuf = require('zrg/protobuf.js');
var zrgmessageConfig = require('zrg/message.js')
var zrgmessagebodyConfig = require('zrg/messagebody.js')
var zrgMessageRoot = protobuf.Root.fromJSON(zrgmessageConfig);
var zrgMessagebodyRoot = protobuf.Root.fromJSON(zrgmessagebodyConfig);
var zrgMessage = zrgMessageRoot.lookupType("Model");
var zrgMessagebody = zrgMessagebodyRoot.lookupType("MessageBody");
var vcSocketTask, zrgSocketTask;
Page({
  liveTimeoutTimer: undefined, //等待时间计时-16秒开始滚动,
  liveTimeoutTimer2: undefined, //等待时间计时-40秒停止滚动显示按钮,
  liveTimeoutTimer3: undefined, //等待时间计时-60秒强制结束开始滚动,
  liveTimeoutTimer4: undefined, //接通45秒上传记录定时器,
  interval: undefined, //滚动定时器

  phoneTel: '', //用户标识，查找日志用
  cmdclose: false, //坐席结束聊天
  evaluate: { //满意度
    SatisfactionURL: ''
  },
  zrgFlag: true,
  zrgCount: 1,//用于区分是否是首次链接socket,以确认是否执行关闭socket
  // vcFlag: true,
  imageId: 1, //图片编号

  data: {
    imgurl: $.imgurl,
    showimg: true, //等待图片
    antext: '', //显示的文字状态
    animationData: {},
    showloading: false, //是否等待了很久
    showPusher: false, //是否显示推流
    showPlayer: false, //是否显示拉流


    base_src: '',
    play_src: '', //rtmp://58.132.215.93:1935/live...vhost...players/demo.mcs710010
    push_src: '', //'rtmp://58.132.215.93:1935/live...vhost...players/demo.mcs710011',
    player_url: '',
    pusher_url: '',
    connect_info: '智能视频客服开始服务',
    close_info: '当前服务停止',
    faceresult: "-1",
    vc_ws_url: '', //视频信令地址
    vc_ws_open: false, //是否连接视频信令
    zrg_ws_url: '', //转人工服务地址
    zrg_ws_open: false, //是否连接转人工服务

    roomId: '', //分配会议号码
    videoUser: '', //视频账号
    videoUserToken: '', //用户token,

    userId: '', //用户唯一识别账号openId
    nickname: '', //请求客户名称,
    areaNo: '', //请求客户地区编码
    phoneNo: '', //请求客户手机号,
    timestamp: '', //请求时间戳
    signature: '', //签名
    nonce: '123eqweqwe', //随机数
    token: 'w7s_jrhM-792C9T6', //token

    sessionId: "",
    chatSeessionID: '', //会话标识id
  },

  // 接通前响铃并计时
  ringAndTime: function() {
    var that = this;
    that.cleartime(); //定时器清除
    that.textRollTime(); //接通前计时开始
    that.setData({
      antext: '接通中..'
    });
    innerAudioContext.play(); //响铃
    logsout({
      method: 'ringAndTime',
      detail: {
        info: '接通前响铃并计时',
        inParams: '',
        outParams: ''
      }
    })
  },
  //拨打电话
  makePhoneCall: function() {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: $.tel,
      success: function() {
        that.Endchat()
      },
    })
    logsout({
      method: 'makePhoneCall',
      detail: {
        info: '拨打电话',
        inParams: '',
        outParams: ''
      }
    })
  },
  //人工聊天
  customchat: function() { //人工聊天
    var that = this;
    let city = '';
    let lng = '';
    let lat = '';
    let phone = app.globalData.userPhone || '';
    let name = app.globalData.userName || '';
    try {
      if (app.globalData.address == null && app.globalData.addressls == null) { //没定位没选择
        city = ''
      } else if (app.globalData.address == null && app.globalData.addressls != null) { //未定位, 已选择
        city = $.f.getproandcity(app.globalData.addressls[0].name)
      } else {
        city = app.globalData.address.address;
        lat = app.globalData.address.location.lat;
        lng = app.globalData.address.location.lng;
      }
    } catch (e) {}
    wx.navigateToMiniProgram({
      appId: $.glappid1,
      path: '',
      extraData: {
        userName: name,
        city: city,
        lng: lng,
        lat: lat,
        phone: phone,
        userId: app.globalData.userUserId,
        channel: '001'
      },
      success(res) {
        that.Endchat();
      },
    })

    logsout({
      method: 'customchat',
      detail: {
        info: '人工聊天',
        inParams: '',
        outParams: ''
      }
    })
  },
  // 接通前客户挂断
  Endchat: function() {
    var that = this;
    that.Unload();
    wx.redirectTo({
      url: '/pages/videopage/videobeforer/videobeforer?Un=video'
    })
    logsout({
      method: 'Endchat',
      detail: {
        info: '接通前客户挂断',
        inParams: '',
        outParams: ''
      }
    })
  },
  // 接通前强制挂断
  Endchat2: function() {
    var that = this;
    that.Unload();
    wx.redirectTo({
      url: '/pages/videopage/videobeforer/videobeforer?Un=video2'
    })
    logsout({
      method: 'Endchat2',
      detail: {
        info: '接通前强制挂断',
        inParams: '',
        outParams: ''
      }
    })
  },
  // onUnload处理
  Unload: function() {
    var that = this;
    that.cleartime();
    innerAudioContext.stop();
    that.setData({
      antext: ''
    });
    that.closeSocket();
    logsout({
      method: 'Unload',
      detail: {
        info: 'onUnload处理',
        inParams: '',
        outParams: ''
      }
    })
  },
  //清除定时器
  cleartime: function() {
    var that = this;
    if (that.liveTimeoutTimer != undefined) {
      clearTimeout(that.liveTimeoutTimer);
      that.liveTimeoutTimer = undefined;
    }
    if (that.liveTimeoutTimer2 != undefined) {
      clearTimeout(that.liveTimeoutTimer2);
      that.liveTimeoutTimer2 = undefined;
    }
    if (that.liveTimeoutTimer3 != undefined) {
      clearTimeout(that.liveTimeoutTimer3);
      that.liveTimeoutTimer3 = undefined;
    }
    if (that.liveTimeoutTimer4 != undefined) {
      clearTimeout(that.liveTimeoutTimer4);
      that.liveTimeoutTimer4 = undefined;
    }
    if (that.interval != undefined) {
      clearInterval(that.interval);
      that.interval = undefined;
    }
    logsout({
      method: 'cleartime',
      detail: {
        info: '清除定时器',
        inParams: '',
        outParams: ''
      }
    })
  },
  //接通前计时
  textRollTime: function() { //文字滚动定时器
    var that = this;
    that.liveTimeoutTimer = setTimeout(function() { // 16秒开始滚动
      that.liveTimeoutTimer = undefined;
      that.interval = setInterval(function() {
        if (!that.data.showloading) {
          that.setData({ //显示按钮
            showloading: true
          });
        }
        that.textRoll(Math.round(Math.random() * 4 + 3) * 10)
      }, 8000)
    }, 8000);
    that.liveTimeoutTimer2 = setTimeout(function() { // 设置40s结束滚动
      that.liveTimeoutTimer2 = undefined;
      if (that.interval != undefined) { //清除滚动计时器
        clearInterval(that.interval);
        that.interval = undefined;
      }
    }, 40000);
    that.liveTimeoutTimer3 = setTimeout(function() { // 60秒强制结束
      that.liveTimeoutTimer3 = undefined;
      that.Endchat2();
    }, 60000);
    logsout({
      method: 'textRollTime',
      detail: {
        info: '文字滚动定时器',
        inParams: '',
        outParams: ''
      }
    })
  },
  //文字滚动
  textRoll: function(top) {
    var that = this;
    if (top == undefined || top == '' || top == null) {
      top = 50
    }
    that.animation = wx.createAnimation();
    that.animation.opacity(1).right('100%').step({
        duration: 8000
      })
      .opacity(0).right('-100%').step({
        duration: 1
      })
      .opacity(0).top(top + '%').step({
        duration: 1
      })
      .opacity(1).step({
        duration: 1
      });
    that.setData({
      animationData: that.animation.export()
    });
    logsout({
      method: 'textRoll',
      detail: {
        info: '文字滚动',
        inParams: '',
        outParams: ''
      }
    })
  },


  //连接socket
  connectSocket: function() {

    var that = this;
    var data = {
      vc_ws_url: $.vc_ws_url, //视频信令地址
      zrg_ws_url: $.zrg_ws_url, //转人工服务地址
      base_src: $.base_src, //base_src
    }
    that.setData(data, function() {
      var zrgAndVc = setInterval(function() { //socket.onOpen有效使用时，清除socket连接定时器
        if (!that.zrgFlag) { //转人工socket.onOpen是否有效标识
          clearInterval(zrgAndVc)
          return
        }
        if (that.zrgCount!=1) {
          that.closeSocket();
        }
        var zrgAndVc2 = setTimeout(function() {
          that.connectZrg(); //连接转人工websocket
          that.connect_vc(); //连接视频websocket
          
          logsout({
            method: 'connectSocket',
            detail: {
              info: '连接socket',
              inParams: data,
              outParams: {zrgCount:that.zrgCount}
            }
          })
          clearTimeout(zrgAndVc2)
        },500)

      }, 2500)

    });

  },
  //初始化socket
  // initSocket: function () {
  //   var that = this;
  //   // setTimeout(function(){

  //     that.initZrgEvent();
  //     that.initVCEvent();
  //     try {
  //       $.xbossdebug.error(`
  //     ===========${that.phoneTel}=====initSocket======>
  //     `)
  //     } catch (e) { }
  //   // },500)

  // },
  //关闭socket
  closeSocket: function() {
    var that = this;
    if (vcSocketTask != null && that.data.vc_ws_open) {
      vcSocketTask.close({
        success: function() {
          logsout({
            method: 'closeSocket',
            detail: {
              info: '关闭视频socket成功',
              inParams: '',
              outParams: ''
            }
          })
        },
        fail: function() {
          logsout({
            method: 'closeSocket',
            detail: {
              info: '关闭视频socket失败',
              inParams: '',
              outParams: ''
            }
          })
        },
        complete: function() {}
      });
      that.data.vc_ws_open = false;
    }
    if (zrgSocketTask != null && that.data.zrg_ws_open) {
      zrgSocketTask.close({
        success: function() {
          logsout({
            method: 'closeSocket',
            detail: {
              info: '关闭转人工socket成功',
              inParams: '',
              outParams: ''
            }
          })
        },
        fail: function() {
          logsout({
            method: 'closeSocket',
            detail: {
              info: '关闭转人工socket失败',
              inParams: '',
              outParams: ''
            }
          })
        },
        complete: function() {

        }
      });
      that.data.vc_ws_open = false;
    }
  },
  /**
   * zrg socket部分
   */
  //连接转人工服务
  connectZrg() {
    var that = this;
    zrgSocketTask = wx.connectSocket({
      url: that.data.zrg_ws_url,
      header: {
        'content-type': 'application/json'
      },
      method: "GET",
      success() {
        that.setData({
          zrg_ws_open: true
        }, function() {
          that.initZrgEvent();
        })
        logsout({
          method: 'connectZrg',
          detail: {
            info: '转人工socket连接成功',
            inParams: {
              url: that.data.zrg_ws_url
            },
            outParams: ''
          }
        })
      },
      fail() {
        that.data.zrg_ws_open = false;
        that.reconnect_zrg();
        logsout({
          method: 'connectZrg',
          detail: {
            info: '转人工socket连接失败',
            inParams: {
              url: that.data.zrg_ws_url
            },
            outParams: ''
          }
        })
      },
      complete: function(res) {},

    })
  },
  //重连转人工服务
  reconnect_zrg() {
    var that = this;
    if (that.data.zrg_ws_open) return;
    that.data.zrg_ws_open = true;
    //没连接上会一直重连，设置延迟避免请求过多
    setTimeout(function() {

      that.connectZrg();
      that.data.zrg_ws_open = false;
      logsout({
        method: 'reconnect_zrg',
        detail: {
          info: '重新连接转人工socket',
          inParams: '',
          outParams: ''
        }
      })
    }, 2000);
  },
  //初始化转人工服务
  initZrgEvent() {
    var that = this;
    zrgSocketTask.onOpen(res => {
      that.zrgFlag = false; //转人工socket自动关闭问题
      that.zrgCount++;
      that.data.zrg_ws_open = true;
      that.zrgRequest(); //转人工
      logsout({
        method: 'initZrgEvent',
        detail: {
          info: '转人工socket 打开,发起转人工请求',
          inParams: '',
          outParams: ''
        }
      })
    })
    zrgSocketTask.onClose(onClose => {

      that.data.zrg_ws_open = false;
      logsout({
        method: 'initZrgEvent',
        detail: {
          info: '转人工socket 关闭',
          inParams: '',
          outParams: onClose
        }
      })
    })
    zrgSocketTask.onError(onError => {

      this.data.zrg_ws_open = false;
      that.reconnect_zrg();
      logsout({
        method: 'initZrgEvent',
        detail: {
          info: '转人工socket 报错，重新连接转人工socket',
          inParams: '',
          outParams: onError
        }
      })
    })
    zrgSocketTask.onMessage(onMessage => {
      var message = onMessage.data
      if (message instanceof ArrayBuffer) {
        var msg = zrgMessage.decode(message); //如果后端发送的是二进制帧（protobuf）会收到前面定义的类型
        // var content = zrgMessage.decode(msg.content);
        var content = zrgMessagebody.decode(msg.content).content;

        //心跳消息
        if (msg.cmd == 2) {
          //发送心跳回应
          var message1 = {
            "cmd": 2,
            "msgtype": 4
          };
          var message = zrgMessage.create(message1);
          var buffer = zrgMessage.encode(message).finish();
          that.sendZrgMessage(buffer);

          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 心跳',
              inParams: '',
              outParams: message1
            }
          })
        } else if (msg.cmd == 300) { //客户成功分配座席
          var data = JSON.parse(content);

          that.data.roomId = data.roomId;
          that.data.videoUser = data.videoUser;
          that.data.videoUserToken = data.videoUserToken;
          that.data.chatSeessionID = data.chatSessionId; //会话标识id
          that.send_vc(data);
          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 客户成功分配座席',
              inParams: '',
              outParams: data
            }
          })
        } else if (msg.cmd == 301) { //等待坐席进线
          var data = JSON.parse(content);

          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 等待坐席进线',
              inParams: '',
              outParams: data
            }
          })
        } else if (msg.cmd == 307) { //会话超时提醒
          var data = JSON.parse(content);

          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 会话超时提醒',
              inParams: '',
              outParams: data
            }
          })
        } else if (msg.cmd == 308) { //会话超时，结束会话提醒
          var data = JSON.parse(content);

          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 会话超时，结束会话提醒',
              inParams: '',
              outParams: data
            }
          })
        } else if (msg.cmd == 501) { //坐席点不发送满意度按钮
          var data = JSON.parse(content);

          that.evaluate.SatisfactionURL = data.satisfactionMsg
          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 坐席点不发送满意度按钮',
              inParams: '',
              outParams: data
            }
          })
        } else if (msg.cmd == 502) { //结束聊天
          var data = JSON.parse(content);

          that.cmdclose = true;
          that.calldrop();
          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 结束聊天',
              inParams: '',
              outParams: ''
            }
          })
        } else if (msg.cmd == 503) { //快照
          var data = JSON.parse(content);

          that.snapshot();
          logsout({
            method: 'initZrgEvent',
            detail: {
              info: '转人工socket 服务端消息 快照',
              inParams: '',
              outParams: data
            }
          })
        }
      }
    });
  },
  //获取地区code
  getaddress: function() {
    var that = this;
    let x = ''; //地区国家行政区划表.先默认北京
    let ad1 = app.globalData.address;
    let ad2 = app.globalData.addressls;
    if (ad1 != null) { //定位
      if (ad1.address_component.nation != '中国') { //海外
        x = 'areacode';
      } else if ($.f.judgecity(ad1.address_component.city)) { //单列市
        x = (ad1.ad_info.adcode).substring(0, 4) + '00';
      } else {
        x = (ad1.ad_info.adcode).substring(0, 2) + '0000';
      }
    } else { //选择
      if ($.f.judgecity(ad2[1].name)) { //单列市
        x = ad2[1].code
      } else {
        x = ad2[0].code
      }
    }
    logsout({
      method: 'getaddress',
      detail: {
        info: '获取地区code',
        inParams: x,
        outParams: ''
      }
    })
    return x
  },
  // //字典排序sha1加密
  // SORTSHA(token, nonce, timestamp) {
  //   var that = this;
  //   var list = [token, nonce, timestamp];
  //   list.sort();
  //   var sha1 = $.sha1(list.join(''));
  //   try {
  //     $.xbossdebug.error(`
  //     ===========${that.phoneTel}=====SORTSHA======>
  //     ${JSON.stringify({
  //       sha1
  //     }) }
  //     `)
  //   } catch (e) {}
  //   return sha1
  // },
  //转人工参数处理
  zrgRequest() {
    var that = this;
    var params = {
      token: that.data.token,
      num: that.data.nonce
    }
    $.Http.request($.HttpURL.getSignature, params, false, function(res) {
      var data = {
        phoneNo: app.globalData.userPhone || '02161694627',
        areaNo: String(that.getaddress()),
        timestamp: res.currentTime,
        signature: res.sgin,
        userId: app.globalData.userOpenId,
        nickname: '',
      }
      that.setData(data, function() {
        that.zrgRequest1();
        that.ringAndTime();
        logsout({
          method: 'zrgRequest',
          detail: {
            info: '转人工参数处理',
            inParams: {
              params,
              data
            },
            outParams: ''
          }
        })
      });
    })
  },
  //转人工
  zrgRequest1() {
    var that = this;
    var messageJson = {};
    var contentJson = {};

    var sessionId = that.generateUUID();

    messageJson.msgtype = 6;
    messageJson.cmd = 1; //视频转人工命令
    messageJson.token = that.data.token;
    messageJson.sender = sessionId;
    messageJson.chatModel = "1"; //会话模式
    messageJson.userType = "1"; //用户类型
    messageJson.sourceNo = "003";
    messageJson.platform = "video"; //渠道类型
    contentJson.type = 2;
    var phoneNo = that.data.phoneNo;
    var areaNo = that.data.areaNo;
    var timestamp = that.data.timestamp;
    var signature = that.data.signature;
    var nonce = that.data.nonce;
    var userId = that.data.userId;
    var userName = that.data.nickname;
    contentJson.content = "phoneNo|" + phoneNo + ";" +
      "areaNo|" + areaNo + ";" +
      "timestamp|" + timestamp + ";" +
      "signature|" + signature + ";" +
      "nonce|" + nonce + ";" +
      "userId|" + userId + ";" +
      "userName|" + userName;
    logsout({
      method: 'zrgRequest1',
      detail: {
        info: '转人工',
        inParams: {
          messageJson,
          contentJson
        },
        outParams: ''
      }
    })
    var content = zrgMessagebody.create(contentJson);
    messageJson.content = zrgMessagebody.encode(content).finish();
    var message = zrgMessage.create(messageJson);
    that.sendZrgMessage(zrgMessage.encode(message).finish());
  },
  //generateUUID
  generateUUID() {
    var that = this;
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = (d + Math.random() * 16) % 16 | 0;
      d = Math.floor(d / 16);
      return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    logsout({
      method: 'generateUUID',
      detail: {
        info: 'generateUUID',
        inParams: uuid,
        outParams: ''
      }
    })
    return uuid;
  },

  //发送转人工信令
  sendZrgMessage(msg) {
    var that = this;
    if (zrgSocketTask != null && that.data.zrg_ws_open) {
      zrgSocketTask.send({
        data: msg.slice().buffer,
        success: function(e) {
          logsout({
            method: 'sendZrgMessage',
            detail: {
              info: '发送转人工信令 成功',
              inParams: msg,
              outParams: e
            }
          })
        },
        fail: function(e) {
          logsout({
            method: 'sendZrgMessage',
            detail: {
              info: '发送转人工信令 失败',
              inParams: msg,
              outParams: e
            }
          })
        },
        complete: function(e) {}
      });
    } else {
      logsout({
        method: 'sendZrgMessage',
        detail: {
          info: '发送转人工信令 人工服务没有连接',
          inParams: msg,
          outParams: ''
        }
      })
    }
  },

  /**
   * vc socket部分
   */
  //连接视频信令服务
  connect_vc() {
    var that = this;

    vcSocketTask = wx.connectSocket({
      url: that.data.vc_ws_url,
      header: {
        'content-type': 'application/json'
      },
      method: "GET",
      success() {

        that.setData({
          vc_ws_open: true
        }, function() {
          that.initVCEvent();
        })
        logsout({
          method: 'connect_vc',
          detail: {
            info: '连接视频信令socket 成功 ',
            inParams: {
              url: that.data.vc_ws_url
            },
            outParams: ''
          }
        })
      },
      fail() {

        that.data.vc_ws_open = false;
        that.reconnect_vc();
        logsout({
          method: 'connect_vc',
          detail: {
            info: '连接视频信令socket 失败 ',
            inParams: {
              url: that.data.vc_ws_url
            },
            outParams: ''
          }
        })
      },
      complete: function(res) {

      },

    })
  },
  //重连vc服务
  reconnect_vc() {
    var that = this;
    if (that.data.vc_ws_open) return;
    that.data.vc_ws_open = true;
    //没连接上会一直重连，设置延迟避免请求过多
    setTimeout(function() {

      that.connect_vc();
      that.data.vc_ws_open = false;
      logsout({
        method: 'reconnect_vc',
        detail: {
          info: '重连vc socket服务 ',
          inParams: '',
          outParams: ''
        }
      })
    }, 2000);
  },
  //初始化视频信令服务
  initVCEvent() {
    var that = this;

    if (that.data.vc_ws_open) {
      vcSocketTask.onOpen(res => {
        // that.vcFlag = false; //视频socket自动关闭问题
        that.data.vc_ws_open = true;

        logsout({
          method: 'initVCEvent',
          detail: {
            info: '视频socket 打开 ',
            inParams: '',
            outParams: res
          }
        })
      })
      vcSocketTask.onClose(onClose => {

        that.data.vc_ws_open = false;
        logsout({
          method: 'initVCEvent',
          detail: {
            info: '视频socket 关闭 ',
            inParams: '',
            outParams: onClose
          }
        })
      })
      vcSocketTask.onError(onError => {

        that.data.vc_ws_open = false;
        that.reconnect_vc();
        logsout({
          method: 'initVCEvent',
          detail: {
            info: '视频socket 报错 ',
            inParams: '',
            outParams: onError
          }
        })
      })
      vcSocketTask.onMessage(res => {

        var message = JSON.parse(res.data);

        if (message && message.player && message.pusher) {
          that.data.play_src = that.data.base_src + message.player;
          that.data.push_src = that.data.base_src + message.pusher;

          // wx.showToast({
          //   title: that.data.connect_info,
          //   icon: 'playing',
          //   duration: 1000
          // });
          that.closeRingAndTime()
          // that.callBind();
          logsout({
            method: 'initVCEvent',
            detail: {
              info: '视频socket 服务器消息  推拉流地址',
              inParams: '',
              outParams: {
                message,
                play_src: that.data.play_src,
                push_src: that.data.push_src

              }
            }
          })
        } else if (message && message.server_hangup && message.server_hangup == "1") {

          // wx.showToast({
          //   title: that.data.close_info,
          //   icon: 'playing',
          //   duration: 1000
          // });
          // setTimeout(() => {

          //   that.playContent.stop();
          //   that.pusherContent.stop();
          // }, 1500);
          that.playContent.stop();
          that.pusherContent.stop();
          logsout({
            method: 'initVCEvent',
            detail: {
              info: '视频socket 服务器消息  停止推拉流',
              inParams: '',
              outParams: message
            }
          })
        } else if (message && message.faceresult) {

          that.data.faceresult = message.faceresult;
          // wx.showToast({
          //   title: '比对结果:' + that.data.faceresult,
          //   icon: 'playing',
          //   duration: 2000
          // });
          logsout({
            method: 'initVCEvent',
            detail: {
              info: '视频socket 服务器消息  比对结果',
              inParams: '',
              outParams: message
            }
          })
        };
      });
    }

  },
  //视频接入时响铃关闭
  closeRingAndTime() {
    var that = this;
    that.cleartime();
    that.setData({
      // SID: data.sid,
      // CaseID: data.orderid,
      showimg: false,
      showPusher: true,
      showPlayer: true,
      antext: ''
    }, function() {
      that.callBind()
      innerAudioContext.stop(); //结束提示音
      logsout({
        method: 'closeRingAndTime',
        detail: {
          info: '视频接入时响铃关闭',
          inParams: '',
          outParams: ''
        }
      })

    });



  },
  //推拉流状态码
  statechange(e) {
    var that = this;

    if (e.detail.code == 2004) { //拉流成功，显示客服屏幕,视频计时

      // that.setData({
      //   showPlayer: true
      // });
      that.videoRecord();
    }
    logsout({
      method: 'statechange',
      detail: '推拉流状态码  ' + e.detail.code
    })
  },
  //视频接入
  callBind() {
    var that = this;
    // that.closeRingAndTime();


    that.playContent = wx.createLivePlayerContext('player');
    that.setData({
      player_url: that.data.play_src
    }, function() {
      // that.playContent.stop();
      // setTimeout(() => {

      //   that.playContent.play();

      // }, 500);
      that.playContent.stop({
        success: res => {
          that.playContent.play()
        },
        fail: res => {

        }
      })

    });


    that.pusherContent = wx.createLivePusherContext('pusher'),
      that.setData({
        pusher_url: that.data.push_src
      }, function() {
        // that.pusherContent.stop();
        // setTimeout(() => {

        //   that.pusherContent.start({
        //     success: res => {
        //       console.log('start success')
        //     },
        //     fail: res => {
        //       console.log('start fail')
        //     }
        //   });

        // }, 500);
        that.pusherContent.stop({
          success: res => {
            that.pusherContent.start()
          },
          fail: res => {

          }
        })
      });
    // that.videoRecord();
    logsout({
      method: 'callBind',
      detail: {
        info: '视频接入',
        inParams: '',
        outParams: {
          player_url: that.data.play_src,
          pusher_url: that.data.push_src
        }
      }
    })
  },
  // 视频超过45秒上传视频记录
  videoRecord() {
    var that = this;
    that.liveTimeoutTimer4 = setTimeout(function() { // 视频超过45秒上传视频记录.由于延迟增加3秒
      app.sharepush('video');

      clearTimeout(that.liveTimeoutTimer4);
      that.liveTimeoutTimer4 = undefined;; //请求成功后清除4号定时器
      logsout({
        method: 'videoRecord',
        detail: {
          info: '视频超过45秒上传视频记录',
          inParams: '',
          outParams: ''
        }
      })
    }, 48000);
  },
  //快照
  snapshot: function() {
    var that = this;
    that.pusherContent.snapshot({
      success: function(res) {
        var path = res.tempImagePath;
        that.uploadimg(path); //上传图片
        logsout({
          method: 'snapshot',
          detail: {
            info: '快照 成功',
            inParams: '',
            outParams: res
          }
        })
      },
      fail: function(res) {
        logsout({
          method: 'snapshot',
          detail: {
            info: '快照 失败',
            inParams: '',
            outParams: res
          }
        })
      }
    });
  },
  //上传图片
  uploadimg: function(path) {
    var that = this;

    var params = {
      sessionId: that.data.chatSeessionID, //会话标识id
      type: that.imageId.toString(), //图片编号
      roomId: that.data.roomId, //分配会议号码
    }
    $.Http.uploadfile2(params, path, function(res) {
      if (res.msg == 'success') {
        that.imageId++;
        $.f.showToast('截屏上传成功', 'success');
        logsout({
          method: 'uploadimg',
          detail: {
            info: '快照 截屏上传成功',
            inParams: '',
            outParams: {
              params,
              res
            }
          }
        })
      } else {
        $.f.showToast('截屏上传失败');
        logsout({
          method: 'uploadimg',
          detail: {
            info: '快照 截屏上传失败',
            inParams: '',
            outParams: {
              params,
              res
            }
          }
        })

      }
    })
  },
  //加入会议//呼叫
  send_vc: function(msg) {
    var that = this;
    // var app = getApp();
    if (that.vc_ws_open == false) {

      return;
    }

    var data = JSON.stringify({
      // "user": this.videoUser,
      // "pwd": this.videoUserToken,
      // "command": "rtmpgetvc",
      // "confid": this.roomId,
      // "nickname": this.nickname
      "userid":msg.videoUser,
      "user": msg.videoUser,
      "pwd": msg.videoUserToken,
      "command": "rtmpgetvc",
      "confid": msg.roomId,
      "nickname": ''
    });
    that.sendVCMessage(data);
    // that.ringAndTime();
    logsout({
      method: 'send_vc',
      detail: {
        info: '加入会议',
        inParams: '',
        outParams: data
      }
    })
  },
  // 切换摄像头
  pusherBindSwitchCamera() {
    var that = this;
    that.pusherContent.switchCamera({
      success: res => {

        logsout({
          method: 'pusherBindSwitchCamera',
          detail: {
            info: '切换摄像头 成功',
            inParams: '',
            outParams: ''
          }
        })
      },
      fail: res => {

        logsout({
          method: 'pusherBindSwitchCamera',
          detail: {
            info: '切换摄像头 失败',
            inParams: '',
            outParams: ''
          }
        })
      }
    })
  },
  //挂断
  calldrop() {
    var that = this;

    that.playerBindStop();
    that.pusherBindStop();
    that.send_vc_drop();

    if (!that.cmdclose) { //(用户挂断时发送),并跳转到相应页面
      var message1 = {
        msgtype: 8,
        userType: "1",
        chatSeessionID: that.data.chatSeessionID,
        username: app.globalData.userName
      };

      var message = zrgMessage.create(message1);
      var buffer = zrgMessage.encode(message).finish();
      that.sendZrgMessage(buffer);
      wx.redirectTo({
        url: '/pages/videopage/videobeforer/videobeforer?Un=video'
      })
      logsout({
        method: 'calldrop',
        detail: {
          info: '用户挂断',
          inParams: '',
          outParams: {
            message1,
            url: '/pages/videopage/videobeforer/videobeforer?Un=video'
          }
        }
      })
      return
    }
    if (that.cmdclose) { //坐席结束聊天
      if (that.evaluate.SatisfactionURL != '') { //坐席没点不发送满意度按钮时，跳转到满意度页面
        that.Unload();
        let a = encodeURIComponent(that.evaluate.SatisfactionURL)
        wx.redirectTo({
          url: '/pages/videopage/webview/webview?url=' + a
        })
        logsout({
          method: 'calldrop',
          detail: {
            info: '坐席没点不发送满意度按钮时，跳转到满意度页面',
            inParams: '',
            outParams: {
              SatisfactionURL: that.evaluate.SatisfactionURL,
              url: '/pages/videopage/webview/webview?url=' + a
            }
          }
        })
      } else { //坐席点不发送满意度按钮时，跳转到相应页面
        wx.redirectTo({
          url: '/pages/videopage/videobeforer/videobeforer?Un=video'
        })
        logsout({
          method: 'calldrop',
          detail: {
            info: '坐席没点不发送满意度按钮时，跳转到满意度页面',
            inParams: '',
            outParams: {
              url: '/pages/videopage/videobeforer/videobeforer?Un=video'
            }
          }
        })
      }



    }



  },
  //停止推流
  pusherBindStop() {
    var that = this;
    that.pusherContent.stop({
      success: res => {

        logsout({
          method: 'pusherBindStop',
          detail: {
            info: '停止推流 成功',
            inParams: '',
            outParams: ''
          }
        })
      },
      fail: res => {

        logsout({
          method: 'pusherBindStop',
          detail: {
            info: '停止推流 失败',
            inParams: '',
            outParams: ''
          }
        })
      }
    })
  },
  //停止拉流
  playerBindStop() {
    var that = this;
    that.playContent.stop({
      success: res => {

        logsout({
          method: 'pusherBindStop',
          detail: {
            info: '停止拉流 成功',
            inParams: '',
            outParams: ''
          }
        })
      },
      fail: res => {

        logsout({
          method: 'pusherBindStop',
          detail: {
            info: '停止拉流 失败',
            inParams: '',
            outParams: ''
          }
        })
      }
    })
  },
  //退出会议
  send_vc_drop: function() {
    var that = this;
    // var app = getApp();
    if (that.vc_ws_open == false) {

      return;
    }
    var data = JSON.stringify({
      // "user": this.videoUser,
      // "pwd": this.videoUserToken,
      // "command": "rtmpvc_drop",
      // "nickname": app.globalData.user_nick
      "user": that.data.videoUser,
      "pwd": that.data.videoUserToken,
      "command": "rtmpvc_drop",
      "nickname": ''
    });
    that.sendVCMessage(data);
    logsout({
      method: 'send_vc_drop',
      detail: {
        info: '退出会议',
        inParams: '',
        outParams: ''
      }
    })
  },
  //发送视频信令
  sendVCMessage(msg) {
    var that = this;
    if (vcSocketTask != null && that.data.vc_ws_open) {
      vcSocketTask.send({
        data: msg,
        success: function(e) {

          logsout({
            method: 'sendVCMessage',
            detail: {
              info: '发送视频信令 成功',
              inParams: '',
              outParams: msg
            }
          })
        },
        fail: function(e) {

          logsout({
            method: 'sendVCMessage',
            detail: {
              info: '发送视频信令 失败',
              inParams: '',
              outParams: {
                msg,
                e
              }
            }
          })
        },
        complete: function(e) {

        }
      });
    } else {

      logsout({
        method: 'sendVCMessage',
        detail: {
          info: '视频服务没有连接',
          inParams: '',
          outParams: ''
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    console.log('onload');
    that.phoneTel = app.globalData.userPhone || '02161694627';
    that.connectSocket();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    var that = this;
    console.log('onready');
    // that.initSocket();

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    console.log('onShow');
    wx.setKeepScreenOn({ //防止熄屏
      keepScreenOn: true
    });
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    console.log('onhide');
    wx.setKeepScreenOn({
      keepScreenOn: false
    });
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    var that = this;
    console.log('onUnload');
    that.Unload();
  },

})