// pages/videopage/evaluate/evaluate.js
const app = getApp();
const $ = app.global;
const starurl1 = $.imgurl+'161255.png';
const starurl2 = $.imgurl+'161305.png';
Page({
  evaluate: {
    actId: '',//任务编号
    sid: '',//会话标识id
    empCode: '',//用户ID
    agentCode: '',//座席工号
  },
  /**
   * 页面的初始数据
   */
  data: {
    imgurl:$.imgurl,
    star1: starurl1,
    star2: starurl1,
    star3: starurl1,
    star4: starurl1,
    star5: starurl1,
    star:'',
    assess:'满意',
    assessnum:'1',
    inputValue:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(JSON.stringify(options))
    this.evaluate.actId = options.actId;
    this.evaluate.sid = options.sid;
    this.evaluate.empCode = options.empCode;
    this.evaluate.agentCode = options.agentCode;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  clickatar:function(event){//点击星星
    console.log(event.currentTarget.id);
    var n = event.currentTarget.id
    if (n == '1') {
      this.setData({
        star1: starurl1,
        star2: starurl2,
        star3: starurl2,
        star4: starurl2,
        star5: starurl2,
        assess:'差',
        assessnum:'3',
        star:'1'
      })
    }
    if (n == '2') {
      this.setData({
        star1: starurl1,
        star2: starurl1,
        star3: starurl2,
        star4: starurl2,
        star5: starurl2,
        assess: '一般',
        assessnum: '2',
        star: '2'
      })
    }
    if (n == '3') {
      this.setData({
        star1: starurl1,
        star2: starurl1,
        star3: starurl1,
        star4: starurl2,
        star5: starurl2,
        assess: '一般',
        assessnum: '2',
        star: '3'
      })
    }
    if (n == '4') {
      this.setData({
        star1: starurl1,
        star2: starurl1,
        star3: starurl1,
        star4: starurl1,
        star5: starurl2,
        assess: '满意',
        assessnum: '1',
        star: '4'
      })
    }
    if (n == '5') {
      this.setData({
        star1: starurl1,
        star2: starurl1,
        star3: starurl1,
        star4: starurl1,
        star5: starurl1,
        assess: '满意',
        assessnum: '1',
        star: '5'
      })
     }

  },

  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
  },

  Satisfaction: function () {
    var _this = this;
    var params = {
      'actId': _this.evaluate.actId,
      'empCode': _this.evaluate.empCode,
      'agentCode': _this.evaluate.agentCode,
      'callId': _this.evaluate.sid,
      'assessRes': _this.data.assessnum,
      'assessExplain': _this.data.inputValue
    };
    $.Http.request($.HttpURL.sendtranslate, params, false,function (res) {
        wx.showToast({
          title: '感谢您的评价',
          icon: 'success',
        })
        setTimeout(function () {
			wx.switchTab({
				url: '/pages/service/service'
          })
        }, 500);
    })
  },


})